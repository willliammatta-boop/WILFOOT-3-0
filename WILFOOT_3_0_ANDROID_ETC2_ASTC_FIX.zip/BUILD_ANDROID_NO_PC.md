# WILFOOT 3.0 — gerar APK sem PC

Este projeto inclui um workflow do GitHub Actions para compilar o APK na nuvem.

## Pelo celular
1. Crie uma conta no GitHub.
2. Crie um repositório novo.
3. Envie todos os arquivos deste projeto para o repositório.
4. Abra a aba **Actions**.
5. Selecione **Build WILFOOT Android APK**.
6. Toque em **Run workflow**.
7. Aguarde a compilação.
8. Abra a execução concluída e baixe o artefato **WILFOOT-3.0-Android**.
9. Dentro dele estará `WILFOOT_3.0_debug.apk`.

## Observação
O APK é de teste/debug. Para publicar comercialmente na Google Play, depois precisamos configurar assinatura de release, ícone, pacote definitivo, política de privacidade e outros metadados.
