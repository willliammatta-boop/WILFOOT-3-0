# WILFOOT 2.0 — Design Android real

Esta versão altera de fato o menu principal, não apenas documentação.

## Novo layout
- Barra superior com WILFOOT 2.0, temporada, caixa e perfil Moto G54.
- Sidebar de navegação.
- Hero central com identidade WILFOOT 2.0 e indicadores 1.200 clubes / 10 países / Engine 7.0 / 60 FPS.
- Central da carreira com Novo Jogo, Carregar, Editor, Salvar, Rankings, Galeria e Sair.
- Layout responsivo para paisagem e retrato Android.
- Botões continuam conectados às funções existentes.
- Visual azul/neon/dourado e painéis arredondados.
