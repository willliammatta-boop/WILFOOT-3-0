# WILFOOT Android 0.8

Projeto Godot 4 para Android em modo paisagem. Junta as versões 0.4 e 0.5, o redesign
lime/neon, a integração JSON com export web e o pacote ULTIMATE (times/jogadores reais,
patrocinadores e premiações), com correções ao longo do caminho.

## O motor do jogo (main.gd)
- Atributos, potencial, evolução, contratos e negociação (da 0.4)
- Mercado de transferências, treino por foco, lesões, orçamento e folha salarial (da 0.4)
- Escalação com 11 titulares e banco, formações, mentalidade, pressão e linha defensiva (da 0.5)
- 95 times (40 brasileiros + 55 do resto do mundo), calendário turno/returno, todos os times jogando
- Classificação no estilo do Brasileirão, com zonas coloridas e legenda
- Redesign lime/neon: menu principal, boot, cabeçalho, cartões, campo, partida ao vivo com narração
- Integração com export web em JSON (rodada_12.json): importar, simular e exportar

## Correções feitas nesta rodada (pacote ULTIMATE)
- **Simulação de rodada importada:** antes, um time sem dados caía sempre em 70 x 70 de
  força (quase sem variação); agora usa a força real das 95 ligas quando o nome bate, e
  senão usa uma força estável por nome (o mesmo time sempre fica com a mesma força).
- **Importar rodada:** agora tenta `user://`, depois o caminho configurado e por fim
  `res://Data/rodada_12.json`, e valida se o JSON tem `partida_principal` e
  `jogos_da_rodada` antes de aceitar, com mensagem de erro mais clara (linha do erro).
- **Salvar rodada:** gravação atômica (escreve num arquivo temporário e só troca pelo
  definitivo no final, com backup do anterior) para não corromper o save se a gravação
  for interrompida.
- Os scripts do pacote ULTIMATE (`Scripts/*.gd`) e os dados (`Data/*.json`) foram
  conferidos (indentação, chaves/parênteses, funções duplicadas): não achei erros de
  sintaxe nesses arquivos.

## Novas telas (a partir do pacote ULTIMATE)
Na aba MAIS:
- **TÍTULOS REAIS:** carteira de títulos de 5 jogadores reais (Messi, CR7, Neymar,
  Gabigol, Endrick) e 4 times reais (Flamengo, Palmeiras, Real Madrid, Man City), com
  linha do tempo por ano. Só consulta — não interfere no seu elenco.
- **PATROCINADORES:** os 13 patrocínios reais de 2025/2026 do pacote (Flamengo Betano
  R$268M/ano, etc). Só consulta — não afeta seu caixa.
- **PREMIAÇÕES REAIS:** valores oficiais de Brasileirão, Copa do Brasil, Libertadores e
  Brasileirão Feminino 2026. Só consulta.

## O que veio junto mas não foi ligado à navegação
O pacote ULTIMATE tem muito mais do que estas 3 telas: editor de time/kit, importação de
ligas por .zip/.ban/.png, categoria de base com newgens anuais, conquistas desbloqueáveis,
preferências completas, save em múltiplos slots, e mais títulos/times reais com radar de
atributos. Todo esse código está em `Scripts/` e `Data/`, sem erros de sintaxe que eu
tenha encontrado, mas **não** foi ligado ao menu do jogo nesta versão: cada uma dessas
telas foi construída para uma cena (`.tscn`) própria, com caminhos de nó (`$Painel/Botão`
etc.) que não existem no `Main.tscn` deste projeto, e recriar a interface de cada uma no
nosso estilo (como fiz com as 3 telas acima) é trabalho grande por sistema. Ficam
disponíveis para quem quiser montar a cena própria delas no Godot, ou para eu ligar uma
de cada vez nas próximas versões.

O `WILFOOT_Main_MELHORADO_10000.gd` enviado não entrou como arquivo — ele é um script de
cena raiz alternativo (assim como o `main.gd`), e um projeto Godot só roda um script raiz
por cena. As melhorias dele (força real por time, validação de esquema, gravação atômica)
foram incorporadas diretamente no `main.gd`, descritas acima. `RodadaData.gd` e
`UIManager.gd` foram incluídos em `Scripts/` como estão — são independentes e não
conflitam com nada, mas o `main.gd` ainda lê a rodada como `Dictionary` solto, não como os
recursos tipados desses dois arquivos.

## Abrir
1. Instale Godot 4.x.
2. Importe esta pasta (mantém `main.gd`, `Main.tscn`, `project.godot`, `Scripts/`, `Data/`).
3. Execute o projeto (F5).
4. Para Android: configure o Android SDK no Godot e use Project > Export > Android.

Este ZIP é o projeto-fonte, não um APK compilado.


## Base mundial atualizada
Esta versão contém 1.200 clubes: 120 em cada um dos 10 países. Os 120 clubes de cada país são divididos em 20 da elite e 100 de divisões inferiores/regionais. O banco completo fica em `Data/mundo_1200_clubes.json`; o arquivo `mundo_120_clubes.json` foi atualizado para refletir os 1.200 clubes.


## WILFOOT ENGINE 7.0
- Núcleo `Scripts/WilfootEngine7.gd` com validação de banco e simulação segura.
- 10 países e 1.200 clubes (120 por país).
- Calendário de divisões, tabelas, resultados e base para promoção/rebaixamento.
- Fallback seguro para JSON ausente/corrompido.
- Correções de UI: filtros de elenco, salvamento do editor de equipes, menu sem dependência de `z_index` em diálogos.
- O projeto continua compatível com Godot 4.x; “Engine 7.0” é o motor interno do WILFOOT, não uma versão do Godot.


## LOCALIZAÇÃO 2.1

Inclui Português-BR, Inglês-UK, Alemão, Italiano, Francês, Espanhol, Português-PT e Turco, com seleção manual ou automática e persistência local.
