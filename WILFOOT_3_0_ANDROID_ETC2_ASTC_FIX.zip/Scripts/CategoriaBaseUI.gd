extends Control
# Sistema Categoria de Base Completo - UI editável nome, overall, idade, etc - Igual FM

var jogadores: Array[JogadorBase] = []
var filtro_categoria: String = "TODOS"
var busca: String = ""
var ordenacao: String = "POTENCIAL"

@onready var lista: VBoxContainer = $MainVBox/Scroll/Lista
@onready var header_stats: Label = $MainVBox/Header/Stats
@onready var busca_input: LineEdit = $MainVBox/Header/Busca
@onready var filtros: HBoxContainer = $MainVBox/Filtros

func _ready():
  carregar_base()
  conectar_filtros()
  atualizar_lista()

func carregar_base():
  var f = FileAccess.open("res://Data/categoria_base.json", FileAccess.READ)
  if f==null: return
  var j = JSON.new(); j.parse(f.get_as_text())
  for d in j.data:
    jogadores.append(JogadorBase.from_dict(d))

func conectar_filtros():
  if busca_input:
    busca_input.text_changed.connect(func(t): busca=t; _filtrar())
  for child in filtros.get_children():
    if child is Button:
      child.pressed.connect(func(): _on_filtro(child.text))

func _on_filtro(cat: String):
  filtro_categoria = cat
  _filtrar()

func _filtrar():
  var filtrados = jogadores.filter(func(j):
    var match_cat = filtro_categoria=="TODOS" or j.categoria==filtro_categoria
    var match_busca = busca=="" or j.nome.to_lower().contains(busca.to_lower()) or j.pos.to_lower().contains(busca.to_lower())
    return match_cat and match_busca
  )
  filtrados.sort_custom(func(a,b):
    if ordenacao=="POTENCIAL": return a.potencial>b.potencial
    elif ordenacao=="OVR": return a.ovr>b.ovr
    elif ordenacao=="IDADE": return a.idade<b.idade
    else: return a.nome<b.nome
  )
  _mostrar_lista(filtrados)

func atualizar_lista():
  _filtrar()

func _mostrar_lista(filtrados: Array):
  for c in lista.get_children(): c.queue_free()
  
  # Stats header
  var total = filtrados.size()
  var media_ovr = 0; var media_pot = 0; var destaques = 0
  for j in filtrados: media_ovr+=j.ovr; media_pot+=j.potencial; 
  for j in filtrados:
    if j.potencial>=85: destaques+=1
  if total>0:
    media_ovr/=total; media_pot/=total
  if header_stats:
    header_stats.text = "🌱 %d atletas | ⭐ OVR %d | 🔥 POT %d | 💎 %d destaques POT 85+" % [total, media_ovr, media_pot, destaques]
  
  for i in range(filtrados.size()):
    var card = _criar_card(filtrados[i], i)
    lista.add_child(card)

func _criar_card(j: JogadorBase, idx: int) -> Control:
  var panel = PanelContainer.new()
  panel.custom_minimum_size = Vector2(0, 110)
  var sb = StyleBoxFlat.new()
  sb.bg_color = Color(0.09,0.12,0.20) if idx%2==0 else Color(0.11,0.14,0.23)
  sb.corner_radius_top_left=12; sb.corner_radius_top_right=12; sb.corner_radius_bottom_left=12; sb.corner_radius_bottom_right=12
  sb.border_width_left=1; sb.border_width_top=1; sb.border_width_right=1; sb.border_width_bottom=1
  if j.potencial>=90: sb.border_color=Color(1,0.84,0,0.6) # ouro para wonderkid
  elif j.potencial>=85: sb.border_color=Color(0.77,1,0,0.5) # verde limão destaque
  else: sb.border_color=Color(1,1,1,0.06)
  sb.content_margin_left=12; sb.content_margin_right=12; sb.content_margin_top=10; sb.content_margin_bottom=10
  panel.add_theme_stylebox_override("panel", sb)
  
  var vbox = VBoxContainer.new(); panel.add_child(vbox)
  
  # Linha 1: Nome editável + Pos + Idade editável + OVR editável + POT
  var h1 = HBoxContainer.new(); h1.add_theme_constant_override("separation",8)
  vbox.add_child(h1)
  
  var nome_edit = LineEdit.new(); nome_edit.text=j.nome; nome_edit.custom_minimum_size=Vector2(140,0)
  nome_edit.placeholder_text="Nome"; nome_edit.add_theme_font_size_override("font_size",13)
  nome_edit.text_submitted.connect(func(novo): if j.editar_nome(novo): salvar())
  
  var pos_btn = OptionButton.new(); pos_btn.custom_minimum_size=Vector2(60,0)
  var posicoes = ["G","LD","LE","ZD","ZE","VOL","MC","ME","MD","AE","AD","ATA"]
  for p in posicoes: pos_btn.add_item(p)
  pos_btn.selected = posicoes.find(j.pos)
  pos_btn.item_selected.connect(func(idx): j.editar_pos(posicoes[idx]); salvar(); atualizar_lista())
  
  var idade_spin = SpinBox.new(); idade_spin.min_value=14; idade_spin.max_value=23; idade_spin.value=j.idade; idade_spin.custom_minimum_size=Vector2(70,0)
  idade_spin.value_changed.connect(func(v): j.editar_idade(int(v)); salvar(); atualizar_lista())
  
  var ovr_spin = SpinBox.new(); ovr_spin.min_value=1; ovr_spin.max_value=99; ovr_spin.value=j.ovr; ovr_spin.custom_minimum_size=Vector2(70,0)
  ovr_spin.prefix="OVR "
  ovr_spin.value_changed.connect(func(v): j.editar_ovr(int(v)); salvar(); atualizar_lista())
  
  var pot_label = Label.new(); pot_label.text="POT %d" % j.potencial
  if j.potencial>=85: pot_label.add_theme_color_override("font_color", Color(0.77,1,0))
  elif j.potencial>=90: pot_label.add_theme_color_override("font_color", Color(1,0.84,0))
  
  h1.add_child(nome_edit); h1.add_child(pos_btn); h1.add_child(idade_spin); h1.add_child(ovr_spin); h1.add_child(pot_label)
  
  # Linha 2: Atributos editáveis + bandeira + categoria + valor
  var h2 = HBoxContainer.new(); h2.add_theme_constant_override("separation",6)
  vbox.add_child(h2)
  
  var flag = Label.new(); flag.text=j.flag; flag.add_theme_font_size_override("font_size",14)
  var cat_badge = Label.new(); cat_badge.text=j.categoria
  var cat_sb = StyleBoxFlat.new()
  if j.categoria=="Sub-15": cat_sb.bg_color=Color(0.2,0.5,1,0.2)
  elif j.categoria=="Sub-17": cat_sb.bg_color=Color(0.2,0.8,0.4,0.2)
  else: cat_sb.bg_color=Color(1,0.6,0.2,0.2)
  cat_sb.corner_radius_top_left=4; cat_sb.corner_radius_top_right=4; cat_sb.corner_radius_bottom_left=4; cat_sb.corner_radius_bottom_right=4
  cat_sb.content_margin_left=6; cat_sb.content_margin_right=6
  cat_badge.add_theme_stylebox_override("normal", cat_sb)
  cat_badge.add_theme_font_size_override("font_size",9)
  
  var valor_l = Label.new(); valor_l.text="€%.1fM" % j.valor; valor_l.add_theme_font_size_override("font_size",10); valor_l.modulate=Color(0.7,0.85,0.7)
  
  var status_l = Label.new(); status_l.text=j.status; status_l.add_theme_font_size_override("font_size",9); status_l.modulate=Color(0.6,0.7,0.8)
  
  h2.add_child(flag); h2.add_child(cat_badge); h2.add_child(valor_l); h2.add_child(status_l)
  
  # Barras de atributos editáveis
  for attr in ["VEL","FIN","PAS","DRI"]:
    var attr_box = VBoxContainer.new()
    var attr_label = Label.new(); attr_label.text=attr; attr_label.add_theme_font_size_override("font_size",8); attr_label.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
    var attr_spin = SpinBox.new(); attr_spin.min_value=1; attr_spin.max_value=99; attr_spin.value=j.atributos.get(attr,60); attr_spin.custom_minimum_size=Vector2(55,0)
    attr_spin.add_theme_font_size_override("font_size",9)
    attr_spin.value_changed.connect(func(v): j.editar_atributo(attr, int(v)); salvar(); atualizar_lista())
    attr_box.add_child(attr_label); attr_box.add_child(attr_spin)
    h2.add_child(attr_box)
  
  # Botões ação
  var h3 = HBoxContainer.new()
  vbox.add_child(h3)
  var btn_promover = Button.new(); btn_promover.text="⬆️ Promover"; btn_promover.add_theme_font_size_override("font_size",10)
  btn_promover.pressed.connect(func(): if j.promover_para_profissional(): salvar(); atualizar_lista())
  var btn_emprestar = Button.new(); btn_emprestar.text="🔄 Emprestar"; btn_emprestar.add_theme_font_size_override("font_size",10)
  var btn_dispensar = Button.new(); btn_dispensar.text="❌ Dispensar"; btn_dispensar.add_theme_font_size_override("font_size",10)
  btn_dispensar.pressed.connect(func(): jogadores.erase(j); salvar(); atualizar_lista())
  h3.add_child(btn_promover); h3.add_child(btn_emprestar); h3.add_child(btn_dispensar)
  
  return panel

func salvar():
  DirAccess.make_dir_recursive_absolute("user://Data/")
  var arr = jogadores.map(func(j): return j.to_dict())
  var f = FileAccess.open("user://Data/categoria_base_editada.json", FileAccess.WRITE)
  f.store_string(JSON.stringify(arr, "\t"))
  f.close()
  print("Base salva - %d jogadores" % jogadores.size())

func gerar_novo_jogador():
  var novo = JogadorBase.new()
  novo.nome = "Novo Talento %d" % (jogadores.size()+1)
  novo.idade = 16
  novo.ovr = 60
  novo.potencial = 80
  jogadores.append(novo)
  salvar()
  atualizar_lista()
