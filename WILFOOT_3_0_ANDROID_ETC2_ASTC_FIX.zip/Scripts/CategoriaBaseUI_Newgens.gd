extends Control
# Sistema Base + Newgens Anual - Atualizado com geração automática

var jogadores: Array[JogadorBase] = []
var filtro_categoria: String = "TODOS"
var busca: String = ""
var generator: NewgenGenerator = NewgenGenerator.new()
var temporada_manager: TemporadaManager = TemporadaManager.new()
var ano: int = 2026

@onready var lista: VBoxContainer = $MainVBox/Scroll/Lista
@onready var header_stats: Label = $MainVBox/Header/Stats

func _ready():
  carregar_base()
  atualizar_lista()

func carregar_base():
  var path = "user://Data/categoria_base_editada.json"
  if not FileAccess.file_exists(path):
    path = "res://Data/categoria_base.json"
  if not FileAccess.file_exists(path): return
  var f = FileAccess.open(path, FileAccess.READ)
  var j = JSON.new(); j.parse(f.get_as_text())
  jogadores.clear()
  for d in j.data:
    jogadores.append(JogadorBase.from_dict(d))

func atualizar_lista():
  for c in lista.get_children(): c.queue_free()
  var filtrados = jogadores.filter(func(j): return filtro_categoria=="TODOS" or j.categoria==filtro_categoria)
  filtrados.sort_custom(func(a,b): return a.potencial>b.potencial)
  
  var total = filtrados.size()
  var media_ovr = 0; var media_pot = 0; var wonder = 0
  for j in filtrados: media_ovr+=j.ovr; media_pot+=j.potencial; 
  for j in filtrados:
    if j.status=="Wonderkid": wonder+=1
  if total>0: media_ovr/=total; media_pot/=total
  if header_stats:
    header_stats.text = "🌱 %d atletas (%d) | ⭐ OVR %d | 🔥 POT %d | 💎 %d wonderkids | 🏟️ Estrutura: %s" % [total, ano, media_ovr, media_pot, wonder, temporada_manager.estrutura_base]
  
  for j in filtrados:
    var card = _criar_card(j)
    lista.add_child(card)

func _criar_card(j: JogadorBase) -> Control:
  var panel = PanelContainer.new(); panel.custom_minimum_size=Vector2(0,100)
  var sb = StyleBoxFlat.new(); sb.bg_color=Color(0.09,0.12,0.20)
  sb.corner_radius_top_left=12; sb.corner_radius_top_right=12; sb.corner_radius_bottom_left=12; sb.corner_radius_bottom_right=12
  if j.status=="Wonderkid": sb.border_color=Color(1,0.84,0,0.8); sb.border_width_left=2
  elif j.potencial>=85: sb.border_color=Color(0.77,1,0,0.5)
  else: sb.border_color=Color(1,1,1,0.06)
  sb.border_width_left=1; sb.border_width_top=1; sb.border_width_right=1; sb.border_width_bottom=1
  sb.content_margin_left=12; sb.content_margin_right=12; sb.content_margin_top=8; sb.content_margin_bottom=8
  panel.add_theme_stylebox_override("panel", sb)
  var hbox = HBoxContainer.new(); panel.add_child(hbox)
  var vbox = VBoxContainer.new(); vbox.size_flags_horizontal=Control.SIZE_EXPAND_FILL; hbox.add_child(vbox)
  var nome = Label.new(); nome.text="%s %s | %s %d anos | OVR %d POT %d" % [j.flag, j.nome, j.pos, j.idade, j.ovr, j.potencial]
  if j.status=="Wonderkid": nome.add_theme_color_override("font_color", Color(1,0.84,0))
  var cat = Label.new(); cat.text="%s | %s | €%.1fM | %s" % [j.categoria, j.personalidade, j.valor, j.status]; cat.add_theme_font_size_override("font_size",10); cat.modulate=Color(0.7,0.8,0.9)
  vbox.add_child(nome); vbox.add_child(cat)
  return panel

func _on_gerar_nova_safra():
  var novos = temporada_manager.avancar_temporada()
  for n in novos: jogadores.append(n)
  ano = temporada_manager.ano_atual
  salvar()
  atualizar_lista()
  print("Nova safra %d gerada: %d jogadores" % [ano, novos.size()])

func salvar():
  DirAccess.make_dir_recursive_absolute("user://Data/")
  var arr = jogadores.map(func(j): return j.to_dict())
  var f = FileAccess.open("user://Data/categoria_base_editada.json", FileAccess.WRITE)
  f.store_string(JSON.stringify(arr, "\t")); f.close()
