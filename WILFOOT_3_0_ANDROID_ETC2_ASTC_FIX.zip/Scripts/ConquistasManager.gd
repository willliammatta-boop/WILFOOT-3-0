extends Resource
class_name ConquistasManager

# Sistema Conquistas Desbloqueáveis - 1.281 gols Pelé, 8 Bolas Ouro Messi, etc

var conquistas: Array = []
var total_desbloqueadas: int = 0
var recompensa_total: int = 0

func _init():
  carregar_conquistas()

func carregar_conquistas():
  # Se já existe progresso salvo, usa ele; senão parte da lista base do jogo.
  var progresso_path = "user://Data/conquistas_progresso.json"
  var path = progresso_path if FileAccess.file_exists(progresso_path) else "res://Data/conquistas_desbloqueaveis.json"
  var f = FileAccess.open(path, FileAccess.READ)
  if f == null:
    push_error("ConquistasManager: não foi possível abrir %s" % path)
    return
  var texto = f.get_as_text()
  f.close()
  var j = JSON.new()
  var err = j.parse(texto)
  if err != OK or typeof(j.data) != TYPE_ARRAY:
    push_error("ConquistasManager: JSON inválido em %s" % path)
    return
  conquistas = j.data
  total_desbloqueadas = conquistas.filter(func(c): return c.get("desbloqueado", false)).size()

func verificar_progresso(tipo: String, valor: int) -> Array:
  var desbloqueadas_agora = []
  for conquista in conquistas:
    if conquista.get("desbloqueado",false): continue
    if tipo in conquista.get("id",""):
      conquista["progresso_atual"] += valor
      if conquista["progresso_atual"] >= conquista.get("meta",0):
        conquista["desbloqueado"] = true
        total_desbloqueadas += 1
        recompensa_total += conquista.get("recompensa",0)
        desbloqueadas_agora.append(conquista)
        print("🎉 CONQUISTA DESBLOQUEADA: %s - %s - Recompensa %d" % [conquista.get("icone",""), conquista.get("nome",""), conquista.get("recompensa",0)])
  salvar()
  return desbloqueadas_agora

func adicionar_gol(jogador_id: String):
  return verificar_progresso("gols", 1)

func adicionar_bola_ouro(jogador_id: String):
  return verificar_progresso("bolas_ouro", 1)

func adicionar_titulo(titulo_id: String):
  return verificar_progresso(titulo_id, 1)

func get_conquistas_por_categoria(cat: String) -> Array:
  return conquistas.filter(func(c): return c.get("categoria","")==cat)

func get_conquistas_por_raridade(rar: String) -> Array:
  return conquistas.filter(func(c): return c.get("raridade","")==rar)

func get_progresso_percentual(id: String) -> float:
  for c in conquistas:
    if c.get("id","")==id:
      return float(c.get("progresso_atual",0)) / float(c.get("meta",1)) * 100.0
  return 0.0

func salvar():
  DirAccess.make_dir_recursive_absolute("user://Data/")
  var f = FileAccess.open("user://Data/conquistas_progresso.json", FileAccess.WRITE)
  if f == null:
    push_error("ConquistasManager: falha ao salvar progresso de conquistas")
    return
  f.store_string(JSON.stringify(conquistas, "\t"))
  f.close()

func get_resumo() -> String:
  var miticas = get_conquistas_por_raridade("Mítica").size()
  var miticas_desbloq = get_conquistas_por_raridade("Mítica").filter(func(c): return c.get("desbloqueado",false)).size()
  return "%d/%d conquistas | %d míticas (%d desbloqueadas) | Recompensa total €%dM" % [total_desbloqueadas, conquistas.size(), miticas, miticas_desbloq, recompensa_total/1000000]
