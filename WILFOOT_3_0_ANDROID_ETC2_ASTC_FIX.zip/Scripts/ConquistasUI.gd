extends Control
# UI Conquistas Desbloqueáveis - 1.281 gols Pelé, 8 Bolas Ouro Messi, etc

var manager: ConquistasManager = ConquistasManager.new()
var conquistas: Array = []
var filtro_raridade: String = "TODAS"

@onready var lista: VBoxContainer = $MainVBox/Scroll/Lista
@onready var header: Label = $MainVBox/Header/Stats

func _ready():
  # Usa o ConquistasManager para que o progresso salvo (user://Data/conquistas_progresso.json)
  # seja lido e as conquistas fiquem realmente desbloqueáveis, não só uma lista estática.
  conquistas = manager.conquistas
  atualizar()

func atualizar():
  for c in lista.get_children(): c.queue_free()
  
  var total = conquistas.size()
  var desbloqueadas = conquistas.filter(func(c): return c.get("desbloqueado",false)).size()
  var miticas = conquistas.filter(func(c): return c.get("raridade","")=="Mítica").size()
  if header:
    header.text = "🏆 %d/%d conquistas | 💎 %d míticas | 👑 Pelé 1.281 gols | Messi 8 Bolas Ouro" % [desbloqueadas, total, miticas]
  
  var filtradas = conquistas
  if filtro_raridade!="TODAS":
    filtradas = conquistas.filter(func(c): return c.get("raridade","")==filtro_raridade)
  
  filtradas.sort_custom(func(a,b):
    var ordem = {"Mítica":4,"Lendária":3,"Épica":2,"Rara":1}
    return ordem.get(a.get("raridade",""),0) > ordem.get(b.get("raridade",""),0)
  )
  
  for conquista in filtradas:
    var panel = PanelContainer.new()
    var sb = StyleBoxFlat.new()
    var desbloqueado = conquista.get("desbloqueado",false)
    if desbloqueado:
      sb.bg_color=Color(0.1,0.2,0.1)
      sb.border_color=Color(0.77,1,0,0.6)
    else:
      sb.bg_color=Color(0.09,0.12,0.20)
      if conquista.get("raridade","")=="Mítica": sb.border_color=Color(1,0.84,0,0.5)
      elif conquista.get("raridade","")=="Lendária": sb.border_color=Color(0.8,0.4,1,0.4)
      elif conquista.get("raridade","")=="Épica": sb.border_color=Color(0.2,0.6,1,0.4)
      else: sb.border_color=Color(1,1,1,0.08)
    sb.corner_radius_top_left=12; sb.corner_radius_top_right=12; sb.corner_radius_bottom_left=12; sb.corner_radius_bottom_right=12
    sb.border_width_left=2; sb.border_width_top=1; sb.border_width_right=1; sb.border_width_bottom=1
    sb.content_margin_left=14; sb.content_margin_right=14; sb.content_margin_top=10; sb.content_margin_bottom=10
    panel.add_theme_stylebox_override("panel", sb)
    var vbox = VBoxContainer.new(); panel.add_child(vbox)
    
    var h1 = HBoxContainer.new()
    var icone = Label.new(); icone.text=conquista.get("icone","🏆"); icone.add_theme_font_size_override("font_size",18)
    var nome = Label.new(); nome.text=conquista.get("nome",""); nome.add_theme_font_size_override("font_size",13)
    if desbloqueado: nome.add_theme_color_override("font_color", Color(0.77,1,0))
    var raridade = Label.new(); raridade.text=conquista.get("raridade",""); raridade.add_theme_font_size_override("font_size",9)
    if conquista.get("raridade","")=="Mítica": raridade.add_theme_color_override("font_color", Color(1,0.84,0))
    h1.add_child(icone); h1.add_child(nome); h1.add_child(raridade); vbox.add_child(h1)
    
    var desc = Label.new(); desc.text=conquista.get("descricao",""); desc.add_theme_font_size_override("font_size",11); desc.modulate=Color(0.8,0.85,0.9); desc.autowrap_mode=TextServer.AUTOWRAP_WORD
    vbox.add_child(desc)
    
    var detalhe = Label.new(); detalhe.text=conquista.get("detalhe",""); detalhe.add_theme_font_size_override("font_size",9); detalhe.modulate=Color(0.6,0.7,0.8); detalhe.autowrap_mode=TextServer.AUTOWRAP_WORD
    vbox.add_child(detalhe)
    
    var progresso = conquista.get("progresso_atual",0); var meta = conquista.get("meta",1)
    var barra_box = HBoxContainer.new()
    var progresso_label = Label.new(); progresso_label.text="%d/%d" % [progresso, meta]; progresso_label.add_theme_font_size_override("font_size",10)
    var barra = ProgressBar.new(); barra.max_value=meta; barra.value=progresso; barra.custom_minimum_size=Vector2(150,12); barra.size_flags_horizontal=Control.SIZE_EXPAND_FILL
    if desbloqueado: barra.modulate=Color(0.77,1,0)
    barra_box.add_child(progresso_label); barra_box.add_child(barra); vbox.add_child(barra_box)
    
    var recompensa = Label.new(); recompensa.text="Recompensa: €%d | %s | %s" % [conquista.get("recompensa",0), conquista.get("categoria",""), conquista.get("jogador_referencia","")]; recompensa.add_theme_font_size_override("font_size",9); recompensa.modulate=Color(0.5,0.7,0.5)
    vbox.add_child(recompensa)
    
    lista.add_child(panel)

func _on_filtro(raridade: String):
  filtro_raridade = raridade
  atualizar()
