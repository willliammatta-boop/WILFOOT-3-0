# EditarTimeUI.gd - Editor de equipe WILFOOT Engine 7.0
extends Control

@export var preview_camisa: ColorRect
@export var preview_estadio: Control

var dados_time: Dictionary = {
	"nome": "Sem Contrato - 19",
	"pais": "Afeganistão",
	"tecnico": "Zinedine Zidane",
	"pais_tec": "França",
	"estadio": "ESTADIO SIMU",
	"lugares": 11000,
	"nivel": 19,
	"reputacao": "Nacional",
	"cor_texto": Color(0, 0, 0),
	"cor_fundo": Color(1, 1, 1)
}

func _ready() -> void:
	_atualizar_preview()

func _on_nome_changed(novo: String) -> void:
	dados_time["nome"] = novo.strip_edges()
	_atualizar_preview()
	if novo.strip_edges().is_empty():
		_mostrar_erro("Nome não pode ser vazio")

func _on_cor_changed(tipo: String, cor: Color) -> void:
	if tipo == "texto":
		dados_time["cor_texto"] = cor
	else:
		dados_time["cor_fundo"] = cor
	_atualizar_preview()

func _atualizar_preview() -> void:
	var fundo: Color = _get_color("cor_fundo", Color.WHITE)
	var estadio: String = str(dados_time.get("estadio", "ESTADIO SIMU"))
	var lugares: int = int(dados_time.get("lugares", 11000))

	if is_instance_valid(preview_camisa):
		preview_camisa.color = fundo

	if is_instance_valid(preview_estadio):
		var label: Label = preview_estadio.get_node_or_null("Label") as Label
		if is_instance_valid(label):
			var bancadas: int = clampi(int(lugares / 5000.0), 1, 4)
			label.text = "🏟️ %s - %d lugares (%d bancadas)" % [estadio, lugares, bancadas]

func _on_gerar_aleatorio() -> void:
	var nomes: Array[String] = ["Real Cidreira", "Grêmio da Praia", "Inter Litoral", "Avenida FC", "WILFOOT United"]
	var tecnicos: Array[String] = ["Zidane", "Guardiola", "Tite", "Abel Ferreira", "Renato Gaúcho"]

	dados_time["nome"] = "%s - %d" % [nomes[randi_range(0, nomes.size() - 1)], randi_range(15, 22)]
	dados_time["tecnico"] = tecnicos[randi_range(0, tecnicos.size() - 1)]
	dados_time["lugares"] = randi_range(5000, 40000)
	dados_time["nivel"] = randi_range(14, 19)
	_atualizar_preview()
	_mostrar_toast("Time gerado aleatoriamente!")

func _mostrar_toast(msg: String) -> void:
	print("[TOAST] %s" % msg)

func _mostrar_erro(msg: String) -> void:
	printerr("[ERRO] %s" % msg)

func salvar() -> bool:
	var nome: String = str(dados_time.get("nome", "")).strip_edges()
	var safe_name: String = nome.to_lower().replace(" ", "_")
	if safe_name.is_empty():
		_mostrar_erro("Nome do time inválido")
		return false

	var path: String = "user://Data/time_%s.json" % safe_name
	DirAccess.make_dir_recursive_absolute("user://Data/")

	var arquivo: FileAccess = FileAccess.open(path, FileAccess.WRITE)
	if arquivo == null:
		_mostrar_erro("Não foi possível abrir o arquivo para salvar")
		return false

	var export_data: Dictionary = dados_time.duplicate(true)
	export_data["cor_texto"] = _get_color("cor_texto", Color.WHITE).to_html(true)
	export_data["cor_fundo"] = _get_color("cor_fundo", Color.WHITE).to_html(true)
	arquivo.store_string(JSON.stringify(export_data, "\t"))
	arquivo.close()
	_mostrar_toast("Salvo em %s" % path)
	return true

func _get_color(chave: String, padrao: Color) -> Color:
	var valor: Variant = dados_time.get(chave, padrao)
	if valor is Color:
		return valor as Color
	if valor is String:
		var convertido: Color = Color.from_string(str(valor), padrao)
		return convertido
	return padrao
