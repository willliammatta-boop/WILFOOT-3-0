# ElencoUI.gd - Tela 1 V2 Ultra - Lista de jogadores Sem Contrato
extends Control
class_name ElencoUI

signal jogador_selecionado(jogador: Dictionary)

@export var card_scene: PackedScene # opcional

var jogadores_originais: Array = []
var jogadores_filtrados: Array = []
var filtro_pos: String = "TODOS"
var filtro_extra: String = ""
var ordenacao: String = "OVR"
var busca: String = ""

@onready var lista: VBoxContainer = $MainVBox/Scroll/Lista
@onready var busca_input: LineEdit = $MainVBox/Header/Busca
@onready var filtros_box: HBoxContainer = $MainVBox/Filtros
@onready var stats_label: Label = $MainVBox/Header/Stats

func _ready():
	carregar_jogadores()
	_conectar_filtros()
	atualizar_lista()

func carregar_jogadores():
	var path = "res://Data/jogadores_sem_contrato.json"
	if not FileAccess.file_exists(path):
		jogadores_originais = []
		jogadores_filtrados = []
		return
	var f = FileAccess.open(path, FileAccess.READ)
	if f == null:
		jogadores_originais = []
		jogadores_filtrados = []
		return
	var j = JSON.new()
	var err = j.parse(f.get_as_text())
	f.close()
	if err != OK or typeof(j.data) != TYPE_ARRAY:
		jogadores_originais = []
		jogadores_filtrados = []
		return
	jogadores_originais = j.data
	for jogador in jogadores_originais:
		if typeof(jogador) == TYPE_DICTIONARY:
			_normalizar_jogador(jogador)
	jogadores_filtrados = jogadores_originais.duplicate()

func _conectar_filtros():
	if busca_input:
		busca_input.text_changed.connect(func(t): busca=t; _filtrar())
	for child in filtros_box.get_children():
		if child is Button:
			child.pressed.connect(_on_filtro.bind(child.text))

func _on_filtro(f: String):
	filtro_pos = f
	_filtrar()

func _normalizar_jogador(j: Dictionary) -> void:
	j["nome"] = str(j.get("nome", "Jogador"))
	j["pos"] = str(j.get("pos", "MC"))
	j["flag"] = str(j.get("flag", "🇧🇷"))
	j["idade"] = int(j.get("idade", 20))
	j["ovr"] = int(j.get("ovr", 60))
	j["valor"] = str(j.get("valor", "€0M"))
	j["star"] = bool(j.get("star", false))
	if typeof(j.get("attrs", [])) != TYPE_ARRAY:
		j["attrs"] = ["VEL", "FIN"]
	if j["attrs"].size() < 2:
		j["attrs"] = ["VEL", "FIN"]

func _filtrar():
	jogadores_filtrados = jogadores_originais.filter(func(j):
		var match_pos = filtro_pos=="TODOS" or _pos_match(str(j.get("pos", "MC")), filtro_pos)
		var match_busca = busca=="" or str(j.get("nome", "")).to_lower().contains(busca.to_lower())
		var match_extra = true
		if filtro_extra=="U23": match_extra = int(j.get("idade", 0))<=23
		elif filtro_extra=="+30": match_extra = int(j.get("idade", 0))>=30
		elif filtro_extra=="STAR": match_extra = bool(j.get("star", false))
		return match_pos and match_busca and match_extra
	)
	# Ordenação
	jogadores_filtrados.sort_custom(func(a,b):
		if ordenacao=="OVR": return int(a.get("ovr", 0)) > int(b.get("ovr", 0))
		elif ordenacao=="Idade": return int(a.get("idade", 0)) < int(b.get("idade", 0))
		elif ordenacao=="Valor": return str(a.get("valor", "")) > str(b.get("valor", ""))
		else: return str(a.get("nome", "")) < str(b.get("nome", ""))
	)
	atualizar_lista()

func _pos_match(pos: String, filtro: String) -> bool:
	if filtro=="G": return pos=="G"
	if filtro=="DEF": return pos in ["LD","LE","ZD","ZE"]
	if filtro=="MEI": return pos in ["ME","MD"]
	if filtro=="ATA": return pos in ["AD","AE"]
	return true

func atualizar_lista():
	if lista==null: return
	for c in lista.get_children(): c.queue_free()
	
	# Stats header
	var media_idade = 0
	var media_ovr = 0
	for j in jogadores_filtrados:
		media_idade+=int(j.get("idade", 20)); media_ovr+=int(j.get("ovr", 60))
	if jogadores_filtrados.size()>0:
		media_idade/=jogadores_filtrados.size()
		media_ovr/=jogadores_filtrados.size()
	if stats_label:
		stats_label.text = "👥 %d jogadores | ⭐ Média OVR %d | 📅 Idade %.1f | 💰 €%.1fM total" % [jogadores_filtrados.size(), int(media_ovr), media_idade, 81.8]
	
	for i in range(jogadores_filtrados.size()):
		var j = jogadores_filtrados[i]
		var card = _criar_card(j, i)
		lista.add_child(card)
		# anim stagger
		card.modulate.a=0
		var tw = create_tween()
		tw.tween_property(card, "modulate:a", 1.0, 0.25).set_delay(i*0.03)

func _criar_card(j: Dictionary, idx: int) -> Control:
	var panel = PanelContainer.new()
	panel.custom_minimum_size = Vector2(0, 84)
	var sb = StyleBoxFlat.new()
	sb.bg_color = Color(0.09,0.12,0.20) if idx%2==0 else Color(0.11,0.14,0.23)
	sb.corner_radius_top_left=12; sb.corner_radius_top_right=12; sb.corner_radius_bottom_left=12; sb.corner_radius_bottom_right=12
	sb.border_width_left=1; sb.border_width_top=1; sb.border_width_right=1; sb.border_width_bottom=1
	sb.border_color = Color(0.77,1,0,0.0)
	if bool(j.get("star", false)): sb.border_color = Color(1,0.84,0,0.4)
	panel.add_theme_stylebox_override("panel", sb)
	
	var hbox = HBoxContainer.new()
	hbox.add_theme_constant_override("separation", 10)
	panel.add_child(hbox)
	
	# Avatar inicial
	var avatar = Label.new()
	avatar.text = str(j.get("nome", "Jogador")).left(1) + str(j.get("nome", "Jogador")).split(" ")[-1].left(1) if " " in j.nome else str(j.get("nome", "Jogador")).left(2)
	avatar.custom_minimum_size = Vector2(44,44)
	avatar.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	avatar.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	var av_sb = StyleBoxFlat.new(); av_sb.bg_color = Color(0.18,0.22,0.35); av_sb.corner_radius_top_left=22; av_sb.corner_radius_top_right=22; av_sb.corner_radius_bottom_left=22; av_sb.corner_radius_bottom_right=22
	avatar.add_theme_stylebox_override("normal", av_sb)
	avatar.add_theme_font_size_override("font_size", 14)
	
	var vbox_info = VBoxContainer.new(); vbox_info.size_flags_horizontal=Control.SIZE_EXPAND_FILL
	var nome_row = HBoxContainer.new()
	var nome_l = Label.new(); nome_l.text = str(j.get("nome", "Jogador")); nome_l.add_theme_font_size_override("font_size",15)
	if bool(j.get("star", false)): 
		var star = Label.new(); star.text="⭐"; star.add_theme_font_size_override("font_size",12)
		nome_row.add_child(nome_l); nome_row.add_child(star)
	else:
		nome_row.add_child(nome_l)
	
	var sub = Label.new()
	sub.text = "%s • %s • %d anos • %s • %s" % [j.get("pos", "MC"), j.get("flag", "🇧🇷"), int(j.get("idade", 20)), str(j.get("attrs", ["VEL", "FIN"])[0])+"/"+str(j.get("attrs", ["VEL", "FIN"])[1]), j.get("valor", "€0M")]
	sub.add_theme_font_size_override("font_size",11)
	sub.modulate = Color(0.7,0.75,0.85)
	
	vbox_info.add_child(nome_row); vbox_info.add_child(sub)
	
	# OVR badge
	var ovr_box = VBoxContainer.new()
	var ovr_l = Label.new(); ovr_l.text=str(j.get("ovr", 60)); ovr_l.add_theme_font_size_override("font_size",20)
	ovr_l.add_theme_color_override("font_color", Color(0.77,1,0) if int(j.get("ovr", 60))>=75 else Color(1,1,1))
	ovr_l.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
	var ovr_t = Label.new(); ovr_t.text="OVR"; ovr_t.add_theme_font_size_override("font_size",9); ovr_t.modulate=Color(0.6,0.7,0.8)
	ovr_t.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
	ovr_box.add_child(ovr_l); ovr_box.add_child(ovr_t)
	
	hbox.add_child(avatar); hbox.add_child(vbox_info); hbox.add_child(ovr_box)
	
	# Clique expande radar
	panel.gui_input.connect(func(ev):
		if ev is InputEventScreenTouch and ev.pressed:
			emit_signal("jogador_selecionado", j)
			_expandir_card(panel, j)
	)
	
	return panel

func _expandir_card(card: Control, j: Dictionary):
	# Adiciona radar se não existe
	if card.get_child_count()>0 and card.get_child(0).get_child_count()>3:
		return # já expandido
	var radar = RadarChart.new()
	radar.custom_minimum_size = Vector2(0, 160)
	# Gera 5 atributos baseados no OVR + variação
	var ovr := int(j.get("ovr", 60))
	var vals = [ovr + randi()%10-5, ovr + randi()%10-5, ovr + randi()%8-4, ovr + randi()%8-4, ovr + randi()%12-6]
	radar.set_data(vals, j.get("attrs", ["VEL","FIN"]) + ["VEL","RES"])
	card.get_child(0).add_child(radar)
