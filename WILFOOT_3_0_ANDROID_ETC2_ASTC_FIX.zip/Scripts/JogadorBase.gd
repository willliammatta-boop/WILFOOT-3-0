extends Resource
class_name JogadorBase

# Sistema Categoria de Base Completo - Editável nome, overall, idade, etc

@export var id: String = ""
@export var nome: String = "Kayky Silva"
@export var idade: int = 16
@export var pos: String = "ME"
@export var ovr: int = 65
@export var potencial: int = 85
@export var pais: String = "Brasil"
@export var flag: String = "🇧🇷"
@export var altura: float = 1.75
@export var peso: int = 70
@export var pe: String = "Direito"
@export var personalidade: String = "Profissional"
@export var categoria: String = "Sub-17"
@export var contrato_ate: int = 2028
@export var salario: float = 2.5
@export var valor: float = 1.2
@export var atributos: Dictionary = {"VEL":60,"FIN":60,"PAS":60,"DRI":60,"DEF":60,"FIS":60}
@export var status: String = "Promissor"

func get_idade() -> int: return idade
func get_ovr() -> int: return ovr
func get_potencial() -> int: return potencial

func editar_nome(novo: String):
  if novo.length()>=2:
    nome = novo
    return true
  return false

func editar_idade(nova: int):
  if nova>=14 and nova<=23:
    idade = nova
    # Atualiza categoria automaticamente
    if idade<=15: categoria="Sub-15"
    elif idade<=17: categoria="Sub-17"
    else: categoria="Sub-20"
    return true
  return false

func editar_ovr(novo: int):
  if novo>=1 and novo<=99:
    ovr = novo
    if potencial < ovr: potencial = ovr
    valor = ovr * 0.05 + (potencial-ovr)*0.1
    return true
  return false

func editar_potencial(novo: int):
  if novo>=ovr and novo<=99:
    potencial = novo
    valor = ovr * 0.05 + (potencial-ovr)*0.1
    return true
  return false

func editar_pos(nova: String):
  var posicoes_validas = ["G","LD","LE","ZD","ZE","VOL","MC","ME","MD","AE","AD","ATA"]
  if nova in posicoes_validas:
    pos = nova
    return true
  return false

func editar_atributo(nome_attr: String, valor: int):
  if nome_attr in atributos and valor>=1 and valor<=99:
    atributos[nome_attr] = valor
    # Recalcula OVR baseado na média dos atributos
    var soma = 0
    for v in atributos.values(): soma+=v
    ovr = int(float(soma) / float(atributos.size()))
    return true
  return false

func promover_para_profissional() -> bool:
  if idade>=16 and ovr>=60:
    categoria = "Profissional"
    status = "Promovido"
    return true
  return false

func to_dict() -> Dictionary:
  return {
    "id":id,"nome":nome,"idade":idade,"pos":pos,"ovr":ovr,"potencial":potencial,
    "pais":pais,"flag":flag,"altura":altura,"peso":peso,"pe":pe,"personalidade":personalidade,
    "categoria":categoria,"contrato_ate":contrato_ate,"salario":salario,"valor":valor,
    "atributos":atributos,"status":status
  }

static func from_dict(d: Dictionary) -> JogadorBase:
  var j = JogadorBase.new()
  j.id=d.get("id",""); j.nome=d.get("nome","Kayky"); j.idade=d.get("idade",16)
  j.pos=d.get("pos","ME"); j.ovr=d.get("ovr",65); j.potencial=d.get("potencial",85)
  j.pais=d.get("pais","Brasil"); j.flag=d.get("flag","🇧🇷"); j.altura=d.get("altura",1.75)
  j.peso=d.get("peso",70); j.pe=d.get("pe","Direito"); j.personalidade=d.get("personalidade","Profissional")
  j.categoria=d.get("categoria","Sub-17"); j.contrato_ate=d.get("contrato_ate",2028)
  j.salario=d.get("salario",2.5); j.valor=d.get("valor",1.2); j.atributos=d.get("atributos",{"VEL":60,"FIN":60,"PAS":60,"DRI":60,"DEF":60,"FIS":60})
  j.status=d.get("status","Promissor")
  return j
