extends Resource
class_name JogadorReal

# Sistema Jogadores Reais com Títulos na Carteira - Mostra títulos conquistados outros anos

@export var id: String = ""
@export var nome: String = "Lionel Messi"
@export var idade: int = 38
@export var pos: String = "AD"
@export var time_atual: String = "Inter Miami"
@export var pais: String = "Argentina"
@export var flag: String = "🇦🇷"
@export var ovr: int = 88
@export var carteira_titulos: Array = []
@export var total_titulos: int = 0

func get_titulos_por_categoria(cat: String) -> Array:
  return carteira_titulos.filter(func(t): return t.get("categoria","")==cat)

func get_titulos_por_ano(ano: int) -> Array:
  return carteira_titulos.filter(func(t): return t.get("ano",0)==ano)

func get_titulos_por_competicao(comp: String) -> Array:
  return carteira_titulos.filter(func(t): return t.get("competicao","")==comp)

func adicionar_titulo(titulo: String, ano: int, time: String, competicao: String, categoria: String = "Clube"):
  var novo = {"titulo":titulo,"ano":ano,"time":time,"competicao":competicao,"categoria":categoria}
  carteira_titulos.append(novo)
  total_titulos += 1
  print("🏆 %s conquistou %s %d pelo %s" % [nome, titulo, ano, time])

func get_linha_do_tempo() -> Array:
  # Retorna títulos ordenados por ano decrescente (mais recente primeiro)
  var sorted = carteira_titulos.duplicate()
  sorted.sort_custom(func(a,b): return a.get("ano",0) > b.get("ano",0))
  return sorted

func get_resumo() -> String:
  var libertadores = get_titulos_por_competicao("Libertadores").size()
  var brasileirao = get_titulos_por_competicao("Brasileirão").size()
  var champions = get_titulos_por_competicao("UCL").size()
  var copa_mundo = get_titulos_por_competicao("Copa do Mundo").size()
  return "%d títulos | Libertadores %d | Brasileirão %d | UCL %d | Copa Mundo %d" % [total_titulos, libertadores, brasileirao, champions, copa_mundo]

func to_dict() -> Dictionary:
  return {"id":id,"nome":nome,"idade":idade,"pos":pos,"time_atual":time_atual,"pais":pais,"flag":flag,"ovr":ovr,"carteira_titulos":carteira_titulos,"total_titulos":total_titulos}

static func from_dict(d: Dictionary) -> JogadorReal:
  var j = JogadorReal.new()
  j.id=d.get("id",""); j.nome=d.get("nome",""); j.idade=d.get("idade",25)
  j.pos=d.get("pos","ATA"); j.time_atual=d.get("time_atual",""); j.pais=d.get("pais","Brasil")
  j.flag=d.get("flag","🇧🇷"); j.ovr=d.get("ovr",75); j.carteira_titulos=d.get("carteira_titulos",[]); j.total_titulos=d.get("total_titulos",0)
  return j
