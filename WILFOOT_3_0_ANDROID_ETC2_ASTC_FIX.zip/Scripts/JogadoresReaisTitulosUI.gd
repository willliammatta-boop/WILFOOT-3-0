extends Control
# UI Jogadores Reais com Carteira de Títulos

var jogadores: Array[JogadorReal] = []

@onready var lista: VBoxContainer = $MainVBox/Scroll/Lista
@onready var busca: LineEdit = $MainVBox/Header/Busca

func _ready():
  carregar_jogadores()
  atualizar()

func carregar_jogadores():
  var f = FileAccess.open("res://Data/jogadores_reais_titulos.json", FileAccess.READ)
  if f==null: return
  var j = JSON.new(); j.parse(f.get_as_text())
  for d in j.data:
    jogadores.append(JogadorReal.from_dict(d))

func atualizar():
  for c in lista.get_children(): c.queue_free()
  var filtrados = jogadores
  if busca and busca.text!="":
    var termo = busca.text.to_lower()
    filtrados = jogadores.filter(func(j): return j.nome.to_lower().contains(termo) or j.time_atual.to_lower().contains(termo))
  
  filtrados.sort_custom(func(a,b): return a.total_titulos>b.total_titulos)
  
  for jogador in filtrados:
    var panel = PanelContainer.new()
    var sb = StyleBoxFlat.new(); sb.bg_color=Color(0.09,0.12,0.20)
    sb.corner_radius_top_left=12; sb.corner_radius_top_right=12; sb.corner_radius_bottom_left=12; sb.corner_radius_bottom_right=12
    sb.border_color=Color(1,0.84,0,0.3) if jogador.total_titulos>=30 else Color(1,1,1,0.08)
    sb.border_width_left=1; sb.border_width_top=1; sb.border_width_right=1; sb.border_width_bottom=1
    sb.content_margin_left=14; sb.content_margin_right=14; sb.content_margin_top=10; sb.content_margin_bottom=10
    panel.add_theme_stylebox_override("panel", sb)
    var vbox = VBoxContainer.new(); panel.add_child(vbox)
    
    var h1 = HBoxContainer.new()
    var nome = Label.new(); nome.text="%s %s | %s %d anos | OVR %d | %s" % [jogador.flag, jogador.nome, jogador.pos, jogador.idade, jogador.ovr, jogador.time_atual]
    nome.add_theme_font_size_override("font_size",14)
    var total = Label.new(); total.text="🏆 %d títulos" % jogador.total_titulos; total.add_theme_color_override("font_color", Color(1,0.84,0))
    h1.add_child(nome); h1.add_child(total); vbox.add_child(h1)
    
    var resumo = Label.new(); resumo.text=jogador.get_resumo(); resumo.add_theme_font_size_override("font_size",10); resumo.modulate=Color(0.7,0.8,0.9)
    vbox.add_child(resumo)
    
    # Linha do tempo de títulos
    var linha_tempo = jogador.get_linha_do_tempo()
    for titulo in linha_tempo.slice(0,5):
      var t_label = Label.new()
      t_label.text="  %d - %s pelo %s (%s)" % [titulo.get("ano",0), titulo.get("titulo",""), titulo.get("time",""), titulo.get("competicao","")]
      t_label.add_theme_font_size_override("font_size",11)
      if titulo.get("competicao","")=="Copa do Mundo": t_label.add_theme_color_override("font_color", Color(1,0.84,0))
      elif titulo.get("competicao","")=="Libertadores" or titulo.get("competicao","")=="UCL": t_label.add_theme_color_override("font_color", Color(0.77,1,0))
      vbox.add_child(t_label)
    
    if linha_tempo.size()>5:
      var mais = Label.new(); mais.text="  +%d títulos anteriores..." % (linha_tempo.size()-5); mais.add_theme_font_size_override("font_size",9); mais.modulate=Color(0.5,0.6,0.7)
      vbox.add_child(mais)
    
    lista.add_child(panel)

func _on_busca_changed(txt: String):
  atualizar()
