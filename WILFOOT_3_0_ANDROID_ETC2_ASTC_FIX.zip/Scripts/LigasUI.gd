# LigasUI.gd - Tela 3 V2 - Importação premium
extends Control

var times: Array = []
var filtro_pais: String = "Todos"
var busca: String = ""

@onready var lista: VBoxContainer = $MainVBox/Scroll/Lista
@onready var busca_input: LineEdit = $MainVBox/Header/BuscaTime
@onready var drop_zone: PanelContainer = $MainVBox/DropZone

func _ready():
	_carregar_times()
	atualizar_lista()
	# Drag & Drop
	if drop_zone:
		drop_zone.gui_input.connect(_on_drop_gui)

func _carregar_times():
	# Mock baseado na foto 3
	times = [
		{"nome":"Sem Contrato - 19","nivel":19,"pais":"Mundo","flag":"🌍"},
		{"nome":"Sem Contrato - 18","nivel":18,"pais":"Mundo","flag":"🌍"},
		{"nome":"Mamelodi Sundowns","nivel":18,"pais":"África do Sul","flag":"🇿🇦"},
		{"nome":"Orlando Pirates","nivel":17,"pais":"África do Sul","flag":"🇿🇦"},
		{"nome":"Royal AM","nivel":17,"pais":"África do Sul","flag":"🇿🇦"},
		{"nome":"AmaZulu FC","nivel":16,"pais":"África do Sul","flag":"🇿🇦"},
		{"nome":"Cape Town City","nivel":16,"pais":"África do Sul","flag":"🇿🇦"},
		{"nome":"Kaizer Chiefs","nivel":16,"pais":"África do Sul","flag":"🇿🇦"},
		{"nome":"Stellenbosch","nivel":16,"pais":"África do Sul","flag":"🇿🇦"},
		{"nome":"SuperSport United","nivel":16,"pais":"África do Sul","flag":"🇿🇦"},
		{"nome":"TS Galaxy","nivel":14,"pais":"África do Sul","flag":"🇿🇦","selecionado":true},
	]

func atualizar_lista():
	for c in lista.get_children(): c.queue_free()
	var filtrados = times.filter(func(t): return busca=="" or t.nome.to_lower().contains(busca.to_lower()))
	for t in filtrados:
		var card = _criar_time_card(t)
		lista.add_child(card)

func _criar_time_card(t: Dictionary) -> Control:
	var panel = PanelContainer.new()
	panel.custom_minimum_size = Vector2(0,56)
	var sb = StyleBoxFlat.new()
	sb.bg_color = Color(0.16,0.24,0.14) if t.get("selecionado",false) else Color(0.09,0.12,0.20)
	sb.corner_radius_top_left=10; sb.corner_radius_top_right=10; sb.corner_radius_bottom_left=10; sb.corner_radius_bottom_right=10
	sb.border_color = Color(0.77,1,0,0.5) if t.get("selecionado",false) else Color(0,0,0,0)
	sb.border_width_left=1; sb.border_width_right=1; sb.border_width_top=1; sb.border_width_bottom=1
	panel.add_theme_stylebox_override("panel", sb)
	
	var hbox = HBoxContainer.new()
	hbox.add_theme_constant_override("separation",12)
	panel.add_child(hbox)
	
	var flag = Label.new(); flag.text=t.flag; flag.add_theme_font_size_override("font_size",18)
	var nome = Label.new(); nome.text=t.nome; nome.size_flags_horizontal=Control.SIZE_EXPAND_FILL; nome.add_theme_font_size_override("font_size",14)
	
	var nivel_badge = Label.new()
	nivel_badge.text=str(t.nivel)
	nivel_badge.custom_minimum_size=Vector2(32,32)
	nivel_badge.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
	nivel_badge.vertical_alignment=VERTICAL_ALIGNMENT_CENTER
	var nivel_sb = StyleBoxFlat.new()
	if t.nivel>=19: nivel_sb.bg_color=Color(1,0.84,0,1) # ouro
	elif t.nivel>=17: nivel_sb.bg_color=Color(0.8,0.8,0.8,1) # prata
	else: nivel_sb.bg_color=Color(0.8,0.5,0.2,1) # bronze
	nivel_sb.corner_radius_top_left=16; nivel_sb.corner_radius_top_right=16; nivel_sb.corner_radius_bottom_left=16; nivel_sb.corner_radius_bottom_right=16
	nivel_badge.add_theme_stylebox_override("normal", nivel_sb)
	nivel_badge.add_theme_color_override("font_color", Color(0,0,0))
	nivel_badge.add_theme_font_size_override("font_size",13)
	
	hbox.add_child(flag); hbox.add_child(nome); hbox.add_child(nivel_badge)
	return panel

func _on_busca_changed(txt: String):
	busca=txt; atualizar_lista()

func _on_drop_gui(ev):
	if ev is InputEventScreenTouch and ev.pressed:
		_importar_patch()

func _importar_patch():
	print("[WILFOOT] Abrindo seletor de arquivo .zip/.ban/.png")
	# No Godot real: FileDialog
	# Aqui simula
	var toast = "Patch importado! 3 times adicionados"
	print(toast)

func _on_atualizar_liga():
	print("Atualizando liga via Transfermarkt API...")

func _on_resetar():
	print("Resetando elencos para original")
