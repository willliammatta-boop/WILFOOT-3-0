extends Control
# WILFOOT 2026 ATUALIZADO - Patrocinadores reais + Premiações com aumento CBF 2026

func _ready():
  print("WILFOOT 2026 ATUALIZADO - Flamengo Betano R$268M, Pixbet R$125M 2026, Adidas R$69M - Camisa R$225,8M total")
  print("Premiações CBF 2026 +5% - Brasileirão campeão R$52M, Copa do Brasil R$80M")
