# MainV2.gd - Controlador de abas V2
extends Control

@onready var tabs: TabContainer = $TabContainer

func _ready():
	# Conecta abas
	print("[WILFOOT V2] Iniciado - 3 telas premium carregadas")
	if tabs:
		tabs.tab_changed.connect(func(idx): print("Aba trocada para %d" % idx))

func _on_elenco_selecionado(jogador: Dictionary):
	print("[V2] Jogador selecionado: %s - OVR %d" % [jogador.nome, jogador.ovr])
