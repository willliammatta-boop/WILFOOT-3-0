extends Node
## WILFOOT - perfil gráfico Android otimizado para aparelhos como Moto G54.
## Mantém GL Compatibility/GLES3 e evita cargas gráficas desnecessárias.

const TARGET_FPS: int = 60

func _ready() -> void:
    if OS.has_feature("android"):
        Engine.max_fps = TARGET_FPS
        DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_ENABLED)
        # Mantém o jogo responsivo sem forçar processamento de física acima do necessário.
        Engine.physics_ticks_per_second = 60
