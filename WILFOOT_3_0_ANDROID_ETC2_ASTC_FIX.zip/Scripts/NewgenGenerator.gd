extends Resource
class_name NewgenGenerator

# Sistema de Newgens Anual - Gera safra nova todo ano igual Football Manager

var estrutura: String = "3 - Boa"
var ano_atual: int = 2026

var nomes_br = ["Kayky","Endrick","Estevão","Luis Guilherme","Vitor Roque","Marcos Leonardo","Ângelo","Sávio","Andrey Santos","Matheus França","Lorran","Wesley","Rayan","Cauan","Kauã","Davi","Miguel","Arthur","Heitor","Theo","Gael","Breno","Enzo","Lorenzo","Riquelme","Kauan","Ryan","Petterson","Giovanni","Marquinhos"]
var sobrenomes = ["Silva","Santos","Oliveira","Souza","Pereira","Lima","Costa","Rodrigues","Almeida","Nascimento","Araújo","Melo","Barbosa","Ribeiro","Martins","Carvalho","Rocha","Freitas","Mendes","Fernandes","Gomes","Cavalcanti","Dias","Monteiro"]

var posicoes = ["G","LD","LE","ZD","ZE","VOL","MC","ME","MD","AE","AD","ATA"]

func gerar_safra_anual(ano: int, estrutura_nivel: String = "3 - Boa") -> Array[JogadorBase]:
  ano_atual = ano
  estrutura = estrutura_nivel
  
  var config = {
    "1 - Precária": {"qtd":2,"ovr_min":40,"ovr_max":60,"pot_max":75,"chance_wonder":0.01},
    "2 - Básica": {"qtd":4,"ovr_min":45,"ovr_max":65,"pot_max":82,"chance_wonder":0.03},
    "3 - Boa": {"qtd":6,"ovr_min":50,"ovr_max":70,"pot_max":86,"chance_wonder":0.06},
    "4 - Excelente": {"qtd":8,"ovr_min":55,"ovr_max":75,"pot_max":90,"chance_wonder":0.10},
    "5 - Estado da Arte": {"qtd":10,"ovr_min":60,"ovr_max":80,"pot_max":95,"chance_wonder":0.15}
  }
  
  var cfg = config.get(estrutura, config["3 - Boa"])
  var novos: Array[JogadorBase] = []
  
  for i in range(cfg.qtd):
    var j = JogadorBase.new()
    j.nome = "%s %s" % [nomes_br[randi()%nomes_br.size()], sobrenomes[randi()%sobrenomes.size()]]
    j.id = "newgen_%d_%d" % [ano, i]
    j.idade = [15,16,17][randi()%3]
    j.pos = posicoes[randi()%posicoes.size()]
    j.ovr = randi_range(cfg.ovr_min, cfg.ovr_max)
    
    # Chance de wonderkid
    var is_wonder = randf() < cfg.chance_wonder
    if is_wonder:
      j.potencial = randi_range(88, cfg.pot_max)
      j.status = "Wonderkid"
    else:
      j.potencial = randi_range(j.ovr+5, cfg.pot_max)
      j.status = "Promissor"
    
    j.categoria = "Sub-15" if j.idade<=15 else ("Sub-17" if j.idade<=17 else "Sub-20")
    j.pais = "Brasil"
    j.flag = "🇧🇷"
    j.contrato_ate = ano + randi_range(2,4)
    j.salario = randf_range(0.5, 3.0)
    j.valor = j.ovr * 0.05 + (j.potencial-j.ovr)*0.1
    j.personalidade = ["Profissional","Ambicioso","Equilibrado","Determinado"][randi()%4]
    
    # Atributos baseados no potencial
    for attr in j.atributos.keys():
      j.atributos[attr] = randi_range(j.ovr-10, j.ovr+10)
    
    novos.append(j)
  
  print("[NEWGENS %d] Gerados %d novos talentos - Estrutura %s - %d wonderkids" % [ano, novos.size(), estrutura, novos.filter(func(x): return x.status=="Wonderkid").size()])
  return novos

func gerar_nome_realista() -> String:
  return "%s %s" % [nomes_br[randi()%nomes_br.size()], sobrenomes[randi()%sobrenomes.size()]]
