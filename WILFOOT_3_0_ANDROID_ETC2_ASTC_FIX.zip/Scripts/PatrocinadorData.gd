extends Resource
class_name PatrocinadorData
@export var id: String = ""
@export var nome: String = "Emirates"
@export var categoria: String = "Master"
@export var valor_ano: float = 10.0
@export var anos: int = 3
@export var bonus_titulo: float = 1.0
@export var exigencia: String = "Top 4"
@export var cor_hex: String = "#FF0000"
@export var ativo: bool = true
var cor: Color:
  get: return Color(cor_hex)
var logo_inicial: String:
  get: return nome.left(1).to_upper()
func get_valor_total() -> float: return valor_ano*anos
func to_dict() -> Dictionary:
  return {"id":id,"nome":nome,"categoria":categoria,"valor_ano":valor_ano,"anos":anos,"bonus_titulo":bonus_titulo,"exigencia":exigencia,"cor":cor_hex,"ativo":ativo}
static func from_dict(d: Dictionary) -> PatrocinadorData:
  var p = PatrocinadorData.new()
  p.id=d.get("id",""); p.nome=d.get("nome",""); p.categoria=d.get("categoria","Master")
  p.valor_ano=d.get("valor_ano",0.0); p.anos=d.get("anos",1)
  p.bonus_titulo=d.get("bonus_titulo",0.0); p.exigencia=d.get("exigencia","")
  p.cor_hex=d.get("cor","#FF0000"); p.ativo=d.get("ativo",false)
  return p
static func get_marcas_disponiveis() -> Array:
  return ["Nike","Adidas","Puma","Emirates","Qatar Airways","Etihad Airways","Heineken","Coca-Cola","Red Bull","Spotify","Allianz","Rakuten"]
