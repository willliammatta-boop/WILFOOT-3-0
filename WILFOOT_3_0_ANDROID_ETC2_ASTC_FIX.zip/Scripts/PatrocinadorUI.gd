extends Control
var patrocinadores: Array[PatrocinadorData] = []
var filtro_cat: String = "TODOS"
@onready var lista: VBoxContainer = $MainVBox/Scroll/Lista
@onready var total_label: Label = $MainVBox/Header/TotalLabel
func _ready():
  carregar_patrocinadores()
  atualizar_ui()
func carregar_patrocinadores():
  var f = FileAccess.open("res://Data/patrocinadores_reais.json", FileAccess.READ)
  if f==null: return
  var j = JSON.new(); j.parse(f.get_as_text())
  for d in j.data: patrocinadores.append(PatrocinadorData.from_dict(d))
func atualizar_ui():
  for c in lista.get_children(): c.queue_free()
  var total = 0.0
  for p in patrocinadores:
    if p.ativo: total+=p.valor_ano
  if total_label: total_label.text = "💰 €%.1fM / temporada | %d ativos" % [total, patrocinadores.filter(func(x): return x.ativo).size()]
  var filtrados = patrocinadores.filter(func(p): return filtro_cat=="TODOS" or p.categoria==filtro_cat)
  for i in range(filtrados.size()):
    lista.add_child(_criar_card(filtrados[i]))
func _criar_card(p: PatrocinadorData) -> Control:
  var panel = PanelContainer.new(); panel.custom_minimum_size=Vector2(0,96)
  var sb = StyleBoxFlat.new(); sb.bg_color=Color(0.09,0.12,0.20)
  sb.corner_radius_top_left=12; sb.corner_radius_top_right=12; sb.corner_radius_bottom_left=12; sb.corner_radius_bottom_right=12
  sb.border_color = Color(0.77,1,0,0.6) if p.ativo else Color(1,1,1,0.08)
  sb.border_width_left=1; sb.border_width_top=1; sb.border_width_right=1; sb.border_width_bottom=1
  sb.content_margin_left=12; sb.content_margin_right=12; sb.content_margin_top=10; sb.content_margin_bottom=10
  panel.add_theme_stylebox_override("panel", sb)
  var hbox = HBoxContainer.new(); hbox.add_theme_constant_override("separation",12); panel.add_child(hbox)
  var logo = Label.new(); logo.text=p.logo_inicial; logo.custom_minimum_size=Vector2(48,48)
  logo.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; logo.vertical_alignment=VERTICAL_ALIGNMENT_CENTER
  var logo_sb = StyleBoxFlat.new(); logo_sb.bg_color=p.cor; logo_sb.corner_radius_top_left=24; logo_sb.corner_radius_top_right=24; logo_sb.corner_radius_bottom_left=24; logo_sb.corner_radius_bottom_right=24
  logo.add_theme_stylebox_override("normal", logo_sb)
  logo.add_theme_color_override("font_color", Color(1,1,1) if p.cor.get_luminance()<0.6 else Color(0,0,0))
  var vbox = VBoxContainer.new(); vbox.size_flags_horizontal=Control.SIZE_EXPAND_FILL
  var nome = Label.new(); nome.text=p.nome
  var detalhes = Label.new(); detalhes.text="€%.1fM/ano • %d anos • Bônus €%.1fM • %s" % [p.valor_ano, p.anos, p.bonus_titulo, p.exigencia]
  detalhes.modulate=Color(0.7,0.75,0.85); detalhes.add_theme_font_size_override("font_size",11)
  vbox.add_child(nome); vbox.add_child(detalhes)
  var btn = Button.new(); btn.text="✏️"; btn.custom_minimum_size=Vector2(36,36)
  btn.pressed.connect(func(): p.valor_ano+=1.0; atualizar_ui(); salvar())
  hbox.add_child(logo); hbox.add_child(vbox); hbox.add_child(btn)
  return panel
func salvar():
  DirAccess.make_dir_recursive_absolute("user://Data/")
  var f = FileAccess.open("user://Data/patrocinadores_editados.json", FileAccess.WRITE)
  f.store_string(JSON.stringify(patrocinadores.map(func(p): return p.to_dict()), "\t"))
  f.close()
