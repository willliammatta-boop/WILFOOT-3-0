extends Resource
class_name PreferenciasManager

# Sistema Preferência Completo - Salva tudo em user://preferencias.json

var preferencias: Dictionary = {}
var path_save: String = "user://preferencias.json"

func _init():
  carregar()

func carregar():
  if FileAccess.file_exists(path_save):
    preferencias = _ler_json_dict(path_save)
    if not preferencias.is_empty():
      print("⚙️ Preferências carregadas")
      return
  preferencias = _ler_json_dict("res://Data/preferencias_completo.json")
  if not preferencias.is_empty():
    print("⚙️ Preferências padrão carregadas")
    salvar()

# Lê um JSON e sempre devolve um Dictionary (nunca null), mesmo se o arquivo
# não existir, não abrir, ou estiver corrompido.
func _ler_json_dict(path: String) -> Dictionary:
  var f = FileAccess.open(path, FileAccess.READ)
  if f == null:
    push_error("PreferenciasManager: não foi possível abrir %s" % path)
    return {}
  var texto = f.get_as_text()
  f.close()
  var j = JSON.new()
  var err = j.parse(texto)
  if err != OK:
    push_error("PreferenciasManager: JSON inválido em %s: %s" % [path, j.get_error_message()])
    return {}
  if typeof(j.data) != TYPE_DICTIONARY:
    return {}
  return j.data

func salvar():
  DirAccess.make_dir_recursive_absolute("user://")
  var f = FileAccess.open(path_save, FileAccess.WRITE)
  if f == null:
    push_error("PreferenciasManager: falha ao salvar preferências")
    return
  f.store_string(JSON.stringify(preferencias, "\t"))
  f.close()
  print("⚙️ Preferências salvas em %s" % path_save)

func get_value(caminho: String):
  # caminho tipo "jogo.dificuldade" ou "audio.volume_master"
  var partes = caminho.split(".")
  var atual = preferencias
  for parte in partes:
    if atual.has(parte):
      atual = atual[parte]
    else:
      return null
  return atual

func set_value(caminho: String, valor):
  var partes = caminho.split(".")
  var atual = preferencias
  for i in range(partes.size()-1):
    var parte = partes[i]
    if not atual.has(parte):
      atual[parte] = {}
    atual = atual[parte]
  atual[partes[partes.size()-1]] = valor
  salvar()
  print("⚙️ Preferência %s = %s" % [caminho, valor])

func resetar():
  var padrao = _ler_json_dict("res://Data/preferencias_completo.json")
  if not padrao.is_empty():
    preferencias = padrao
    salvar()
    print("⚙️ Preferências resetadas para padrão")

func aplicar_video():
  var resolucao = get_value("video.resolucao")
  var fullscreen = get_value("video.fullscreen")
  var vsync = get_value("video.vsync")
  print("🎮 Aplicando vídeo: %s fullscreen=%s vsync=%s" % [resolucao, fullscreen, vsync])
  # DisplayServer.window_set_mode etc

func aplicar_audio():
  var master = get_value("audio.volume_master")
  var musica = get_value("audio.volume_musica")
  var efeitos = get_value("audio.volume_efeitos")
  print("🔊 Áudio master %d música %d efeitos %d" % [master, musica, efeitos])
  # AudioServer.set_bus_volume_db etc
