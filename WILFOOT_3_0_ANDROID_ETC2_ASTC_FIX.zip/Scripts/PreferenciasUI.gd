extends Control
# UI Preferências Completo + Save Game

var pref_manager: PreferenciasManager = PreferenciasManager.new()
var save_manager: SaveGameManager = SaveGameManager.new()

@onready var lista: VBoxContainer = $MainVBox/TabContainer/Preferencias/Scroll/Lista
@onready var lista_saves: VBoxContainer = $MainVBox/TabContainer/Saves/Scroll/ListaSaves

func _ready():
  atualizar_preferencias()
  atualizar_saves()

func atualizar_preferencias():
  for c in lista.get_children(): c.queue_free()
  
  for categoria in pref_manager.preferencias.keys():
    var header = Label.new(); header.text="⚙️ %s" % categoria.to_upper(); header.add_theme_font_size_override("font_size",16); header.add_theme_color_override("font_color", Color(0.77,1,0))
    lista.add_child(header)
    
    var dados_cat = pref_manager.preferencias[categoria]
    for chave in dados_cat.keys():
      if typeof(dados_cat[chave])==TYPE_ARRAY: continue # pula arrays de opções
      var hbox = HBoxContainer.new()
      var label = Label.new(); label.text="%s: %s" % [chave, str(dados_cat[chave])]; label.size_flags_horizontal=Control.SIZE_EXPAND_FILL; label.add_theme_font_size_override("font_size",11)
      var btn_edit = Button.new(); btn_edit.text="✏️ Editar"; btn_edit.add_theme_font_size_override("font_size",10)
      btn_edit.pressed.connect(func(): _editar_preferencia("%s.%s" % [categoria, chave], dados_cat[chave]))
      hbox.add_child(label); hbox.add_child(btn_edit)
      lista.add_child(hbox)

func _editar_preferencia(caminho: String, valor_atual):
  # Simula edição - alterna boolean ou muda valor
  if typeof(valor_atual)==TYPE_BOOL:
    pref_manager.set_value(caminho, !valor_atual)
  elif typeof(valor_atual)==TYPE_INT:
    pref_manager.set_value(caminho, valor_atual+10 if valor_atual<100 else 0)
  elif typeof(valor_atual)==TYPE_STRING:
    if caminho.contains("dificuldade"):
      var opcoes = ["Fácil","Normal","Difícil","Lendário"]
      var idx = opcoes.find(valor_atual)
      pref_manager.set_value(caminho, opcoes[(idx+1)%opcoes.size()])
  atualizar_preferencias()

func atualizar_saves():
  for c in lista_saves.get_children(): c.queue_free()
  
  for i in range(1,6):
    var info = save_manager.get_info_slot(i)
    var panel = PanelContainer.new()
    var sb = StyleBoxFlat.new()
    sb.bg_color=Color(0.09,0.12,0.20) if info.get("existe",false) else Color(0.05,0.07,0.12)
    sb.corner_radius_top_left=12; sb.corner_radius_top_right=12; sb.corner_radius_bottom_left=12; sb.corner_radius_bottom_right=12
    sb.border_color=Color(0.77,1,0,0.3) if info.get("existe",false) else Color(1,1,1,0.06)
    sb.border_width_left=1; sb.content_margin_left=14; sb.content_margin_right=14; sb.content_margin_top=10; sb.content_margin_bottom=10
    panel.add_theme_stylebox_override("panel", sb)
    var vbox = VBoxContainer.new(); panel.add_child(vbox)
    
    if info.get("existe",false):
      var h1 = HBoxContainer.new()
      var nome = Label.new(); nome.text="💾 Slot %d - %s" % [i, info.get("nome","")]; nome.add_theme_font_size_override("font_size",13)
      var data = Label.new(); data.text=info.get("data",""); data.add_theme_font_size_override("font_size",9); data.modulate=Color(0.6,0.7,0.8)
      h1.add_child(nome); h1.add_child(data); vbox.add_child(h1)
      var detalhes = Label.new(); detalhes.text="Time: %s | Temporada: %d | Dinheiro: €%dM | Títulos: %d" % [info.get("time",""), info.get("temporada",2026), info.get("dinheiro",0), info.get("titulos",0)]; detalhes.add_theme_font_size_override("font_size",10)
      vbox.add_child(detalhes)
      var h2 = HBoxContainer.new()
      var btn_carregar = Button.new(); btn_carregar.text="📂 Carregar"; btn_carregar.add_theme_font_size_override("font_size",10)
      btn_carregar.pressed.connect(func(): _carregar_slot(i))
      var btn_deletar = Button.new(); btn_deletar.text="🗑️ Deletar"; btn_deletar.add_theme_font_size_override("font_size",10)
      btn_deletar.pressed.connect(func(): save_manager.deletar_jogo(i); atualizar_saves())
      h2.add_child(btn_carregar); h2.add_child(btn_deletar); vbox.add_child(h2)
    else:
      var vazio = Label.new(); vazio.text="📭 Slot %d - Vazio" % i; vazio.modulate=Color(0.5,0.6,0.7)
      var btn_salvar = Button.new(); btn_salvar.text="💾 Salvar Novo Jogo Aqui"; btn_salvar.add_theme_font_size_override("font_size",10)
      btn_salvar.pressed.connect(func(): _salvar_slot(i))
      vbox.add_child(vazio); vbox.add_child(btn_salvar)
    
    lista_saves.add_child(panel)

func _salvar_slot(slot: int):
  var dados_exemplo = {
    "nome_carreira": "Carreira %d - %s" % [slot, Time.get_datetime_string_from_system()],
    "time_escolhido": "Flamengo",
    "temporada_atual": 2026,
    "dinheiro": 100,
    "total_titulos": 5,
    "preferencias": pref_manager.preferencias
  }
  save_manager.salvar_jogo(slot, dados_exemplo)
  atualizar_saves()

func _carregar_slot(slot: int):
  var dados = save_manager.carregar_jogo(slot)
  print("Carregado: ", dados.get("nome_carreira",""))

func _on_resetar():
  pref_manager.resetar()
  atualizar_preferencias()
