extends Resource
class_name Premiacao2026Data

# Premiações REAIS 2026 - Principais ligas e torneios
# Fontes: CBF, CONMEBOL, UEFA, Premier League

static func get_premiacoes() -> Dictionary:
  return {
    "Brasileirão": {"1º": 52.0, "2º": 49.5, "16º": 17.5, "moeda": "R$ M", "fonte": "CBF 48.1M em 2024"},
    "Copa do Brasil": {"campeao": 80.0, "vice": 35.0, "total_max": 110.0, "moeda": "R$ M", "fonte": "CBF 77.175M em 2025"},
    "Libertadores": {"campeao": 26.0, "vice": 7.5, "moeda": "US$ M", "conversao_BRL": 145.0, "fonte": "CONMEBOL US$24M em 2025"},
    "Premier League": {"campeao": 178.0, "lanterna": 112.0, "por_posicao": 3.76, "moeda": "£ M", "fonte": "PL £96.9M equal + £53.1M merit"},
    "Champions League": {"participacao": 18.62, "campeao_total": 110.0, "moeda": "€ M", "fonte": "UEFA €2.5bn total"}
  }

static func calcular_brasileirao(pos: int) -> float:
  var tabela = [52.0,49.5,47.0,44.5,42.0,39.5,37.0,34.5,32.0,29.5,27.0,24.5,22.0,19.5,18.0,17.5]
  if pos>=1 and pos<=16: return tabela[pos-1]
  return 0.0

static func calcular_premier(pos: int) -> float:
  # £3.76M por posição de diferença【523600931007870301†L62-L65】
  return 178.0 - (pos-1)*3.76
