extends Resource
class_name PremiacaoData
@export var competicao: String = "Brasileirão Série A"
@export var campeao: float = 25.0
@export var vice: float = 12.0
@export var semi: float = 0.0
@export var quartas: float = 0.0
@export var participacao: float = 3.0
@export var vitoria: float = 0.5
@export var empate: float = 0.15
func get_total_maximo() -> float: return campeao+participacao
func to_dict() -> Dictionary: return {"campeao":campeao,"vice":vice,"semi":semi,"quartas":quartas,"participacao":participacao,"vitoria":vitoria,"empate":empate}
static func from_dict(nome: String, d: Dictionary) -> PremiacaoData:
  var p = PremiacaoData.new(); p.competicao=nome; p.campeao=d.get("campeao",0.0); p.vice=d.get("vice",0.0); p.semi=d.get("semi",0.0); p.quartas=d.get("quartas",0.0); p.participacao=d.get("participacao",0.0); p.vitoria=d.get("vitoria",0.0); p.empate=d.get("empate",0.0); return p
func calcular_por_posicao(pos: int) -> float:
  match pos:
    1: return campeao+participacao
    2: return vice+participacao
    3,4: return participacao+ (2.0 if semi==0 else semi)
    _: return participacao
