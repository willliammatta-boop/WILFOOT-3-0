extends Control
var premiacoes: Dictionary = {}
@onready var lista: VBoxContainer = $MainVBox/Scroll/Lista
func _ready():
  carregar_premiacoes()
  atualizar_lista()
func carregar_premiacoes():
  var f = FileAccess.open("res://Data/premiacoes.json", FileAccess.READ)
  if f==null: return
  var j = JSON.new(); j.parse(f.get_as_text())
  for comp in j.data.keys(): premiacoes[comp]=PremiacaoData.from_dict(comp, j.data[comp])
func atualizar_lista():
  for c in lista.get_children(): c.queue_free()
  for comp in premiacoes.keys():
    lista.add_child(_criar_card(premiacoes[comp]))
func _criar_card(p: PremiacaoData) -> Control:
  var panel = PanelContainer.new()
  var sb = StyleBoxFlat.new(); sb.bg_color=Color(0.09,0.12,0.20); sb.corner_radius_top_left=12; sb.corner_radius_top_right=12; sb.corner_radius_bottom_left=12; sb.corner_radius_bottom_right=12
  sb.content_margin_left=14; sb.content_margin_right=14; sb.content_margin_top=12; sb.content_margin_bottom=12
  panel.add_theme_stylebox_override("panel", sb)
  var vbox = VBoxContainer.new(); panel.add_child(vbox)
  var header = HBoxContainer.new()
  var titulo = Label.new(); titulo.text="🏆 %s" % p.competicao; titulo.size_flags_horizontal=Control.SIZE_EXPAND_FILL
  var total = Label.new(); total.text="Max €%.1fM" % p.get_total_maximo(); total.add_theme_color_override("font_color", Color(0.77,1,0))
  header.add_child(titulo); header.add_child(total); vbox.add_child(header)
  var grid = GridContainer.new(); grid.columns=2; vbox.add_child(grid)
  var campos = [["Campeão","campeao"],["Vice","vice"],["Semi","semi"],["Quartas","quartas"],["Participação","participacao"],["Vitória","vitoria"],["Empate","empate"]]
  for campo in campos:
    var label = Label.new(); label.text=campo[0]; label.modulate=Color(0.7,0.8,0.9); label.add_theme_font_size_override("font_size",11)
    var input = SpinBox.new(); input.min_value=0; input.max_value=100; input.step=0.1; input.value=p.get(campo[1]); input.custom_minimum_size=Vector2(100,0)
    input.value_changed.connect(func(v): p.set(campo[1], v); salvar())
    grid.add_child(label); grid.add_child(input)
  return panel
func salvar():
  DirAccess.make_dir_recursive_absolute("user://Data/")
  var dict = {}
  for comp in premiacoes.keys(): dict[comp]=premiacoes[comp].to_dict()
  var f = FileAccess.open("user://Data/premiacoes_editadas.json", FileAccess.WRITE)
  f.store_string(JSON.stringify(dict, "\t")); f.close()
