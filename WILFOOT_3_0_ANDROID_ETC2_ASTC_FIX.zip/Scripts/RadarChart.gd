# RadarChart.gd - Gráfico radar puro em Godot para WILFOOT V2
extends Control
class_name RadarChart

var atributos: Array = [70, 75, 80, 65, 72] # 5 attrs: 0-100
var labels: Array = ["COL","REF","DPE","MAR","VEL"]
var cor_fundo: Color = Color(0.77, 1, 0, 0.25)
var cor_linha: Color = Color(0.77, 1, 0, 1)

func set_data(vals: Array, labs: Array = []):
	atributos = vals
	if labs.size()>0: labels = labs
	queue_redraw()

func _draw():
	var center = size/2.0
	var raio = min(size.x, size.y) * 0.38
	var n = atributos.size()
	if n==0: return
	
	# Grade de fundo (3 níveis)
	for r in [0.33, 0.66, 1.0]:
		var pontos = PackedVector2Array()
		for i in range(n):
			var ang = deg_to_rad(-90 + i*360.0/n)
			var v = atributos[i]/100.0 * raio * r
			pontos.append(center + Vector2(cos(ang), sin(ang))*raio*r)
		pontos.append(pontos[0])
		draw_polyline(pontos, Color(1,1,1,0.08), 1.0)
	
	# Eixos
	for i in range(n):
		var ang = deg_to_rad(-90 + i*360.0/n)
		draw_line(center, center + Vector2(cos(ang), sin(ang))*raio, Color(1,1,1,0.1), 1.0)
	
	# Polígono de atributos
	var poly = PackedVector2Array()
	for i in range(n):
		var ang = deg_to_rad(-90 + i*360.0/n)
		var v = clamp(atributos[i]/100.0, 0, 1) * raio
		poly.append(center + Vector2(cos(ang), sin(ang))*v)
	draw_colored_polygon(poly, cor_fundo)
	var poly_line = poly.duplicate()
	poly_line.append(poly[0])
	draw_polyline(poly_line, cor_linha, 2.5, true)
	
	# Pontos
	for p in poly:
		draw_circle(p, 4, cor_linha)
		draw_circle(p, 2, Color(0,0,0))
