# WILFOOT - RodadaData.gd
# Versao robusta para Godot 4.7.x.
# Mantem os dados de rodada como Dictionary para evitar dependencias de classes internas.
extends Resource
class_name RodadaData

@export var rodada_numero: int = 12
@export var temporada: int = 2026
@export var ultima_atualizacao: String = ""
@export var partida_principal: Dictionary = {}

var jogos_por_divisao: Dictionary = {}

func _init() -> void:
    if partida_principal.is_empty():
        partida_principal = _nova_partida("WILFOOT FC", "Rival FC", "Principal")
    ultima_atualizacao = Time.get_datetime_string_from_system()

static func _nova_time(nome: String, ataque: int = 70, defesa: int = 70) -> Dictionary:
    return {
        "nome": nome,
        "forca_ataque": clampi(ataque, 30, 99),
        "forca_defesa": clampi(defesa, 30, 99),
        "forma": randf_range(0.85, 1.15),
        "escudo_path": "",
        "divisao": ""
    }

static func _nova_partida(casa: String, fora: String, divisao: String = "Serie A") -> Dictionary:
    return {
        "id": "%s_vs_%s_%d" % [casa, fora, Time.get_ticks_msec()],
        "casa": _nova_time(casa),
        "fora": _nova_time(fora),
        "gols_casa": 0,
        "gols_fora": 0,
        "estadio": "Maracana",
        "divisao": divisao,
        "finalizado": false,
        "eventos": []
    }

static func _normalizar_partida(dados: Dictionary, divisao_padrao: String = "Serie A") -> Dictionary:
    var casa_raw = dados.get("casa", "")
    var fora_raw = dados.get("fora", "")
    var casa_nome = str(casa_raw.get("nome", "")) if casa_raw is Dictionary else str(casa_raw)
    var fora_nome = str(fora_raw.get("nome", "")) if fora_raw is Dictionary else str(fora_raw)
    var partida = _nova_partida(casa_nome, fora_nome, str(dados.get("divisao", divisao_padrao)))

    if casa_raw is Dictionary:
        partida["casa"] = casa_raw.duplicate(true)
    if fora_raw is Dictionary:
        partida["fora"] = fora_raw.duplicate(true)

    partida["id"] = str(dados.get("id", partida["id"]))
    partida["gols_casa"] = int(dados.get("gols_casa", 0))
    partida["gols_fora"] = int(dados.get("gols_fora", 0))
    partida["estadio"] = str(dados.get("estadio", "Maracana"))
    partida["finalizado"] = bool(dados.get("finalizado", true))
    partida["eventos"] = dados.get("eventos", []) if dados.get("eventos", []) is Array else []

    var placar = str(dados.get("placar", ""))
    if placar.contains(" x "):
        var partes = placar.split(" x ")
        if partes.size() == 2:
            partida["gols_casa"] = int(partes[0])
            partida["gols_fora"] = int(partes[1])

    return partida

static func from_json_dict(json: Dictionary) -> RodadaData:
    var rodada := RodadaData.new()
    rodada.rodada_numero = int(json.get("rodada_numero", json.get("rodada", 12)))
    rodada.temporada = int(json.get("temporada", 2026))
    rodada.ultima_atualizacao = str(json.get("ultima_atualizacao", Time.get_datetime_string_from_system()))

    if json.get("partida_principal") is Dictionary:
        rodada.partida_principal = _normalizar_partida(json["partida_principal"], "Principal")

    var jogos_raw = json.get("jogos_da_rodada", {})
    if jogos_raw is Dictionary:
        for divisao_nome in jogos_raw.keys():
            var lista: Array = []
            var lista_raw = jogos_raw[divisao_nome]
            if lista_raw is Array:
                for jogo_raw in lista_raw:
                    if jogo_raw is Dictionary:
                        lista.append(_normalizar_partida(jogo_raw, str(divisao_nome)))
            rodada.jogos_por_divisao[str(divisao_nome)] = lista

    return rodada

func to_json_dict() -> Dictionary:
    var jogos_dict: Dictionary = {}
    for divisao in jogos_por_divisao.keys():
        var saida: Array = []
        for partida in jogos_por_divisao[divisao]:
            saida.append(_partida_to_dict(partida))
        jogos_dict[str(divisao)] = saida

    return {
        "rodada_numero": rodada_numero,
        "temporada": temporada,
        "ultima_atualizacao": ultima_atualizacao,
        "partida_principal": _partida_to_dict(partida_principal),
        "jogos_da_rodada": jogos_dict,
        "stats": {
            "total_gols": total_gols_rodada,
            "total_jogos": get_total_jogos()
        }
    }

func _partida_to_dict(partida: Dictionary) -> Dictionary:
    if partida.is_empty():
        return {}
    var casa = partida.get("casa", {})
    var fora = partida.get("fora", {})
    var casa_nome = str(casa.get("nome", "")) if casa is Dictionary else str(casa)
    var fora_nome = str(fora.get("nome", "")) if fora is Dictionary else str(fora)
    var gols_casa = int(partida.get("gols_casa", 0))
    var gols_fora = int(partida.get("gols_fora", 0))
    return {
        "id": str(partida.get("id", "")),
        "casa": casa_nome,
        "fora": fora_nome,
        "placar": "%d x %d" % [gols_casa, gols_fora],
        "gols_casa": gols_casa,
        "gols_fora": gols_fora,
        "estadio": str(partida.get("estadio", "Maracana")),
        "divisao": str(partida.get("divisao", "Serie A")),
        "finalizado": bool(partida.get("finalizado", false)),
        "eventos": partida.get("eventos", [])
    }

var total_gols_rodada: int:
    get:
        var total := 0
        total += int(partida_principal.get("gols_casa", 0)) + int(partida_principal.get("gols_fora", 0))
        for lista in jogos_por_divisao.values():
            if lista is Array:
                for jogo in lista:
                    if jogo is Dictionary:
                        total += int(jogo.get("gols_casa", 0)) + int(jogo.get("gols_fora", 0))
        return total

func get_total_jogos() -> int:
    var total := 0
    for lista in jogos_por_divisao.values():
        if lista is Array:
            total += lista.size()
    return total

func get_jogos_da_divisao(divisao: String) -> Array:
    var lista = jogos_por_divisao.get(divisao, [])
    return lista if lista is Array else []

func get_todas_divisoes() -> Array:
    return jogos_por_divisao.keys()

func get_classificacao(divisao: String) -> Array:
    var pontos: Dictionary = {}
    for jogo in get_jogos_da_divisao(divisao):
        if not jogo is Dictionary:
            continue
        var casa = jogo.get("casa", {})
        var fora = jogo.get("fora", {})
        var casa_nome = str(casa.get("nome", "")) if casa is Dictionary else str(casa)
        var fora_nome = str(fora.get("nome", "")) if fora is Dictionary else str(fora)
        pontos[casa_nome] = int(pontos.get(casa_nome, 0))
        pontos[fora_nome] = int(pontos.get(fora_nome, 0))
        var gc := int(jogo.get("gols_casa", 0))
        var gf := int(jogo.get("gols_fora", 0))
        if gc > gf:
            pontos[casa_nome] += 3
        elif gf > gc:
            pontos[fora_nome] += 3
        else:
            pontos[casa_nome] += 1
            pontos[fora_nome] += 1

    var lista: Array = []
    for nome in pontos.keys():
        lista.append({"nome": nome, "pontos": pontos[nome]})
    lista.sort_custom(func(a, b): return int(a["pontos"]) > int(b["pontos"]))
    return lista
