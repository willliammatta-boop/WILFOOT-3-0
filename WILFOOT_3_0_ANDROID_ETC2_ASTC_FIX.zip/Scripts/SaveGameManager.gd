extends Resource
class_name SaveGameManager

# Sistema Completo Save Game - Slots + Preferências + Tudo

var slots: Dictionary = {}
var max_slots: int = 5
var autosave_slot: String = "autosave"

func _init():
  carregar_slots()

func carregar_slots():
  for i in range(1, max_slots+1):
    var path = "user://save_slot_%d.json" % i
    slots["slot_%d" % i] = _ler_json_seguro(path)

  # Autosave
  slots[autosave_slot] = _ler_json_seguro("user://%s.json" % autosave_slot)

# Lê e valida um JSON de save; nunca deixa f nulo ou JSON corrompido derrubar o app.
func _ler_json_seguro(path: String):
  if not FileAccess.file_exists(path):
    return null
  var f = FileAccess.open(path, FileAccess.READ)
  if f == null:
    push_error("SaveGameManager: não foi possível abrir %s" % path)
    return null
  var texto = f.get_as_text()
  f.close()
  var j = JSON.new()
  var err = j.parse(texto)
  if err != OK:
    push_error("SaveGameManager: JSON inválido em %s (linha %d): %s" % [path, j.get_error_line(), j.get_error_message()])
    return null
  if typeof(j.data) != TYPE_DICTIONARY:
    return null
  return j.data

func salvar_jogo(slot_num: int, dados: Dictionary) -> bool:
  if slot_num<1 or slot_num>max_slots: return false
  dados["data_save"] = Time.get_datetime_string_from_system()
  dados["versao"] = "2026.1"
  dados["slot"] = slot_num
  DirAccess.make_dir_recursive_absolute("user://")
  var path = "user://save_slot_%d.json" % slot_num
  var f = FileAccess.open(path, FileAccess.WRITE)
  if f == null:
    push_error("SaveGameManager: falha ao gravar slot %d" % slot_num)
    return false
  f.store_string(JSON.stringify(dados, "\t"))
  f.close()
  slots["slot_%d" % slot_num] = dados
  print("💾 Jogo salvo no slot %d - %s" % [slot_num, dados.get("nome_carreira","Carreira")])
  return true

func carregar_jogo(slot_num: int) -> Dictionary:
  var key = "slot_%d" % slot_num
  if slots.has(key) and slots[key]!=null:
    print("📂 Jogo carregado slot %d - %s" % [slot_num, slots[key].get("nome_carreira","Carreira")])
    return slots[key]
  return {}

func deletar_jogo(slot_num: int) -> bool:
  var path = "user://save_slot_%d.json" % slot_num
  if FileAccess.file_exists(path):
    DirAccess.remove_absolute(path)
    slots["slot_%d" % slot_num] = null
    print("🗑️ Save slot %d deletado" % slot_num)
    return true
  return false

func autosave(dados: Dictionary):
  dados["data_save"] = Time.get_datetime_string_from_system()
  dados["autosave"] = true
  var f = FileAccess.open("user://%s.json" % autosave_slot, FileAccess.WRITE)
  if f == null:
    push_error("SaveGameManager: falha no autosave")
    return
  f.store_string(JSON.stringify(dados, "\t"))
  f.close()
  slots[autosave_slot] = dados
  print("💾 Autosave - %s" % Time.get_datetime_string_from_system())

func get_info_slot(slot_num: int) -> Dictionary:
  var key = "slot_%d" % slot_num
  if slots.has(key) and slots[key]!=null:
    return {
      "existe": true,
      "nome": slots[key].get("nome_carreira","Carreira"),
      "time": slots[key].get("time_escolhido","Flamengo"),
      "temporada": slots[key].get("temporada_atual",2026),
      "data": slots[key].get("data_save",""),
      "dinheiro": slots[key].get("dinheiro",0),
      "titulos": slots[key].get("total_titulos",0)
    }
  return {"existe": false}

func listar_slots() -> Array:
  var lista = []
  for i in range(1, max_slots+1):
    lista.append(get_info_slot(i))
  return lista
