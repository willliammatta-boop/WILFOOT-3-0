extends Resource
class_name SistemaTitulos

# Sistema TODOS TÍTULOS POSSÍVEIS + Individual + Coletivo

static func get_todos_titulos() -> Dictionary:
  var f = FileAccess.open("res://Data/todos_titulos_possiveis.json", FileAccess.READ)
  if f==null: return {}
  var j = JSON.new(); j.parse(f.get_as_text())
  return j.data

static func get_titulos_por_tipo(tipo: String) -> Array:
  var todos = get_todos_titulos()
  return todos.get(tipo, [])

static func contar_titulos_possiveis() -> int:
  var todos = get_todos_titulos()
  var total = 0
  for cat in todos.keys():
    total += todos[cat].size()
  return total

static func get_premiacao_total() -> float:
  var todos = get_todos_titulos()
  var total = 0.0
  for cat in todos.keys():
    for titulo in todos[cat]:
      total += titulo.get("premio",0)
  return total
