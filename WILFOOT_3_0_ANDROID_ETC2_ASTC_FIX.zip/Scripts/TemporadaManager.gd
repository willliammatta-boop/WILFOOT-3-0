extends Node
class_name TemporadaManager

# Gerencia passagem de temporada e gera newgens automaticamente todo ano

signal nova_temporada(ano: int)
signal intake_base(novos: Array)

var ano_atual: int = 2026
var estrutura_base: String = "3 - Boa"
var generator: NewgenGenerator = NewgenGenerator.new()
var historico_intakes: Dictionary = {}

func avancar_temporada() -> Array[JogadorBase]:
  ano_atual += 1
  print("=== TEMPORADA %d ===" % ano_atual)
  
  # Envelhece todos os jogadores da base
  _envelhecer_base()
  
  # Gera nova safra
  var novos = generator.gerar_safra_anual(ano_atual, estrutura_base)
  historico_intakes[ano_atual] = novos.map(func(j): return j.to_dict())
  
  # Salva histórico
  _salvar_historico()
  
  emit_signal("nova_temporada", ano_atual)
  emit_signal("intake_base", novos)
  
  return novos

func _envelhecer_base():
  # Carrega base atual
  var path = "user://Data/categoria_base_editada.json"
  if not FileAccess.file_exists(path):
    path = "res://Data/categoria_base.json"
  if not FileAccess.file_exists(path): return

  var f = FileAccess.open(path, FileAccess.READ)
  if f == null:
    push_error("TemporadaManager: não foi possível abrir %s" % path)
    return
  var texto = f.get_as_text()
  f.close()
  var j = JSON.new()
  var err = j.parse(texto)
  if err != OK or typeof(j.data) != TYPE_ARRAY:
    push_error("TemporadaManager: JSON inválido em %s" % path)
    return
  var atualizados = []

  for d in j.data:
    var jogador = JogadorBase.from_dict(d)
    jogador.idade += 1
    # Atualiza categoria
    if jogador.idade <=15: jogador.categoria="Sub-15"
    elif jogador.idade <=17: jogador.categoria="Sub-17"
    elif jogador.idade <=20: jogador.categoria="Sub-20"
    else:
      jogador.categoria="Profissional"
      jogador.status="Precisa ser promovido ou dispensado"
    
    # Evolução baseada no potencial
    if jogador.ovr < jogador.potencial:
      var crescimento = randi_range(1,3)
      jogador.ovr = min(jogador.potencial, jogador.ovr + crescimento)
    
    atualizados.append(jogador.to_dict())
  
  # Salva base envelhecida
  DirAccess.make_dir_recursive_absolute("user://Data/")
  var out = FileAccess.open("user://Data/categoria_base_editada.json", FileAccess.WRITE)
  if out == null:
    push_error("TemporadaManager: falha ao salvar categoria de base envelhecida")
    return
  out.store_string(JSON.stringify(atualizados, "\t"))
  out.close()

func _salvar_historico():
  DirAccess.make_dir_recursive_absolute("user://Data/")
  var f = FileAccess.open("user://Data/historico_newgens.json", FileAccess.WRITE)
  if f == null:
    push_error("TemporadaManager: falha ao salvar histórico de newgens")
    return
  f.store_string(JSON.stringify(historico_intakes, "\t"))
  f.close()

func melhorar_estrutura() -> bool:
  var niveis = ["1 - Precária","2 - Básica","3 - Boa","4 - Excelente","5 - Estado da Arte"]
  var idx = niveis.find(estrutura_base)
  if idx < niveis.size()-1:
    estrutura_base = niveis[idx+1]
    print("Estrutura melhorada para %s" % estrutura_base)
    return true
  return false

func get_custo_melhoria() -> int:
  match estrutura_base:
    "1 - Precária": return 5
    "2 - Básica": return 15
    "3 - Boa": return 40
    "4 - Excelente": return 100
    _: return 0
