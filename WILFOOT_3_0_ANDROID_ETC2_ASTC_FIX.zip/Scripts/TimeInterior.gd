extends Resource
class_name TimeInterior
@export var id: String = ""
@export var nome: String = "Caxias"
@export var cidade: String = "Caxias do Sul"
@export var estado: String = "RS"
@export var flag: String = "🇧🇷"
@export var fundacao: int = 1935
@export var estadio: String = "Centenário"
@export var carteira_titulos: Array = []
@export var total_titulos: int = 0
@export var titulos_interior: int = 0
func get_titulos_interior() -> Array:
  return carteira_titulos.filter(func(t): return t.get("categoria","")=="Interior")
func get_resumo() -> String:
  return "%d títulos (%d interior) | %s | Fundado %d" % [total_titulos, titulos_interior, cidade, fundacao]
static func from_dict(d: Dictionary) -> TimeInterior:
  var t = TimeInterior.new()
  t.id=d.get("id",""); t.nome=d.get("nome",""); t.cidade=d.get("cidade",""); t.estado=d.get("estado","RS")
  t.flag=d.get("flag","🇧🇷"); t.fundacao=d.get("fundacao",1935); t.estadio=d.get("estadio","")
  t.carteira_titulos=d.get("carteira_titulos",[]); t.total_titulos=d.get("total_titulos",0); t.titulos_interior=d.get("titulos_interior",0)
  return t
