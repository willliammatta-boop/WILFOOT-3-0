extends Resource
class_name TimeReal

# Sistema Times Reais com Carteira de Títulos - Mostra títulos conquistados ao longo dos anos

@export var id: String = ""
@export var nome: String = "Flamengo"
@export var pais: String = "Brasil"
@export var flag: String = "🇧🇷"
@export var fundacao: int = 1895
@export var estadio: String = "Maracanã"
@export var carteira_titulos: Array = []
@export var total_titulos: int = 0

func get_titulos_por_ano(ano: int) -> Array:
  return carteira_titulos.filter(func(t): return t.get("ano",0)==ano)

func get_titulos_por_competicao(comp: String) -> Array:
  return carteira_titulos.filter(func(t): return t.get("competicao","")==comp)

func get_ultimos_5_anos() -> Array:
  var atual = 2026
  return carteira_titulos.filter(func(t): return t.get("ano",0) >= atual-5)

func adicionar_titulo(titulo: String, ano: int, competicao: String):
  carteira_titulos.append({"titulo":titulo,"ano":ano,"competicao":competicao})
  total_titulos+=1

func get_linha_tempo_agrupada() -> Dictionary:
  # Agrupa títulos por ano
  var agrupado = {}
  for t in carteira_titulos:
    var ano = t.get("ano",0)
    if not agrupado.has(ano): agrupado[ano]=[]
    agrupado[ano].append(t)
  return agrupado

func get_resumo() -> String:
  var libertadores = get_titulos_por_competicao("Libertadores").size()
  var brasileirao = get_titulos_por_competicao("Brasileirão").size()
  var copa_brasil = get_titulos_por_competicao("Copa do Brasil").size()
  return "%d títulos | Libertadores %d | Brasileirão %d | Copa BR %d | Fundado %d" % [total_titulos, libertadores, brasileirao, copa_brasil, fundacao]

func to_dict() -> Dictionary:
  return {"id":id,"nome":nome,"pais":pais,"flag":flag,"fundacao":fundacao,"estadio":estadio,"carteira_titulos":carteira_titulos,"total_titulos":total_titulos}

static func from_dict(d: Dictionary) -> TimeReal:
  var t = TimeReal.new()
  t.id=d.get("id",""); t.nome=d.get("nome",""); t.pais=d.get("pais","Brasil")
  t.flag=d.get("flag","🇧🇷"); t.fundacao=d.get("fundacao",1900); t.estadio=d.get("estadio","")
  t.carteira_titulos=d.get("carteira_titulos",[]); t.total_titulos=d.get("total_titulos",0)
  return t
