extends Control
var times: Array[TimeInterior] = []
@onready var lista: VBoxContainer = $MainVBox/Scroll/Lista
func _ready():
  var f = FileAccess.open("res://Data/times_interior_titulos.json", FileAccess.READ)
  if f==null: return
  var j = JSON.new(); j.parse(f.get_as_text())
  for d in j.data:
    times.append(TimeInterior.from_dict(d))
  for c in lista.get_children(): c.queue_free()
  for time in times:
    var panel = PanelContainer.new()
    var l = Label.new(); l.text="%s %s - %d títulos (%d interior) - %s" % [time.flag, time.nome, time.total_titulos, time.titulos_interior, time.cidade]
    panel.add_child(l)
    lista.add_child(panel)
