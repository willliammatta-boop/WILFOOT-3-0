extends Control
# UI Times Reais com Carteira de Títulos

var times: Array[TimeReal] = []

@onready var lista: VBoxContainer = $MainVBox/Scroll/Lista

func _ready():
  var f = FileAccess.open("res://Data/times_reais_titulos.json", FileAccess.READ)
  if f==null: return
  var j = JSON.new(); j.parse(f.get_as_text())
  for d in j.data:
    times.append(TimeReal.from_dict(d))
  atualizar()

func atualizar():
  for c in lista.get_children(): c.queue_free()
  times.sort_custom(func(a,b): return a.total_titulos>b.total_titulos)
  for time in times:
    var panel = PanelContainer.new()
    var sb = StyleBoxFlat.new(); sb.bg_color=Color(0.09,0.12,0.20)
    sb.corner_radius_top_left=12; sb.corner_radius_top_right=12; sb.corner_radius_bottom_left=12; sb.corner_radius_bottom_right=12
    sb.border_color=Color(0.77,1,0,0.3) if time.total_titulos>=30 else Color(1,1,1,0.08)
    sb.border_width_left=1; sb.border_width_top=1; sb.border_width_right=1; sb.border_width_bottom=1
    sb.content_margin_left=14; sb.content_margin_right=14; sb.content_margin_top=10; sb.content_margin_bottom=10
    panel.add_theme_stylebox_override("panel", sb)
    var vbox = VBoxContainer.new(); panel.add_child(vbox)
    
    var h1 = HBoxContainer.new()
    var nome = Label.new(); nome.text="%s %s | Fundado %d | %s" % [time.flag, time.nome, time.fundacao, time.estadio]
    nome.add_theme_font_size_override("font_size",14)
    var total = Label.new(); total.text="🏆 %d títulos" % time.total_titulos; total.add_theme_color_override("font_color", Color(1,0.84,0))
    h1.add_child(nome); h1.add_child(total); vbox.add_child(h1)
    
    var resumo = Label.new(); resumo.text=time.get_resumo(); resumo.add_theme_font_size_override("font_size",10); resumo.modulate=Color(0.7,0.8,0.9)
    vbox.add_child(resumo)
    
    # Linha do tempo agrupada por ano
    var agrupado = time.get_linha_tempo_agrupada()
    var anos = agrupado.keys(); anos.sort(); anos.reverse()
    for ano in anos.slice(0,4):
      var ano_label = Label.new()
      var titulos_ano = agrupado[ano]
      var nomes = ", ".join(titulos_ano.map(func(t): return t.get("titulo","")))
      ano_label.text="  %d: %s" % [ano, nomes]
      ano_label.add_theme_font_size_override("font_size",11)
      vbox.add_child(ano_label)
    
    lista.add_child(panel)
