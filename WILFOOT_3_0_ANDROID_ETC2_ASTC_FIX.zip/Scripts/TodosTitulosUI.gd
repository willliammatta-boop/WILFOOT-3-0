extends Control
# UI Todos Títulos Possíveis + Individual + Jogadores Reais com TODOS os títulos

var todos_titulos: Dictionary = {}
var jogadores: Array = []
var filtro_tipo: String = "TODOS"

@onready var lista: VBoxContainer = $MainVBox/Scroll/Lista
@onready var stats: Label = $MainVBox/Header/Stats

func _ready():
  carregar_dados()
  atualizar()

func carregar_dados():
  var f1 = FileAccess.open("res://Data/todos_titulos_possiveis.json", FileAccess.READ)
  if f1:
    var j = JSON.new(); j.parse(f1.get_as_text())
    todos_titulos = j.data
  
  var f2 = FileAccess.open("res://Data/jogadores_reais_todos_titulos.json", FileAccess.READ)
  if f2:
    var j2 = JSON.new(); j2.parse(f2.get_as_text())
    jogadores = j2.data

func atualizar():
  for c in lista.get_children(): c.queue_free()
  
  var total_possiveis = 0
  for cat in todos_titulos.keys(): total_possiveis += todos_titulos[cat].size()
  if stats:
    stats.text = "🏆 %d títulos possíveis | 👤 %d jogadores reais | 💎 Individual + Coletivo" % [total_possiveis, jogadores.size()]
  
  # Seção 1: Todos os títulos possíveis por categoria
  for categoria in todos_titulos.keys():
    if filtro_tipo!="TODOS" and categoria!=filtro_tipo:
      continue
    var header = Label.new(); header.text="📁 %s (%d títulos)" % [categoria, todos_titulos[categoria].size()]; header.add_theme_font_size_override("font_size",16); header.add_theme_color_override("font_color", Color(0.77,1,0))
    lista.add_child(header)
    
    for titulo in todos_titulos[categoria]:
      var panel = PanelContainer.new()
      var sb = StyleBoxFlat.new(); sb.bg_color=Color(0.09,0.12,0.20); sb.corner_radius_top_left=8; sb.corner_radius_top_right=8; sb.corner_radius_bottom_left=8; sb.corner_radius_bottom_right=8
      sb.content_margin_left=12; sb.content_margin_right=12; sb.content_margin_top=6; sb.content_margin_bottom=6
      if categoria=="INDIVIDUAL": sb.border_color=Color(1,0.84,0,0.3); sb.border_width_left=2
      elif "CONTINENTAL" in categoria: sb.border_color=Color(0.77,1,0,0.3); sb.border_width_left=2
      panel.add_theme_stylebox_override("panel", sb)
      var hbox = HBoxContainer.new(); panel.add_child(hbox)
      var nome = Label.new(); nome.text=titulo.get("nome",""); nome.size_flags_horizontal=Control.SIZE_EXPAND_FILL
      var premio = Label.new(); premio.text="%s %.1fM" % [titulo.get("moeda",""), titulo.get("premio",0)]; premio.add_theme_color_override("font_color", Color(0.2,0.8,0.4)); premio.add_theme_font_size_override("font_size",10)
      hbox.add_child(nome); hbox.add_child(premio)
      lista.add_child(panel)
  
  # Seção 2: Jogadores reais com TODOS os títulos
  var header_jog = Label.new(); header_jog.text="👤 JOGADORES REAIS - TODOS OS TÍTULOS"; header_jog.add_theme_font_size_override("font_size",18); header_jog.add_theme_color_override("font_color", Color(1,0.84,0))
  lista.add_child(header_jog)
  
  for jogador in jogadores:
    var panel = PanelContainer.new()
    var sb = StyleBoxFlat.new(); sb.bg_color=Color(0.11,0.14,0.23)
    sb.corner_radius_top_left=12; sb.corner_radius_top_right=12; sb.corner_radius_bottom_left=12; sb.corner_radius_bottom_right=12
    sb.border_color=Color(1,0.84,0,0.4) if jogador.get("total_titulos",0)>=30 else Color(1,1,1,0.08)
    sb.border_width_left=1; sb.content_margin_left=14; sb.content_margin_right=14; sb.content_margin_top=10; sb.content_margin_bottom=10
    panel.add_theme_stylebox_override("panel", sb)
    var vbox = VBoxContainer.new(); panel.add_child(vbox)
    
    var h1 = HBoxContainer.new()
    var nome = Label.new(); nome.text="%s %s | %s %d anos | OVR %d | %s" % [jogador.get("flag",""), jogador.get("nome",""), jogador.get("pos",""), jogador.get("idade",0), jogador.get("ovr",0), jogador.get("time_atual","")]
    var total = Label.new(); total.text="🏆 %d (%d coletivo + %d individual)" % [jogador.get("total_titulos",0), jogador.get("total_coletivos",0), jogador.get("total_individuais",0)]; total.add_theme_color_override("font_color", Color(1,0.84,0))
    h1.add_child(nome); h1.add_child(total); vbox.add_child(h1)
    
    var resumo_ind = Label.new(); resumo_ind.text=jogador.get("resumo_individual",""); resumo_ind.add_theme_font_size_override("font_size",10); resumo_ind.modulate=Color(1,0.84,0.6); resumo_ind.autowrap_mode=TextServer.AUTOWRAP_WORD
    if jogador.get("resumo_individual","")!="": vbox.add_child(resumo_ind)
    
    # Mostra títulos coletivos e individuais separados
    var coletivos = jogador.get("carteira_titulos",[]).filter(func(t): return t.get("tipo","")=="Coletivo")
    var individuais = jogador.get("carteira_titulos",[]).filter(func(t): return t.get("tipo","")=="Individual")
    
    if coletivos.size()>0:
      var label_col = Label.new(); label_col.text="  Coletivos (%d):" % coletivos.size(); label_col.add_theme_font_size_override("font_size",11); label_col.add_theme_color_override("font_color", Color(0.77,1,0))
      vbox.add_child(label_col)
      for t in coletivos.slice(0,4):
        var l = Label.new(); l.text="    %d - %s (%s) pelo %s" % [t.get("ano",0), t.get("titulo",""), t.get("competicao",""), t.get("time","")]; l.add_theme_font_size_override("font_size",10)
        vbox.add_child(l)
    
    if individuais.size()>0:
      var label_ind = Label.new(); label_ind.text="  Individuais (%d):" % individuais.size(); label_ind.add_theme_font_size_override("font_size",11); label_ind.add_theme_color_override("font_color", Color(1,0.84,0))
      vbox.add_child(label_ind)
      for t in individuais.slice(0,4):
        var qtd = t.get("quantidade",1)
        var detalhe = t.get("detalhe","")
        var l = Label.new()
        if qtd>1:
          l.text="    %dx %s (%s) - %s" % [qtd, t.get("titulo",""), t.get("ano",0), detalhe]
        else:
          l.text="    %d - %s (%s)" % [t.get("ano",0), t.get("titulo",""), t.get("competicao","")]
        l.add_theme_font_size_override("font_size",10); l.add_theme_color_override("font_color", Color(1,0.84,0.6))
        vbox.add_child(l)
    
    lista.add_child(panel)

func _on_filtro(tipo: String):
  filtro_tipo = tipo
  atualizar()
