# WILFOOT - UIManager.gd
# Gerenciador de UI robusto para Godot 4.7.x.
extends Control
class_name WilfootUIManager

signal jogo_selecionado(partida)
signal divisao_trocada(nova_divisao: String)

@export_group("Cena")
@export var jogo_item_scene: PackedScene
@export var lista_container_path: NodePath = NodePath("ScrollContainer/VBoxJogos")
@export var divisoes_tabs_path: NodePath = NodePath("DivisoesTabs")
@export var empty_state_path: NodePath = NodePath("EmptyState")

@export_group("Partida Principal")
@export var placar_label_path: NodePath = NodePath("PartidaPrincipal/Placar")
@export var estadio_label_path: NodePath = NodePath("PartidaPrincipal/Estadio")
@export var casa_label_path: NodePath = NodePath("PartidaPrincipal/CasaNome")
@export var fora_label_path: NodePath = NodePath("PartidaPrincipal/ForaNome")

@export_group("Visual")
@export var animar_entrada: bool = true
@export var duracao_animacao: float = 0.35
@export var stagger_delay: float = 0.06

var _lista_container: VBoxContainer
var _tabs: TabContainer
var _empty_state: Control
var _rodada_atual
var _divisao_atual: String = ""
var _pool_itens: Array = []

func _ready() -> void:
    _lista_container = get_node_or_null(lista_container_path) as VBoxContainer
    _tabs = get_node_or_null(divisoes_tabs_path) as TabContainer
    _empty_state = get_node_or_null(empty_state_path) as Control
    if _tabs and not _tabs.tab_changed.is_connected(_on_divisao_trocada):
        _tabs.tab_changed.connect(_on_divisao_trocada)

func render_rodada(rodada) -> void:
    _rodada_atual = rodada
    if rodada == null:
        _mostrar_empty("Nenhuma rodada carregada")
        return
    _render_partida_principal(rodada.partida_principal)
    _render_divisoes_tabs(rodada.get_todas_divisoes())
    var divisoes = rodada.get_todas_divisoes()
    if not divisoes.is_empty():
        var primeira = _divisao_atual if _divisao_atual != "" else str(divisoes[0])
        render_divisao(primeira)
    else:
        _mostrar_empty("Sem jogos nesta rodada")

func render_divisao(divisao_nome: String) -> void:
    if _rodada_atual == null:
        return
    _divisao_atual = divisao_nome
    var jogos = _rodada_atual.get_jogos_da_divisao(divisao_nome)
    if _lista_container == null:
        return
    _limpar_lista()
    if jogos.is_empty():
        _mostrar_empty("Nenhum jogo em %s" % divisao_nome)
        return
    if _empty_state:
        _empty_state.visible = false
    for i in range(jogos.size()):
        var partida = jogos[i]
        var item = _criar_item_jogo(partida)
        if item == null:
            continue
        _lista_container.add_child(item)
        if animar_entrada:
            item.modulate.a = 0.0
            var tween := create_tween()
            tween.tween_property(item, "modulate:a", 1.0, duracao_animacao).set_delay(i * stagger_delay)

func _nome_time(partida: Dictionary, lado: String) -> String:
    var time = partida.get(lado, {})
    if time is Dictionary:
        return str(time.get("nome", "-"))
    return str(time)

func _placar(partida: Dictionary) -> String:
    return "%d x %d" % [int(partida.get("gols_casa", 0)), int(partida.get("gols_fora", 0))]

func _render_partida_principal(partida) -> void:
    if not partida is Dictionary or partida.is_empty():
        return
    _set_text_seguro(placar_label_path, _placar(partida))
    _set_text_seguro(estadio_label_path, str(partida.get("estadio", "-")))
    _set_text_seguro(casa_label_path, _nome_time(partida, "casa"))
    _set_text_seguro(fora_label_path, _nome_time(partida, "fora"))

func _render_divisoes_tabs(divisoes: Array) -> void:
    if _tabs == null:
        return
    while _tabs.get_tab_count() > 0:
        _tabs.get_child(0).queue_free()
    for divisao in divisoes:
        var placeholder := Control.new()
        placeholder.name = str(divisao)
        _tabs.add_child(placeholder)
        _tabs.set_tab_title(_tabs.get_tab_count() - 1, str(divisao))

func _criar_item_jogo(partida: Dictionary) -> Control:
    var item: Control
    if jogo_item_scene != null:
        item = jogo_item_scene.instantiate() as Control
        if item == null:
            return null
        if item.has_method("setup"):
            item.call("setup", partida)
        elif item.has_method("configurar"):
            item.call("configurar", partida)
        else:
            _set_text_no_filho(item, "Casa", _nome_time(partida, "casa"))
            _set_text_no_filho(item, "Fora", _nome_time(partida, "fora"))
            _set_text_no_filho(item, "Placar", _placar(partida))
            _set_text_no_filho(item, "Estadio", str(partida.get("estadio", "-")))
    else:
        item = _criar_item_fallback(partida)
    if item is Button:
        item.pressed.connect(func(): jogo_selecionado.emit(partida))
    return item

func _criar_item_fallback(partida: Dictionary) -> Control:
    var panel := PanelContainer.new()
    panel.custom_minimum_size = Vector2(0, 68)
    var hbox := HBoxContainer.new()
    hbox.add_theme_constant_override("separation", 12)
    panel.add_child(hbox)

    var casa := Label.new()
    casa.text = _nome_time(partida, "casa")
    casa.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
    casa.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    hbox.add_child(casa)

    var placar := Label.new()
    placar.text = _placar(partida)
    placar.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    placar.custom_minimum_size = Vector2(70, 0)
    hbox.add_child(placar)

    var fora := Label.new()
    fora.text = _nome_time(partida, "fora")
    fora.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    hbox.add_child(fora)
    return panel

func _limpar_lista() -> void:
    if _lista_container == null:
        return
    for child in _lista_container.get_children():
        child.queue_free()

func _mostrar_empty(msg: String) -> void:
    if _empty_state:
        _empty_state.visible = true
        var label := _empty_state.get_node_or_null("Label") as Label
        if label:
            label.text = msg

func _on_divisao_trocada(tab_idx: int) -> void:
    if _tabs == null or _rodada_atual == null or tab_idx < 0 or tab_idx >= _tabs.get_tab_count():
        return
    var nome := _tabs.get_tab_title(tab_idx)
    render_divisao(nome)
    divisao_trocada.emit(nome)

func _set_text_seguro(path: NodePath, texto: String) -> void:
    var node := get_node_or_null(path)
    if node == null:
        return
    if node is Label:
        node.text = texto
    elif node.has_method("set_text"):
        node.call("set_text", texto)

func _set_text_no_filho(parent: Node, nome_filho: String, texto: String) -> void:
    var node := parent.get_node_or_null(nome_filho)
    if node == null:
        node = parent.find_child(nome_filho, true, false)
    if node == null:
        return
    if node is Label:
        node.text = texto
    elif node.has_method("set_text"):
        node.call("set_text", texto)

func conectar_com_main(main_node: Node) -> void:
    if main_node == null:
        return
    if main_node.has_signal("rodada_carregada"):
        main_node.rodada_carregada.connect(_receber_rodada)
    if main_node.has_signal("simulacao_finalizada"):
        main_node.simulacao_finalizada.connect(_receber_rodada)

func _receber_rodada(dados) -> void:
    if dados is Dictionary and ClassDB.class_exists("RodadaData"):
        var rodada = RodadaData.from_json_dict(dados)
        render_rodada(rodada)
