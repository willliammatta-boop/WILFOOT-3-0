# WILFOOT ENGINE 7.0
# Núcleo seguro de simulação: 10 países, 120 clubes por país,
# divisões, calendário, tabela, promoção/rebaixamento e partidas.
extends RefCounted
class_name WilfootEngine7

const ENGINE_VERSION := "7.0"
const MAX_GOALS := 8

var database: Dictionary = {}
var countries: Dictionary = {}
var standings: Dictionary = {}
var schedules: Dictionary = {}
var rounds_played: Dictionary = {}
var ratings: Dictionary = {}
var last_results: Dictionary = {}
var season: int = 2026

func load_database(path: String = "res://Data/mundo_1200_clubes.json") -> bool:
    database.clear()
    countries.clear()
    standings.clear()
    schedules.clear()
    rounds_played.clear()
    ratings.clear()
    last_results.clear()

    if not FileAccess.file_exists(path):
        push_error("ENGINE 7.0: banco não encontrado: %s" % path)
        return false
    var file := FileAccess.open(path, FileAccess.READ)
    if file == null:
        push_error("ENGINE 7.0: não foi possível abrir o banco.")
        return false
    var parsed = JSON.parse_string(file.get_as_text())
    file.close()
    if typeof(parsed) != TYPE_DICTIONARY:
        push_error("ENGINE 7.0: JSON raiz inválido.")
        return false
    database = parsed

    var country_list = database.get("countries", [])
    if typeof(country_list) != TYPE_ARRAY:
        push_error("ENGINE 7.0: 'countries' inválido.")
        return false

    for country_data in country_list:
        if typeof(country_data) != TYPE_DICTIONARY:
            continue
        var country_name := str(country_data.get("country", ""))
        if country_name.is_empty():
            continue
        var normalized := _normalize_country(country_data)
        countries[country_name] = normalized
        _create_country_state(country_name, normalized)

    return countries.size() > 0

func _normalize_country(data: Dictionary) -> Dictionary:
    var result := {"country": str(data.get("country", "")), "divisions": []}
    var divisions = data.get("divisions", [])
    if typeof(divisions) != TYPE_ARRAY:
        divisions = []
    for division in divisions:
        if typeof(division) != TYPE_DICTIONARY:
            continue
        var teams: Array = []
        var raw_teams = division.get("teams", [])
        if typeof(raw_teams) == TYPE_ARRAY:
            for raw_name in raw_teams:
                var name := str(raw_name).strip_edges()
                if not name.is_empty() and not teams.has(name):
                    teams.append(name)
        result.divisions.append({"name": str(division.get("name", "Divisão")), "teams": teams})
    return result

func _create_country_state(country_name: String, country_data: Dictionary) -> void:
    for division_data in country_data.get("divisions", []):
        var division_name := str(division_data.get("name", "Divisão"))
        var key := _key(country_name, division_name)
        var teams: Array = division_data.get("teams", []).duplicate()
        standings[key] = _empty_table(teams)
        schedules[key] = _make_schedule(teams)
        rounds_played[key] = 0
        last_results[key] = []
        for i in teams.size():
            ratings[teams[i]] = _rating_for_index(i, teams.size(), division_name)

func _key(country: String, division: String) -> String:
    return "%s::%s" % [country, division]

func _rating_for_index(index: int, total: int, division: String) -> float:
    var base := 68.0
    if division == "Divisão 1":
        base = 86.0
    elif division == "Divisão 2":
        base = 76.0
    elif division == "Divisão 3":
        base = 68.0
    else:
        base = 60.0
    var spread := 14.0 if total > 1 else 0.0
    return clampf(base - spread * float(index) / float(maxi(total - 1, 1)), 45.0, 94.0)

func _empty_table(teams: Array) -> Array:
    var table: Array = []
    for team in teams:
        table.append({"name": str(team), "p": 0, "j": 0, "v": 0, "e": 0, "d": 0, "gp": 0, "gc": 0})
    return table

func _make_schedule(teams: Array) -> Array:
    var t: Array = teams.duplicate()
    if t.size() < 2:
        return []
    if t.size() % 2 == 1:
        t.append("")
    var n := t.size()
    var rounds: Array = []
    for r in n - 1:
        var games: Array = []
        for i in range(n >> 1):
            var a = t[i]
            var b = t[n - 1 - i]
            if str(a).is_empty() or str(b).is_empty():
                continue
            if (r + i) % 2 == 0:
                games.append([a, b])
            else:
                games.append([b, a])
        rounds.append(games)
        var last = t.pop_back()
        t.insert(1, last)
    var second: Array = []
    for games in rounds:
        var reverse_games: Array = []
        for game in games:
            reverse_games.append([game[1], game[0]])
        second.append(reverse_games)
    return rounds + second

func simulate_round(country: String, division: String, round_index: int) -> Array:
    var key := _key(country, division)
    if not schedules.has(key) or round_index < 1:
        return []
    var schedule: Array = schedules[key]
    if round_index > schedule.size():
        return []
    var games: Array = []
    for game in schedule[round_index - 1]:
        var score := simulate_match(str(game[0]), str(game[1]))
        _record(key, str(game[0]), int(score[0]), str(game[1]), int(score[1]))
        games.append({"home": game[0], "away": game[1], "home_goals": score[0], "away_goals": score[1], "score": "%d x %d" % [score[0], score[1]]})
    rounds_played[key] = round_index
    last_results[key] = games
    return games

func simulate_match(home: String, away: String) -> Array:
    var rh := float(ratings.get(home, 65.0))
    var ra := float(ratings.get(away, 65.0))
    var diff := (rh - ra) / 18.0
    var home_lambda := clampf(1.35 + diff + 0.18, 0.20, 3.80)
    var away_lambda := clampf(1.10 - diff * 0.65, 0.15, 3.40)
    return [_poisson(home_lambda), _poisson(away_lambda)]

func _poisson(lambda: float) -> int:
    var l := exp(-lambda)
    var p := 1.0
    var k := 0
    while k < MAX_GOALS:
        k += 1
        p *= randf()
        if p <= l:
            return k - 1
    return MAX_GOALS

func _record(key: String, home: String, hg: int, away: String, ag: int) -> void:
    if not standings.has(key):
        return
    for row in standings[key]:
        if str(row.get("name", "")) == home:
            _apply(row, hg, ag)
        elif str(row.get("name", "")) == away:
            _apply(row, ag, hg)

func _apply(row: Dictionary, gf: int, ga: int) -> void:
    row["j"] = int(row.get("j", 0)) + 1
    row["gp"] = int(row.get("gp", 0)) + gf
    row["gc"] = int(row.get("gc", 0)) + ga
    if gf > ga:
        row["v"] = int(row.get("v", 0)) + 1
        row["p"] = int(row.get("p", 0)) + 3
    elif gf == ga:
        row["e"] = int(row.get("e", 0)) + 1
        row["p"] = int(row.get("p", 0)) + 1
    else:
        row["d"] = int(row.get("d", 0)) + 1

func get_table(country: String, division: String) -> Array:
    var key := _key(country, division)
    if not standings.has(key):
        return []
    var result: Array = standings[key].duplicate(true)
    result.sort_custom(func(a: Dictionary, b: Dictionary) -> bool:
        if int(a.get("p", 0)) != int(b.get("p", 0)):
            return int(a.get("p", 0)) > int(b.get("p", 0))
        var gd_a := int(a.get("gp", 0)) - int(a.get("gc", 0))
        var gd_b := int(b.get("gp", 0)) - int(b.get("gc", 0))
        if gd_a != gd_b:
            return gd_a > gd_b
        return int(a.get("gp", 0)) > int(b.get("gp", 0))
    )
    return result

func get_division_count(country: String) -> int:
    if not countries.has(country):
        return 0
    return countries[country].get("divisions", []).size()

func get_total_teams(country: String) -> int:
    if not countries.has(country):
        return 0
    var total := 0
    for division in countries[country].get("divisions", []):
        total += division.get("teams", []).size()
    return total

func validate() -> Dictionary:
    var report := {"ok": true, "countries": countries.size(), "teams": 0, "errors": []}
    var seen := {}
    for country_name in countries.keys():
        var total := 0
        for division in countries[country_name].get("divisions", []):
            var teams: Array = division.get("teams", [])
            total += teams.size()
            for team in teams:
                if seen.has(team):
                    report.errors.append("Clube duplicado: %s" % team)
                seen[team] = true
        report.teams += total
        if total != 120:
            report.errors.append("%s possui %d clubes; esperado 120." % [country_name, total])
    report.ok = report.errors.is_empty() and report.countries == 10 and report.teams == 1200
    return report

func finish_season(country: String) -> Dictionary:
    var result := {"promoted": [], "relegated": []}
    if not countries.has(country):
        return result
    var divisions: Array = countries[country].get("divisions", [])
    if divisions.size() < 3:
        return result
    # Regras simples e determinísticas: 3 sobem, 3 descem entre cada divisão principal.
    for idx in range(2):
        var upper := str(divisions[idx].get("name", ""))
        var lower := str(divisions[idx + 1].get("name", ""))
        var up_table := get_table(country, upper)
        var low_table := get_table(country, lower)
        if up_table.size() < 3 or low_table.size() < 3:
            continue
        var down: Array = []
        for i in range(maxi(up_table.size() - 3, 0), up_table.size()):
            down.append(str(up_table[i].get("name", "")))
        var up: Array = []
        for i in 3:
            up.append(str(low_table[i].get("name", "")))
        result.relegated.append({"from": upper, "to": lower, "teams": down})
        result.promoted.append({"from": lower, "to": upper, "teams": up})
    return result
