extends Node

## WILFOOT 2.1 — Motor inteligente de localização contextual.
## Offline, sem depender de internet ou APIs externas.

signal language_changed(language_id: String)

const SAVE_PATH := "user://wilfoot_language.json"
const DEFAULT_LANGUAGE := "pt_BR"
const LANGUAGE_FILES := {
    "pt_BR": "res://Data/Idiomas/pt_BR.json",
    "en_GB": "res://Data/Idiomas/en_GB.json",
    "de_DE": "res://Data/Idiomas/de_DE.json",
    "it_IT": "res://Data/Idiomas/it_IT.json",
    "fr_FR": "res://Data/Idiomas/fr_FR.json",
    "es_ES": "res://Data/Idiomas/es_ES.json",
    "pt_PT": "res://Data/Idiomas/pt_PT.json",
    "tr_TR": "res://Data/Idiomas/tr_TR.json"
}

const LANGUAGE_NAMES := {
    "pt_BR": "Português (Brasil)",
    "en_GB": "English (United Kingdom)",
    "de_DE": "Deutsch",
    "it_IT": "Italiano",
    "fr_FR": "Français",
    "es_ES": "Español",
    "pt_PT": "Português (Portugal)",
    "tr_TR": "Türkçe"
}

var current_language: String = DEFAULT_LANGUAGE
var dictionaries: Dictionary = {}

func _ready() -> void:
    _load_all_dictionaries()
    current_language = _load_saved_language()
    if not LANGUAGE_FILES.has(current_language):
        current_language = DEFAULT_LANGUAGE

func _load_all_dictionaries() -> void:
    dictionaries.clear()
    for language_key in LANGUAGE_FILES.keys():
        var language_id: String = str(language_key)
        var path: String = str(LANGUAGE_FILES[language_id])
        var file := FileAccess.open(path, FileAccess.READ)
        if file == null:
            dictionaries[language_id] = {}
            continue
        var parsed: Variant = JSON.parse_string(file.get_as_text())
        file.close()
        if typeof(parsed) == TYPE_DICTIONARY:
            dictionaries[language_id] = parsed as Dictionary
        else:
            dictionaries[language_id] = {}

func _load_saved_language() -> String:
    if not FileAccess.file_exists(SAVE_PATH):
        return _detect_system_language()
    var file := FileAccess.open(SAVE_PATH, FileAccess.READ)
    if file == null:
        return _detect_system_language()
    var parsed: Variant = JSON.parse_string(file.get_as_text())
    file.close()
    if typeof(parsed) == TYPE_DICTIONARY:
        var saved: String = str((parsed as Dictionary).get("language", ""))
        if LANGUAGE_FILES.has(saved):
            return saved
    return _detect_system_language()

func _detect_system_language() -> String:
    var locale: String = OS.get_locale().replace("-", "_")
    if locale.begins_with("pt_BR") or locale == "pt":
        return "pt_BR"
    if locale.begins_with("pt_PT"):
        return "pt_PT"
    if locale.begins_with("en"):
        return "en_GB"
    if locale.begins_with("de"):
        return "de_DE"
    if locale.begins_with("it"):
        return "it_IT"
    if locale.begins_with("fr"):
        return "fr_FR"
    if locale.begins_with("es"):
        return "es_ES"
    if locale.begins_with("tr"):
        return "tr_TR"
    return DEFAULT_LANGUAGE

func set_system_language() -> bool:
    return set_language(_detect_system_language())

func set_language(language_id: String) -> bool:
    if not LANGUAGE_FILES.has(language_id):
        return false
    current_language = language_id
    var file := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
    if file != null:
        file.store_string(JSON.stringify({"language": current_language}))
        file.close()
    language_changed.emit(current_language)
    return true

func get_language_name(language_id: String = "") -> String:
    var id: String = current_language if language_id == "" else language_id
    return str(LANGUAGE_NAMES.get(id, id))

func get_languages() -> Array[String]:
    var result: Array[String] = []
    for language_key in LANGUAGE_FILES.keys():
        result.append(str(language_key))
    return result

func tr_text(source_text: String) -> String:
    if source_text == "":
        return ""
    var active: Dictionary = dictionaries.get(current_language, {}) as Dictionary
    if active.has(source_text):
        return str(active[source_text])
    var fallback: Dictionary = dictionaries.get(DEFAULT_LANGUAGE, {}) as Dictionary
    if fallback.has(source_text):
        return str(fallback[source_text])
    return source_text
