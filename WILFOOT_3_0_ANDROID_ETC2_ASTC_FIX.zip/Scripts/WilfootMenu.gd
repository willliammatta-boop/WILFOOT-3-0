extends Control

signal new_game_pressed
signal load_game_pressed
signal editor_pressed
signal exit_pressed

func _ready() -> void:
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    process_mode = Node.PROCESS_MODE_ALWAYS

    var bg := TextureRect.new()
    bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    bg.texture = load("res://assets/wilfoot_menu_bg.png")
    bg.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    bg.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
    bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(bg)
    move_child(bg, 0)

    var novo := _make_button("Novo Jogo")
    var carregar := _make_button("Carregar Jogo Salvo")
    var editor := _make_button("Editor Equipes")
    var sair := _make_button("Sair  ✕")

    _place(novo, 0.662, 0.195, 0.953, 0.300)
    _place(carregar, 0.662, 0.362, 0.953, 0.468)
    _place(editor, 0.662, 0.533, 0.953, 0.638)
    _place(sair, 0.662, 0.700, 0.953, 0.803)

    novo.pressed.connect(func(): new_game_pressed.emit())
    carregar.pressed.connect(func(): load_game_pressed.emit())
    editor.pressed.connect(func(): editor_pressed.emit())
    sair.pressed.connect(func(): exit_pressed.emit())

func _make_button(label_text: String) -> Button:
    var b := Button.new()
    b.text = label_text
    b.add_theme_font_size_override("font_size", 27)
    b.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND

    var normal := StyleBoxFlat.new()
    normal.bg_color = Color(0.35, 0.02, 0.015, 0.88)
    normal.border_width_left = 2
    normal.border_width_top = 2
    normal.border_width_right = 2
    normal.border_width_bottom = 2
    normal.border_color = Color(0.62, 0.16, 0.12, 0.95)

    var hover := normal.duplicate()
    hover.bg_color = Color(0.55, 0.04, 0.02, 0.94)
    hover.border_color = Color(0.95, 0.25, 0.16, 1.0)

    var pressed := normal.duplicate()
    pressed.bg_color = Color(0.22, 0.01, 0.01, 0.96)

    b.add_theme_stylebox_override("normal", normal)
    b.add_theme_stylebox_override("hover", hover)
    b.add_theme_stylebox_override("pressed", pressed)
    add_child(b)
    return b

func _place(c: Control, l: float, t: float, r: float, b: float) -> void:
    c.anchor_left = l
    c.anchor_top = t
    c.anchor_right = r
    c.anchor_bottom = b
    c.offset_left = 0
    c.offset_top = 0
    c.offset_right = 0
    c.offset_bottom = 0

func show_message(text: String) -> void:
    var label := Label.new()
    label.text = text
    label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    label.add_theme_color_override("font_color", Color("#C8FF00"))
    label.position = Vector2(0, size.y * 0.84)
    label.size = Vector2(size.x, 40)
    add_child(label)
    get_tree().create_timer(3.0).timeout.connect(label.queue_free)
