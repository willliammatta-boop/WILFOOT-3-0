extends Node

func _ready() -> void:
    var menu = get_parent().get_node_or_null("WilfootMenu")
    if menu == null:
        push_error("WILFOOT: WilfootMenu não encontrado em Main.tscn")
        return
    menu.process_mode = Node.PROCESS_MODE_ALWAYS
    menu.new_game_pressed.connect(_new_game)
    menu.load_game_pressed.connect(_load_game)
    menu.editor_pressed.connect(_editor)
    menu.exit_pressed.connect(_exit)

func _new_game() -> void:
    var p = get_parent()
    if p.has_method("start_new_game"):
        p.start_new_game()
    elif p.has_method("new_game"):
        p.new_game()

func _load_game() -> void:
    var p = get_parent()
    if p.has_method("continue_game"):
        p.continue_game()
    elif p.has_method("load_game"):
        if p.load_game():
            if p.has_method("show_screen"):
                p.show_screen("home")
        else:
            var menu = p.get_node_or_null("WilfootMenu")
            if menu and menu.has_method("show_message"):
                menu.show_message("Nenhum save compatível encontrado.")

func _editor() -> void:
    var p = get_parent()
    if p.has_method("open_team_editor"):
        p.open_team_editor()
    elif p.has_method("show_team_editor"):
        p.show_team_editor()
    elif p.has_method("show_screen"):
        p.show_screen("more")
        p.message = "Editor de equipes: use as opções de carreira em MAIS."

func _exit() -> void:
    get_tree().quit()
