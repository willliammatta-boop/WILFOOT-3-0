extends Node

## WILFOOT 3.0 — Mundo Vivo
## Fundação isolada para eventos, notícias e movimentações do futebol.
## Não altera o motor de partidas existente nesta primeira etapa.

signal world_updated

const DB_PATH: String = "res://Data/mundo_120_clubes.json"
const SAVE_PATH: String = "user://wilfoot_world3.json"

var clubs: Array[Dictionary] = []
var countries: Array[String] = []
var headlines: Array[Dictionary] = []
var last_day_key: String = ""
var world_seed: int = 2026

func _ready() -> void:
    _load_clubs()
    _load_state()
    _refresh_world(false)

func _load_clubs() -> void:
    clubs.clear()
    countries.clear()
    if not FileAccess.file_exists(DB_PATH):
        return
    var file: FileAccess = FileAccess.open(DB_PATH, FileAccess.READ)
    if file == null:
        return
    var parsed: Variant = JSON.parse_string(file.get_as_text())
    file.close()
    if typeof(parsed) != TYPE_DICTIONARY:
        return
    var root: Dictionary = parsed as Dictionary
    var raw_leagues: Variant = root.get("leagues", [])
    if raw_leagues is Array:
        for raw_league in raw_leagues as Array:
            if not (raw_league is Dictionary):
                continue
            var league: Dictionary = raw_league as Dictionary
            var country_name: String = str(league.get("country", ""))
            if country_name != "":
                countries.append(country_name)
            var raw_teams: Variant = league.get("teams", [])
            if raw_teams is Array:
                for raw_team in raw_teams as Array:
                    var team_name: String = str(raw_team)
                    if team_name != "":
                        clubs.append({"name": team_name, "country": country_name})

    var raw_countries: Variant = root.get("countries", [])
    if clubs.is_empty() and raw_countries is Array:
        for raw_country in raw_countries as Array:
            if not (raw_country is Dictionary):
                continue
            var country: Dictionary = raw_country as Dictionary
            var fallback_country: String = str(country.get("country", country.get("name", "")))
            if fallback_country != "":
                countries.append(fallback_country)
            var raw_clubs: Variant = country.get("teams", country.get("clubs", []))
            if raw_clubs is Array:
                for raw_club in raw_clubs as Array:
                    if raw_club is Dictionary:
                        var club_data: Dictionary = raw_club as Dictionary
                        clubs.append(club_data)
                    else:
                        clubs.append({"name": str(raw_club), "country": fallback_country})

func _load_state() -> void:
    last_day_key = ""
    if not FileAccess.file_exists(SAVE_PATH):
        return
    var file: FileAccess = FileAccess.open(SAVE_PATH, FileAccess.READ)
    if file == null:
        return
    var parsed: Variant = JSON.parse_string(file.get_as_text())
    file.close()
    if parsed is Dictionary:
        var state: Dictionary = parsed as Dictionary
        last_day_key = str(state.get("last_day", ""))
        world_seed = int(state.get("seed", 2026))

func _save_state(day_key: String) -> void:
    var file: FileAccess = FileAccess.open(SAVE_PATH, FileAccess.WRITE)
    if file == null:
        return
    file.store_string(JSON.stringify({"last_day": day_key, "seed": world_seed}))
    file.close()

func _today_key() -> String:
    var date: Dictionary = Time.get_date_dict_from_system()
    return "%04d-%02d-%02d" % [int(date.get("year", 2026)), int(date.get("month", 1)), int(date.get("day", 1))]

func _refresh_world(force: bool) -> void:
    var day_key: String = _today_key()
    if not force and day_key == last_day_key and not headlines.is_empty():
        return
    headlines = _build_headlines(day_key)
    last_day_key = day_key
    _save_state(day_key)
    world_updated.emit()

func refresh_now() -> void:
    _refresh_world(true)

func get_headlines() -> Array[Dictionary]:
    return headlines.duplicate(true)

func get_club_count() -> int:
    return clubs.size()

func get_country_count() -> int:
    return countries.size()

func get_status_text() -> String:
    return "%d clubes • %d países • mundo vivo" % [clubs.size(), countries.size()]

func _build_headlines(day_key: String) -> Array[Dictionary]:
    var result: Array[Dictionary] = []
    if clubs.is_empty():
        result.append({"icon": "🌍", "title": "Mundo carregado", "body": "A base mundial está pronta para receber eventos.", "type": "info"})
        return result

    var seed_value: int = day_key.hash() ^ world_seed
    var rng: RandomNumberGenerator = RandomNumberGenerator.new()
    rng.seed = abs(seed_value)

    var first: Dictionary = clubs[rng.randi_range(0, clubs.size() - 1)]
    var second: Dictionary = clubs[rng.randi_range(0, clubs.size() - 1)]
    var first_name: String = str(first.get("name", first.get("nome", "Clube desconhecido")))
    var second_name: String = str(second.get("name", second.get("nome", "Clube desconhecido")))

    result.append({
        "icon": "💰",
        "title": "Mercado em movimento",
        "body": "%s entrou no radar de %s para uma possível negociação." % [first_name, second_name],
        "type": "transfer"
    })

    var young: Dictionary = clubs[rng.randi_range(0, clubs.size() - 1)]
    var young_name: String = str(young.get("name", young.get("nome", "Jovem promessa")))
    result.append({
        "icon": "🌱",
        "title": "Promessa em destaque",
        "body": "%s ganhou atenção dos olheiros depois de uma sequência de boas atuações." % young_name,
        "type": "academy"
    })

    var third: Dictionary = clubs[rng.randi_range(0, clubs.size() - 1)]
    var third_name: String = str(third.get("name", third.get("nome", "Clube")))
    result.append({
        "icon": "🏟️",
        "title": "Dia de jogo",
        "body": "%s prepara uma rodada importante. A pressão aumenta na reta final da temporada." % third_name,
        "type": "match"
    })

    result.append({
        "icon": "📈",
        "title": "Ranking mundial",
        "body": "A classificação será recalculada progressivamente conforme as temporadas do WILFOOT avançarem.",
        "type": "ranking"
    })
    return result
