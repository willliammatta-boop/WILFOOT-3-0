# WILFOOT 2.0 — Design Android

- Interface dark navy + azul neon + dourado.
- Menu principal com Novo Jogo, Carregar, Editor, Rankings e Galeria de Troféus.
- Barra de navegação com Rankings.
- Tela Rankings com Bola de Ouro, Seleções, Clubes e Ligas.
- Layout responsivo: dois painéis em paisagem e uma coluna em telas estreitas.
- Mantidos os sistemas de 1.200 clubes, editor e motor 7.0.
- Foco de performance para Android/Moto G54.
