# WILFOOT 2.1

## Redesign Android
- Dashboard principal premium em paisagem.
- Hero de carreira com ações rápidas.
- Ranking de Bola de Ouro e Ranking de Seleções no topo.
- Ranking de Clubes, Ranking de Ligas e Galeria de Troféus.
- Próxima partida destacada.
- Central de carreira com Elenco, Táticas, Mercado, Competições e Editor de 1.200 clubes.
- Botões grandes para toque.
- Visual escuro de estádio com azul neon, branco e dourado.
- Mantido GL Compatibility para hardware móvel.

## Base preservada
- Motor 7.0 existente.
- Banco mundial de 1.200 clubes.
- Editor de equipes.
- Sistema de partidas, tabela, mercado, treino, contratos e save.
- Rankings e galeria já existentes.

## Observação
O container de desenvolvimento não possui o executável do Godot 4.7.2, portanto a validação final deve ser feita abrindo o projeto no Godot e executando `Main.tscn`.
