extends Control

# WILFOOT 2.1 — 0.4 + 0.5 + 95 times + redesign (lime/neon) + integração JSON + pacote ULTIMATE (Scripts/ e Data/)
# 0.4: atributos, potencial, contratos e negociação, mercado, treino por foco,
#      lesões, folha salarial, tabela e save/load.
# 0.5: interface vermelho/branco/preto, dashboard, escalação com 11 titulares + banco,
#      formações, mentalidade, pressão e linha defensiva.
# Godot 4.x / Android paisagem (1280x720).

signal dialog_closed(result)

# Paleta do redesign 0.7: fundo quase preto, verde-limão como destaque e verde neon como apoio.
const LIME = Color("#19A7FF")
const NEON = Color("#43D8FF")
const GOLD = Color("#FFC83D")
const DARK = Color("#050B14")
const PANEL = Color("#0B1420")
const PANEL2 = Color("#101D2D")
const BORDER = Color("#1D4668")
const PITCH = Color("#07131D")
const WHITE = Color("#F5F5F5")
const MUTED = Color("#8A8A90")
const DIM = Color("#5C5C61")
const GREEN = Color("#19C98B")
const YELLOW = Color("#FFC83D")
const LOSS = Color("#FCA5A5")

const SAVE_PATH = "user://wilfoot_save.json"
const SAVE_VERSION = "2.1"
const WORLD_EDIT_PATH := "user://wilfoot_mundo_1200_editado.json"

# Posição de cada um dos 11 slots de titular (índice = slot).
const SLOT_POS = ["GOL", "LE", "ZAG", "ZAG", "LD", "MC", "MEI", "MC", "PE", "ATA", "PD"]
# Linhas do campo, do ataque (topo) ao goleiro (base), em slots.
const PITCH_ROWS = [[8, 9, 10], [5, 6, 7], [1, 2, 3, 4], [0]]
const FORMATIONS = ["4-3-3", "4-2-3-1", "4-4-2", "3-5-2"]
const MENTALITIES = ["Defensiva", "Equilibrada", "Ofensiva", "Muito ofensiva"]
const MENTALITY_BONUS = {"Defensiva": 0, "Equilibrada": 0, "Ofensiva": 2, "Muito ofensiva": 4}
const PRESSINGS = ["Baixo", "Médio", "Alto"]
const LINES = ["Baixa", "Média", "Alta"]

# Anel de força do jogador (círculo de progresso).
class ForceRing extends Control:
    var value := 0
    var col := Color.WHITE

    func _init():
        custom_minimum_size = Vector2(48, 48)
        size_flags_vertical = Control.SIZE_SHRINK_CENTER

    func _draw():
        var c = size / 2.0
        var r = minf(size.x, size.y) / 2.0 - 4.0
        draw_arc(c, r, 0.0, TAU, 48, Color(1, 1, 1, 0.08), 3.0, true)
        draw_arc(c, r, -PI / 2.0, -PI / 2.0 + TAU * clampf(float(value), 0.0, 100.0) / 100.0, 48, col, 3.0, true)


# Campo em paisagem: linhas verdes + itens posicionados por fração (nx, ny).
class PitchView extends Control:
    var items := []

    func _ready():
        resized.connect(_layout)
        _layout()

    func _layout():
        for it in items:
            var n = it["node"]
            n.position = Vector2(it["nx"] * size.x, it["ny"] * size.y) - n.custom_minimum_size / 2.0
        queue_redraw()

    func _draw():
        var w = size.x
        var h = size.y
        var m = 14.0
        var c1 = Color(0, 1, 0.533, 0.30)
        var c2 = Color(0, 1, 0.533, 0.20)
        draw_rect(Rect2(m, m, w - 2.0 * m, h - 2.0 * m), c1, false, 1.5)
        draw_line(Vector2(w / 2.0, m), Vector2(w / 2.0, h - m), Color(0, 1, 0.533, 0.25), 1.0)
        draw_arc(Vector2(w / 2.0, h / 2.0), h * 0.14, 0.0, TAU, 48, c1, 1.0, true)
        draw_circle(Vector2(w / 2.0, h / 2.0), 4.0, Color(0, 1, 0.533, 1.0))
        var bh = (h - 2.0 * m) * 0.56
        var bw = w * 0.15
        draw_rect(Rect2(m, h / 2.0 - bh / 2.0, bw, bh), c1, false, 1.0)
        draw_rect(Rect2(w - m - bw, h / 2.0 - bh / 2.0, bw, bh), c1, false, 1.0)
        draw_rect(Rect2(m, h / 2.0 - bh / 4.0, bw / 2.0, bh / 2.0), c2, false, 1.0)
        draw_rect(Rect2(w - m - bw / 2.0, h / 2.0 - bh / 4.0, bw / 2.0, bh / 2.0), c2, false, 1.0)


# Ícone de "play": círculo preto com triângulo verde-limão.
class PlayIcon extends Control:
    func _init():
        custom_minimum_size = Vector2(32, 32)

    func _draw():
        var c = size / 2.0
        draw_circle(c, 16.0, Color.BLACK)
        draw_colored_polygon(PackedVector2Array([c + Vector2(-4, -8), c + Vector2(-4, 8), c + Vector2(8, 0)]), Color("#C8FF00"))


const USER_LEAGUE = "br_a"
const Z_LIB = Color("#2F6BFF")
const Z_PRE = Color("#6FA8FF")
const Z_SUL = Color("#36C98F")
const Z_REB = Color("#E5334B")
const Z_NEUTRAL = Color("#3A414B")

# 40 times brasileiros (Série A e B) + 55 do resto do mundo = 95 times. [nome, força]
const LEAGUES = [
    {"id":"br_a","name":"Brasileirão Série A","short":"BRASIL","teams":[
        ["Flamengo",85],["Palmeiras",84],["Botafogo",79],["Fluminense",78],["Internacional",78],["São Paulo",78],["Corinthians",76],["Atlético-MG",79],["Grêmio",76],["Cruzeiro",75],["Bahia",74],["Vasco",73]]},
    {"id":"eng","name":"Premier League","short":"INGLATERRA","teams":[
        ["Manchester City",91],["Liverpool",90],["Arsenal",89],["Chelsea",85],["Manchester United",82],["Tottenham",82],["Newcastle",83],["Aston Villa",82],["Brighton",78],["West Ham",76],["Crystal Palace",74],["Everton",73]]},
    {"id":"esp","name":"La Liga","short":"ESPANHA","teams":[
        ["Real Madrid",92],["Barcelona",90],["Atlético de Madrid",87],["Athletic Club",81],["Real Sociedad",80],["Villarreal",80],["Real Betis",79],["Sevilla",77],["Valencia",76],["Girona",78],["Osasuna",73],["Celta",72]]},
    {"id":"ita","name":"Serie A","short":"ITÁLIA","teams":[
        ["Inter de Milão",89],["Milan",85],["Juventus",85],["Napoli",84],["Atalanta",84],["Roma",82],["Lazio",80],["Fiorentina",79],["Bologna",78],["Torino",74],["Udinese",73],["Genoa",73]]},
    {"id":"ger","name":"Bundesliga","short":"ALEMANHA","teams":[
        ["Bayern de Munique",91],["Bayer Leverkusen",88],["Borussia Dortmund",86],["RB Leipzig",84],["Stuttgart",81],["Eintracht Frankfurt",80],["Wolfsburg",76],["Freiburg",76],["Mainz",74],["Borussia Mönchengladbach",74],["Hoffenheim",73],["Werder Bremen",73]]},
    {"id":"fra","name":"Ligue 1","short":"FRANÇA","teams":[
        ["Paris Saint-Germain",89],["Monaco",82],["Olympique de Marseille",81],["Lille",80],["Lyon",79],["Nice",77],["Lens",77],["Rennes",76],["Strasbourg",73],["Toulouse",72],["Nantes",71],["Montpellier",70]]},
    {"id":"por","name":"Liga Portugal","short":"PORTUGAL","teams":[
        ["Benfica",84],["Porto",84],["Sporting",84],["Braga",78],["Vitória de Guimarães",74],["Rio Ave",71],["Famalicão",71],["Boavista",70],["Gil Vicente",70],["Estoril",69],["Arouca",69],["Casa Pia",68]]},
    {"id":"ned","name":"Eredivisie","short":"HOLANDA","teams":[
        ["PSV",83],["Ajax",82],["Feyenoord",82],["AZ Alkmaar",76],["Twente",75],["Utrecht",72],["Heerenveen",70],["Groningen",69],["Sparta Rotterdam",69],["NEC",68],["Go Ahead Eagles",67],["Fortuna Sittard",66]]},
    {"id":"arg","name":"Liga Argentina","short":"ARGENTINA","teams":[
        ["River Plate",83],["Boca Juniors",82],["Racing",78],["Independiente",75],["San Lorenzo",74],["Estudiantes",76],["Lanús",73],["Vélez Sarsfield",75],["Talleres",75],["Rosario Central",73],["Newell's Old Boys",72],["Huracán",70]]},
    {"id":"sau","name":"Saudi Pro League","short":"ARÁBIA SAUDITA","teams":[
        ["Al Hilal",86],["Al Nassr",84],["Al Ittihad",82],["Al Ahli",80],["Al Qadsiah",75],["Al Ettifaq",73],["Al Shabab",73],["Al Fateh",69],["Al Taawoun",71],["Al Riyadh",66],["Damac",66],["Al Khaleej",65]]}
]

const ATTR_ORDER = ["fin", "pas", "dri", "spd", "phy", "def"]
const FOCUS = [["fin", "Finalização"], ["pas", "Passe"], ["dri", "Drible"], ["spd", "Velocidade"], ["phy", "Físico"], ["def", "Defesa"]]
# Diferença de cada atributo em relação ao overall, por posição (ordem de ATTR_ORDER).
const PROFILES = {
    "GOL": [-63, -18, -53, -28, 2, 9],
    "ZAG": [-47, -7, -32, -12, 11, 9],
    "LE": [-39, -5, -9, 8, -4, 0],
    "LD": [-39, -5, -9, 8, -4, 0],
    "VOL": [-25, 2, -10, -6, 6, 6],
    "MC": [-13, 4, 3, -4, -12, -20],
    "MEI": [-7, 5, -1, -9, -11, -34],
    "PE": [-3, -4, 6, 10, -8, -45],
    "PD": [-3, -4, 6, 10, -8, -45],
    "ATA": [2, -8, 4, 8, -4, -51]
}

var club = {}
var coach = {}
var world_match_log: Array = []
var round_no := 1
var current_screen := "home"
var selected_player := 0
var selected_slot := -1
var formation := "4-3-3"
var mentality := "Equilibrada"
var pressing := "Médio"
var defensive_line := "Média"
var last_result := "Pronto para a próxima partida."
var message := ""

var players := []
var starters := []
var bench := []

var market := []

var season := 2026
var tables := {}          # id da liga -> lista de linhas da tabela
var last_results := {}    # id da liga -> {"round": n, "games": [textos]}
var schedules := {}       # id da liga -> rodadas -> jogos [casa, fora] (gerado, não vai pro save)
var team_ratings := {}    # nome do time -> força (gerado, não vai pro save)
var world_database: Dictionary = {} # 1.200 clubes: 120 por país
var world_team_editor_catalog: Array[Dictionary] = []
var engine7: WilfootEngine7
var engine7_status: Dictionary = {}
var table_league := "br_a"

# Integração com o export web (rodada em JSON). Leitura em res://, gravação sempre em user://.
@export var rodada_json_path: String = "res://Data/rodada_12.json"

var rodada_data: Dictionary = {}
var rodada_importada := false
var last_export := {}

var root_ui: Control
var content: VBoxContainer
var scroll_box: ScrollContainer
var money_label: Label
var round_label: Label
var temp_label: Label
var bold_font: FontVariation
var wide_font: FontVariation
var boot_root: Control
var boot_bar: ProgressBar
var boot_pct: Label
var match_history := []
var live_root: Control
var live_timer: Timer
var live_min := 0
var live_events := []
var live_home := ""
var live_away := ""
var live_hg := 0
var live_ag := 0
var live_title: Label
var live_minute: Label
var live_bar: ProgressBar
var live_log: VBoxContainer
var live_scroll: ScrollContainer
var live_view: PitchView
var live_status: Label
var live_done_btn: Button
var nav_buttons := {}
var menu_root: Control
var menu_msg: Label
var menu_buttons := {}
var menu_bg: TextureRect
var menu_overlay: ColorRect
var menu_language_built: String = ""


func _ready():
    randomize()
    if is_instance_valid(WilfootLocalization):
        WilfootLocalization.language_changed.connect(_on_language_changed)
    engine7 = WilfootEngine7.new()
    if engine7.load_database():
        engine7_status = engine7.validate()
        world_database = engine7.database
    else:
        engine7_status = {"ok": false, "errors": ["Falha ao carregar o motor 7.0"]}
    load_world_database()
    make_fonts()
    carregar_rodada(true)
    reset_game()
    build_ui()
    show_screen("home")
    build_menu_21()
    build_boot()

func _on_language_changed(_language_id: String) -> void:
    if is_instance_valid(root_ui) and is_instance_valid(content):
        show_screen(current_screen)

func loc_text(source_text: String) -> String:
    if is_instance_valid(WilfootLocalization):
        return WilfootLocalization.tr_text(source_text)
    return source_text

func load_world_database() -> void:
    var source_path := WORLD_EDIT_PATH if FileAccess.file_exists(WORLD_EDIT_PATH) else "res://Data/mundo_1200_clubes.json"
    var f := FileAccess.open(source_path, FileAccess.READ)
    if f == null:
        if world_database.is_empty():
            world_database = {}
        return
    var parsed: Variant = JSON.parse_string(f.get_as_text())
    f.close()
    if typeof(parsed) != TYPE_DICTIONARY:
        return
    world_database = parsed as Dictionary
    _rebuild_world_team_catalog()
    # Os 1.200 clubes também entram no radar do motor de partidas.
    for country in world_database.get("countries", []):
        var teams = country.get("teams", [])
        for i in teams.size():
            var club_name: String = str(teams[i])
            var rating: float = 56.0
            if i < 20:
                rating = 92.0 - float(i) * 1.2
            elif i < 40:
                rating = 70.0 - float(i - 20) * 0.4
            elif i < 60:
                rating = 62.0 - float(i - 40) * 0.25
            else:
                rating = 57.0 - float(i - 60) * 0.08
            team_ratings[club_name] = rating

func _rebuild_world_team_catalog() -> void:
    world_team_editor_catalog.clear()
    var countries: Array = world_database.get("countries", []) as Array
    for country_index in countries.size():
        var country_data: Dictionary = countries[country_index] as Dictionary
        var country_name: String = str(country_data.get("country", "País %d" % (country_index + 1)))
        var divisions: Array = country_data.get("divisions", []) as Array
        for division_index in divisions.size():
            var division_data: Dictionary = divisions[division_index] as Dictionary
            var division_name: String = str(division_data.get("name", "Divisão"))
            var teams: Array = division_data.get("teams", []) as Array
            for team_index in teams.size():
                var team_name: String = str(teams[team_index]).strip_edges()
                if team_name.is_empty():
                    continue
                world_team_editor_catalog.append({
                    "country_index": country_index,
                    "division_index": division_index,
                    "team_index": team_index,
                    "country": country_name,
                    "division": division_name,
                    "name": team_name
                })

func _world_ref_data(ref: Dictionary) -> Dictionary:
    var result: Dictionary = {
        "name": str(ref.get("name", "Clube")),
        "short_name": "",
        "city": "",
        "stadium": "Estádio Principal",
        "capacity": 10000,
        "reputation": 60,
        "board_goal": "Evoluir na divisão",
        "money": 5000000.0,
        "wage_budget": 150000.0,
        "cor_primaria": "#D71920",
        "cor_secundaria": "#FFFFFF",
        "cor_terciaria": "#111111",
        "country": str(ref.get("country", "")),
        "division": str(ref.get("division", ""))
    }
    var saved: Variant = world_database.get("club_metadata", {})
    if saved is Dictionary:
        var key: String = "%d:%d:%d" % [int(ref.get("country_index", -1)), int(ref.get("division_index", -1)), int(ref.get("team_index", -1))]
        var entry: Variant = (saved as Dictionary).get(key, {})
        if entry is Dictionary:
            var entry_dict: Dictionary = entry as Dictionary
            var entry_keys: Array = entry_dict.keys()
            for key_index in entry_keys.size():
                var key_name: String = str(entry_keys[key_index])
                result[key_name] = entry_dict[entry_keys[key_index]]
    return result

func _save_world_database_edit() -> bool:
    world_database["total_countries"] = int(world_database.get("countries", []).size())
    world_database["total_teams"] = 0
    for country_data in world_database.get("countries", []):
        if country_data is Dictionary:
            world_database["total_teams"] = int(world_database["total_teams"]) + int((country_data as Dictionary).get("total_teams", 0))
    var file: FileAccess = FileAccess.open(WORLD_EDIT_PATH, FileAccess.WRITE)
    if file == null:
        return false
    file.store_string(JSON.stringify(world_database, "\t"))
    file.close()
    return true

func _set_world_team_name(ref: Dictionary, new_name: String) -> void:
    var countries: Array = world_database.get("countries", []) as Array
    var ci: int = int(ref.get("country_index", -1))
    var di: int = int(ref.get("division_index", -1))
    var ti: int = int(ref.get("team_index", -1))
    if ci < 0 or ci >= countries.size():
        return
    var country_data: Dictionary = countries[ci] as Dictionary
    var divisions: Array = country_data.get("divisions", []) as Array
    if di < 0 or di >= divisions.size():
        return
    var division_data: Dictionary = divisions[di] as Dictionary
    var teams: Array = division_data.get("teams", []) as Array
    if ti < 0 or ti >= teams.size():
        return
    var old_name: String = str(teams[ti])
    teams[ti] = new_name
    division_data["teams"] = teams
    divisions[di] = division_data
    country_data["divisions"] = divisions
    var root_teams: Array = country_data.get("teams", []) as Array
    for i in root_teams.size():
        if str(root_teams[i]) == old_name:
            root_teams[i] = new_name
            break
    country_data["teams"] = root_teams
    countries[ci] = country_data
    world_database["countries"] = countries
    ref["name"] = new_name

func reset_game():
    club = {
        "name": "Internacional", "money": 42950000.0, "wage_budget": 1250000.0,
        "board_goal": "Terminar no G6", "reputation": 78
    }
    coach = {"name":"Novo Treinador", "age":35, "nationality":"Brasil", "style":"Equilibrado", "formation":"4-3-3", "reputation":50, "attack":50, "defense":50, "development":50, "negotiation":50}
    round_no = 1
    selected_player = 0
    selected_slot = -1
    formation = "4-3-3"
    mentality = "Equilibrada"
    pressing = "Médio"
    defensive_line = "Média"
    last_result = "Pronto para a próxima partida."
    message = ""
    market = [
        {"name": "André Costa", "pos": "ATA", "age": 22, "overall": 77, "potential": 85, "value": 3100000.0, "salary": 13000.0},
        {"name": "Bruno Reis", "pos": "MEI", "age": 20, "overall": 75, "potential": 89, "value": 2500000.0, "salary": 9000.0},
        {"name": "Felipe Rocha", "pos": "ZAG", "age": 25, "overall": 80, "potential": 82, "value": 4800000.0, "salary": 19000.0},
        {"name": "Gabriel Nunes", "pos": "VOL", "age": 21, "overall": 76, "potential": 86, "value": 2900000.0, "salary": 11000.0}
    ]
    season = 2026
    match_history = []
    table_league = USER_LEAGUE
    build_world()
    reset_tables()
    reset_roster()



# ---------------------------------------------------------------- ELENCO / DADOS

func reset_roster():
    # Ordem importa: os 11 primeiros são os titulares e seguem SLOT_POS.
    players = [
        {"name": "Diego Alves Jr.", "pos": "GOL", "number": 1, "age": 20, "overall": 73, "potential": 85, "value": 1800000.0, "salary": 7000.0, "years": 4, "bonus": 25000.0, "clause": 5500000.0, "form": 6, "morale": 80, "fatigue": 5, "injured": false, "injury_days": 0, "attrs": {"fin": 10, "pas": 55, "dri": 20, "spd": 45, "phy": 75, "def": 82}},
        {"name": "Rafael Santos", "pos": "LE", "number": 6, "age": 22, "overall": 74, "potential": 83, "value": 2000000.0, "salary": 9000.0, "years": 3, "bonus": 30000.0, "clause": 6000000.0, "form": 7, "morale": 77, "fatigue": 8, "injured": false, "injury_days": 0, "attrs": {"fin": 35, "pas": 69, "dri": 65, "spd": 82, "phy": 70, "def": 74}},
        {"name": "João Vitor", "pos": "ZAG", "number": 3, "age": 24, "overall": 77, "potential": 82, "value": 3500000.0, "salary": 14000.0, "years": 2, "bonus": 40000.0, "clause": 9000000.0, "form": 7, "morale": 75, "fatigue": 10, "injured": false, "injury_days": 0, "attrs": {"fin": 30, "pas": 70, "dri": 45, "spd": 65, "phy": 88, "def": 86}},
        make_player("Henrique Silva", "ZAG", 25, 75, 4, 13000, 12, 74),
        make_player("Lucas Mendes", "LD", 23, 72, 2, 8500, 9, 76),
        {"name": "Caio Mendes", "pos": "MC", "number": 8, "age": 19, "overall": 78, "potential": 88, "value": 3900000.0, "salary": 10000.0, "years": 4, "bonus": 35000.0, "clause": 10000000.0, "form": 8, "morale": 86, "fatigue": 18, "injured": false, "injury_days": 0, "attrs": {"fin": 65, "pas": 82, "dri": 81, "spd": 74, "phy": 66, "def": 58}},
        {"name": "Matheus Lima", "pos": "MEI", "number": 10, "age": 23, "overall": 79, "potential": 86, "value": 4200000.0, "salary": 18000.0, "years": 3, "bonus": 80000.0, "clause": 12000000.0, "form": 8, "morale": 82, "fatigue": 15, "injured": false, "injury_days": 0, "attrs": {"fin": 72, "pas": 84, "dri": 78, "spd": 70, "phy": 68, "def": 45}},
        make_player("Bruno Martins", "MC", 21, 74, 5, 9000, 11, 79),
        make_player("Pedro Henrique", "PE", 22, 75, 11, 11000, 14, 80),
        {"name": "Lucas Ferreira", "pos": "ATA", "number": 9, "age": 21, "overall": 76, "potential": 84, "value": 2800000.0, "salary": 12000.0, "years": 2, "bonus": 50000.0, "clause": 8000000.0, "form": 7, "morale": 78, "fatigue": 12, "injured": false, "injury_days": 0, "attrs": {"fin": 78, "pas": 68, "dri": 80, "spd": 84, "phy": 72, "def": 25}},
        make_player("Gabriel Costa", "PD", 20, 74, 7, 9500, 10, 81),
        make_player("André Rocha", "GOL", 25, 70, 12, 6000, 4, 72),
        make_player("Felipe Santos", "ZAG", 22, 71, 14, 6500, 7, 75),
        make_player("Igor Alves", "LD", 21, 70, 15, 6000, 6, 78),
        make_player("Renan Lima", "VOL", 24, 73, 16, 8000, 9, 76),
        make_player("João Pedro", "MEI", 20, 72, 17, 7000, 8, 79),
        make_player("Mateus Rocha", "PE", 19, 71, 18, 5500, 5, 83),
        make_player("Rafael Lima", "ATA", 23, 72, 19, 7500, 7, 77)
    ]
    reset_lineup()


func reset_lineup():
    starters = []
    bench = []
    for i in players.size():
        if i < 11:
            starters.append(i)
        else:
            bench.append(i)


func make_player(pname, pos, age, ovr, num, salary, fatigue, morale):
    var p = {
        "name": pname, "pos": pos, "age": age, "overall": ovr, "number": num,
        "salary": float(salary), "fatigue": fatigue, "morale": morale
    }
    fill_defaults(p)
    return p


func attrs_for(pos, ovr):
    var prof = PROFILES.get(pos, PROFILES["MC"])
    var a = {}
    for k in ATTR_ORDER.size():
        a[ATTR_ORDER[k]] = clampi(int(ovr) + int(prof[k]), 5, 99)
    return a


func next_number():
    var used = {}
    for q in players:
        if typeof(q) == TYPE_DICTIONARY and q.has("number"):
            used[int(q["number"])] = true
    for n in range(1, 100):
        if not used.has(n):
            return n
    return 99


# Completa campos que faltem (jogador novo, save antigo) e normaliza tipos (JSON devolve floats).
func fill_defaults(p):
    var ovr = int(p.get("overall", 70))
    var age = int(p.get("age", 22))
    var pos = str(p.get("pos", "MC"))
    var salary = float(p.get("salary", 8000.0))
    p["overall"] = ovr
    p["age"] = age
    p["pos"] = pos
    p["salary"] = salary
    if not p.has("name"): p["name"] = "Jogador"
    if not p.has("potential"): p["potential"] = mini(95, ovr + clampi(27 - age, 1, 10))
    p["potential"] = maxi(int(p["potential"]), ovr)
    if not p.has("value"): p["value"] = maxf(200000.0, float(ovr - 60) * 130000.0 + float(int(p["potential"]) - ovr) * 90000.0)
    p["value"] = float(p["value"])
    if not p.has("years"): p["years"] = 2
    if not p.has("bonus"): p["bonus"] = salary * 4.0
    if not p.has("clause"): p["clause"] = float(p["value"]) * 2.5
    if not p.has("form"): p["form"] = 7
    if not p.has("morale"): p["morale"] = 75
    if not p.has("fatigue"): p["fatigue"] = 0
    if not p.has("injured"): p["injured"] = false
    if not p.has("injury_days"): p["injury_days"] = 0
    if not p.has("number"): p["number"] = next_number()
    if not p.has("attrs"): p["attrs"] = attrs_for(pos, ovr)
    for k in ["years", "form", "morale", "fatigue", "injury_days", "number"]:
        p[k] = int(p[k])
    for k in ["bonus", "clause"]:
        p[k] = float(p[k])
    p["injured"] = bool(p["injured"])
    for k in ATTR_ORDER:
        p["attrs"][k] = int(p["attrs"].get(k, ovr))


func wage_bill():
    var total = 0.0
    for p in players:
        total += p.salary
    return total


func avg_morale():
    var total = 0.0
    for p in players:
        total += p.morale
    return int(roundf(total / float(players.size())))


func my_standing():
    for s in tables[USER_LEAGUE]:
        if s.name == club.name:
            return s
    return tables[USER_LEAGUE][0]


func money_str(v):
    var x = float(v)
    if x >= 1000000.0:
        return ("R$ %.2fM" % (x / 1000000.0)).replace(".", ",")
    if x >= 1000.0:
        return ("R$ %.1fk" % (x / 1000.0)).replace(".", ",")
    return "R$ %.0f" % x


func next_in(options, current):
    return options[(options.find(current) + 1) % options.size()]


# ---------------------------------------------------------------- MUNDO / CAMPEONATOS

# Calendário de pontos corridos (turno e returno) pelo método do círculo.
func make_schedule(teams):
    var t = teams.duplicate()
    if t.size() % 2 == 1:
        t.append("")  # folga
    var n = t.size()
    var rounds = []
    for r in n - 1:
        var games = []
        for i in int(n / 2.0):
            var a = t[i]
            var b = t[n - 1 - i]
            if a == "" or b == "":
                continue
            if (r + i) % 2 == 0:
                games.append([a, b])
            else:
                games.append([b, a])
        rounds.append(games)
        t.insert(1, t.pop_back())
    var second = []
    for games in rounds:
        var g2 = []
        for g in games:
            g2.append([g[1], g[0]])
        second.append(g2)
    return rounds + second


func build_world():
    team_ratings = {}
    schedules = {}
    for lg in LEAGUES:
        var names = []
        for t in lg.teams:
            names.append(t[0])
            team_ratings[t[0]] = t[1]
        schedules[lg.id] = make_schedule(names)
    # Reinsere os 1.200 clubes do banco mundial no motor de força.
    for country in world_database.get("countries", []):
        var teams = country.get("teams", [])
        for i in teams.size():
            var club_name: String = str(teams[i])
            if not team_ratings.has(club_name):
                var rating: float = 56.0
                if i < 20:
                    rating = 92.0 - float(i) * 1.2
                elif i < 40:
                    rating = 70.0 - float(i - 20) * 0.4
                elif i < 60:
                    rating = 62.0 - float(i - 40) * 0.25
                else:
                    rating = 57.0 - float(i - 60) * 0.08
                team_ratings[club_name] = rating


func reset_tables():
    tables = {}
    last_results = {}
    for lg in LEAGUES:
        var rows = []
        for t in lg.teams:
            rows.append({"name": t[0], "p": 0, "j": 0, "v": 0, "e": 0, "d": 0, "gp": 0, "gc": 0})
        tables[lg.id] = rows
        last_results[lg.id] = {"round": 0, "games": []}


func league_of(id):
    for lg in LEAGUES:
        if lg.id == id:
            return lg
    return LEAGUES[0]


func season_rounds():
    return schedules[USER_LEAGUE].size()


func user_fixture(r: int) -> Dictionary:
    var sched: Array = schedules[USER_LEAGUE]
    if r < 1 or r > sched.size():
        return {}
    for g: Array in sched[r - 1]:
        if g[0] == club.name:
            return {"opp": g[1], "home": true}
        if g[1] == club.name:
            return {"opp": g[0], "home": false}
    return {}


func fixture_title(fx):
    if fx.home:
        return "%s x %s" % [club.name, fx.opp]
    return "%s x %s" % [fx.opp, club.name]


func _cmp_table(a, b):
    if a.p != b.p:
        return a.p > b.p
    if a.v != b.v:
        return a.v > b.v
    if (a.gp - a.gc) != (b.gp - b.gc):
        return (a.gp - a.gc) > (b.gp - b.gc)
    return a.gp > b.gp


func sorted_table(league_id):
    var rows = tables[league_id].duplicate()
    rows.sort_custom(_cmp_table)
    return rows


func position_of(team, league_id):
    var rows = sorted_table(league_id)
    for i in rows.size():
        if rows[i].name == team:
            return i + 1
    return 0


func poisson(lam):
    var limit = exp(-lam)
    var k = 0
    var p = 1.0
    while k < 9:
        p *= randf()
        if p <= limit:
            return k
        k += 1
    return k


func forca_time_estimada(nome):
    if team_ratings.has(nome):
        var r = float(team_ratings[nome])
        return {"ataque": r, "defesa": r}
    var h = absi(nome.hash()) % 30
    return {"ataque": 65.0 + float(h), "defesa": 65.0 + float(29 - h) * 0.5}


func simular_jogo_importado(jogo, casa_em_casa := true):
    var nome_casa = jogo_time(jogo, true)
    var nome_fora = jogo_time(jogo, false)
    var fc = forca_time_estimada(nome_casa)
    var ff = forca_time_estimada(nome_fora)
    var vantagem = 6.0 if casa_em_casa else 0.0
    var lam_casa = clampf(1.35 + (fc.ataque - ff.defesa + vantagem) / 20.0, 0.15, 4.5)
    var lam_fora = clampf(1.2 + (ff.ataque - fc.defesa) / 20.0, 0.15, 4.5)
    var gc = poisson(lam_casa)
    var gf = poisson(lam_fora)
    jogo["placar"] = "%d x %d" % [gc, gf]
    jogo["gols_casa"] = gc
    jogo["gols_fora"] = gf
    jogo["finalizado"] = true
    return jogo


func ai_match(a, b):
    var ra = float(team_ratings.get(a, 70))
    var rb = float(team_ratings.get(b, 70))
    var ga = poisson(clampf(1.35 + (ra - rb) / 16.0 + 0.2, 0.15, 4.5))
    var gb = poisson(clampf(1.2 + (rb - ra) / 16.0, 0.15, 4.5))
    return [ga, gb]


func apply_result(row, gf, ga):
    row.j += 1
    row.gp += gf
    row.gc += ga
    if gf > ga:
        row.v += 1
        row.p += 3
    elif gf == ga:
        row.e += 1
        row.p += 1
    else:
        row.d += 1


func record_game(league_id, home_team, hg, away_team, ag):
    for row in tables[league_id]:
        if row.name == home_team:
            apply_result(row, hg, ag)
        elif row.name == away_team:
            apply_result(row, ag, hg)


# Todos os outros jogos da rodada r, em todas as ligas (menos o jogo do usuário).
func play_world_round(r):
    last_export = {}
    if engine7 != null and engine7_status.get("ok", false):
        for country_name in engine7.countries.keys():
            var divisions = engine7.countries[country_name].get("divisions", [])
            for division_data in divisions:
                var division_name := str(division_data.get("name", ""))
                if division_name == "Divisões regionais":
                    # Regionais são simuladas em grupos de 20 usando o banco já carregado.
                    continue
                engine7.simulate_round(str(country_name), division_name, r)

    for lg in LEAGUES:
        var sched = schedules[lg.id]
        if r > sched.size():
            continue
        var games = []
        var jogos = []
        for g: Array in sched[r - 1]:
            if lg.id == USER_LEAGUE and (g[0] == club.name or g[1] == club.name):
                continue
            var sc = ai_match(g[0], g[1])
            record_game(lg.id, g[0], sc[0], g[1], sc[1])
            games.append("%s %d x %d %s" % [g[0], sc[0], sc[1], g[1]])
            jogos.append({"casa": g[0], "fora": g[1], "placar": "%d x %d" % [sc[0], sc[1]]})
        last_results[lg.id] = {"round": r, "games": games}
        last_export[lg.id] = jogos


func new_season():
    season += 1
    round_no = 1
    last_result = "Nova temporada iniciada."
    reset_tables()
    for p in players:
        p.fatigue = 0
        p.injured = false
        p.injury_days = 0
    message = "Temporada %d começou!" % season
    save_game(true)
    show_screen("home")


# ---------------------------------------------------------------- UI BASE

func make_fonts():
    bold_font = FontVariation.new()
    bold_font.base_font = ThemeDB.fallback_font
    bold_font.variation_embolden = 0.6
    wide_font = FontVariation.new()
    wide_font.base_font = ThemeDB.fallback_font
    wide_font.variation_embolden = 0.6
    wide_font.spacing_glyph = 2


func make_box(color, radius := 7, mx := 12, my := 8, border := Color.TRANSPARENT, bw := 0):
    var sb = StyleBoxFlat.new()
    sb.bg_color = color
    sb.set_corner_radius_all(radius)
    sb.content_margin_left = mx
    sb.content_margin_right = mx
    sb.content_margin_top = my
    sb.content_margin_bottom = my
    if bw > 0:
        sb.set_border_width_all(bw)
        sb.border_color = border
    return sb


func make_panel(color := PANEL, radius := 20):
    var pc = PanelContainer.new()
    pc.add_theme_stylebox_override("panel", make_box(color, radius, 16, 14, BORDER, 1))
    return pc


func make_label(text, size_px := 14, color := WHITE, wide := false, align := HORIZONTAL_ALIGNMENT_LEFT) -> Label:
    var l = Label.new()
    l.text = loc_text(str(text))
    l.horizontal_alignment = align
    l.add_theme_font_size_override("font_size", size_px)
    l.add_theme_color_override("font_color", color)
    l.add_theme_font_override("font", wide_font if wide else bold_font)
    return l


func pill(text, bg, fg, size_px := 10, mx := 10, my := 3, border := Color.TRANSPARENT, bw := 0):
    var pc = PanelContainer.new()
    pc.add_theme_stylebox_override("panel", make_box(bg, 100, mx, my, border, bw))
    pc.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
    pc.size_flags_vertical = Control.SIZE_SHRINK_CENTER
    pc.add_child(make_label(text, size_px, fg, true))
    return pc


func pos_pill(pos):
    if pos == "ATA":
        return pill(pos, LIME, Color.BLACK, 9, 7, 2)
    if pos == "GOL":
        return pill(pos, Color(1, 1, 1, 0.10), Color(1, 1, 1, 0.6), 9, 7, 2)
    return pill(pos, Color(0, 1, 0.533, 0.15), NEON, 9, 7, 2, Color(0, 1, 0.533, 0.2), 1)


func stat_box(label, value, accent := false):
    var pc = PanelContainer.new()
    var bg = LIME if accent else PANEL2
    pc.add_theme_stylebox_override("panel", make_box(bg, 14, 12, 10, LIME if accent else BORDER, 1))
    pc.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    var vb = VBoxContainer.new()
    vb.add_theme_constant_override("separation", 4)
    pc.add_child(vb)
    vb.add_child(make_label(label, 9, Color(0, 0, 0, 0.6) if accent else DIM, true))
    vb.add_child(make_label(value, 14, Color.BLACK if accent else WHITE))
    return pc


func ignore_children(n):
    for c in n.get_children():
        if c is Control:
            c.mouse_filter = Control.MOUSE_FILTER_IGNORE
        ignore_children(c)


func card_button(height, cb):
    var b = Button.new()
    b.custom_minimum_size = Vector2(0, height)
    b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    b.add_theme_stylebox_override("normal", make_box(PANEL, 18, 0, 0, BORDER, 1))
    b.add_theme_stylebox_override("hover", make_box(PANEL2, 18, 0, 0, BORDER, 1))
    b.add_theme_stylebox_override("pressed", make_box(Color("#0F0F11"), 18, 0, 0, BORDER, 1))
    b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
    b.pressed.connect(cb)
    return b


func card_body(b, m := 12):
    var mc = MarginContainer.new()
    mc.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    mc.add_theme_constant_override("margin_left", m)
    mc.add_theme_constant_override("margin_right", m)
    mc.add_theme_constant_override("margin_top", 6)
    mc.add_theme_constant_override("margin_bottom", 6)
    b.add_child(mc)
    var hb = HBoxContainer.new()
    hb.add_theme_constant_override("separation", 12)
    mc.add_child(hb)
    return hb


func initials(n):
    var parts = str(n).split(" ")
    var s = ""
    for i in mini(2, parts.size()):
        s += parts[i].substr(0, 1)
    return s.to_upper()


func deaccent(s):
    var out = str(s).to_upper()
    for pair in [["Á", "A"], ["À", "A"], ["Â", "A"], ["Ã", "A"], ["É", "E"], ["Ê", "E"], ["Í", "I"], ["Ó", "O"], ["Ô", "O"], ["Õ", "O"], ["Ú", "U"], ["Ç", "C"]]:
        out = out.replace(pair[0], pair[1])
    return out


func abbr(n):
    return deaccent(n).substr(0, 3)


func avatar(pname, sz):
    var pc = PanelContainer.new()
    pc.custom_minimum_size = Vector2(sz, sz)
    pc.size_flags_vertical = Control.SIZE_SHRINK_CENTER
    pc.add_theme_stylebox_override("panel", make_box(Color("#1F1F22"), int(sz / 2.0), 0, 0, Color(1, 1, 1, 0.10), 1))
    var l = make_label(initials(pname), int(sz * 0.26), Color(1, 1, 1, 0.7), false, HORIZONTAL_ALIGNMENT_CENTER)
    l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    pc.add_child(l)
    return pc


func force_ring(v, sz := 48):
    var ring = ForceRing.new()
    ring.value = v
    ring.col = LIME if v > 85 else (NEON if v > 75 else WHITE)
    ring.custom_minimum_size = Vector2(sz, sz)
    var l = make_label(v, 12, WHITE, false, HORIZONTAL_ALIGNMENT_CENTER)
    l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    l.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    ring.add_child(l)
    return ring


func add_glow(parent, center, radius, color):
    for i in 8:
        var poly = Polygon2D.new()
        poly.polygon = circle_points(center, radius * (1.0 - float(i) / 9.0))
        poly.color = Color(color, color.a / 3.0)
        parent.add_child(poly)


func avg_overall():
    var total = 0.0
    for p in players:
        total += p.overall
    return int(roundf(total / float(players.size())))


func morale_label():
    var m = avg_morale()
    if m >= 80:
        return "Alta"
    if m >= 65:
        return "Média"
    return "Baixa"


func pill_button(text, active, cb, min_w := 0):
    var b = Button.new()
    b.text = loc_text(str(text))
    b.custom_minimum_size = Vector2(min_w, 38)
    b.add_theme_font_override("font", bold_font)
    b.add_theme_font_size_override("font_size", 12)
    var bg = LIME if active else Color("#222225")
    var fg = Color.BLACK if active else Color("#B5B5BA")
    b.add_theme_stylebox_override("normal", make_box(bg, 100, 16, 6))
    b.add_theme_stylebox_override("hover", make_box(Color("#D6FF33") if active else Color("#2C2C30"), 100, 16, 6))
    b.add_theme_stylebox_override("pressed", make_box(Color("#A8D400") if active else Color("#111113"), 100, 16, 6))
    b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
    for k in ["font_color", "font_hover_color", "font_pressed_color", "font_focus_color", "font_hover_pressed_color"]:
        b.add_theme_color_override(k, fg)
    b.pressed.connect(cb)
    return b


func style_button(b: Button, primary := false, min_h := 48):
    b.custom_minimum_size = Vector2(0, min_h)
    b.add_theme_font_override("font", bold_font)
    b.add_theme_font_size_override("font_size", 14)
    b.add_theme_color_override("font_outline_color", Color(0,0,0,0.35))
    b.add_theme_constant_override("outline_size", 2)
    var fg = Color.WHITE if primary else WHITE
    if primary:
        b.add_theme_stylebox_override("normal", make_box(LIME, 16, 16, 8, Color("#7AD8FF"), 1))
        b.add_theme_stylebox_override("hover", make_box(Color("#35B8FF"), 16, 16, 8))
        b.add_theme_stylebox_override("pressed", make_box(Color("#0877B8"), 16, 16, 8))
    else:
        b.add_theme_stylebox_override("normal", make_box(PANEL2, 16, 14, 8, BORDER, 1))
        b.add_theme_stylebox_override("hover", make_box(Color("#212125"), 16, 14, 8, BORDER, 1))
        b.add_theme_stylebox_override("pressed", make_box(Color("#0F0F11"), 16, 14, 8, BORDER, 1))
    b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
    for k in ["font_color", "font_hover_color", "font_pressed_color", "font_focus_color", "font_hover_pressed_color"]:
        b.add_theme_color_override(k, fg)


func style_nav(b: Button, active: bool):
    b.custom_minimum_size = Vector2(0, 52)
    b.add_theme_font_override("font", wide_font)
    b.add_theme_font_size_override("font_size", 11)
    b.add_theme_stylebox_override("normal", make_box(Color("#0B8CDE") if active else Color.TRANSPARENT, 16, 8, 6, Color("#1DA9FF") if active else Color.TRANSPARENT, 1 if active else 0))
    b.add_theme_stylebox_override("hover", make_box(Color("#117BBE") if active else Color(1, 1, 1, 0.06), 16, 8, 6))
    b.add_theme_stylebox_override("pressed", make_box(Color("#086AA8") if active else Color(1, 1, 1, 0.10), 16, 8, 6))
    b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
    var fg = Color.WHITE if active else Color("#9AAFC0")
    for k in ["font_color", "font_hover_color", "font_pressed_color", "font_focus_color", "font_hover_pressed_color"]:
        b.add_theme_color_override(k, fg)



func build_ui():
    root_ui = Control.new()
    root_ui.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(root_ui)

    var bg = ColorRect.new()
    bg.color = DARK
    bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    root_ui.add_child(bg)
    add_glow(root_ui, Vector2(200, 40), 420, Color(LIME, 0.05))
    add_glow(root_ui, Vector2(1120, 700), 380, Color(NEON, 0.05))

    var main = VBoxContainer.new()
    main.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    main.add_theme_constant_override("separation", 0)
    root_ui.add_child(main)

    # Cabeçalho: logo W, nome + versão, temporada e pílulas de caixa/rodada.
    var header = PanelContainer.new()
    header.add_theme_stylebox_override("panel", make_box(Color("#0C0C0E"), 0, 22, 10))
    main.add_child(header)
    var hb = HBoxContainer.new()
    hb.add_theme_constant_override("separation", 12)
    header.add_child(hb)

    var logo = PanelContainer.new()
    logo.custom_minimum_size = Vector2(36, 36)
    logo.size_flags_vertical = Control.SIZE_SHRINK_CENTER
    logo.add_theme_stylebox_override("panel", make_box(WHITE, 12, 0, 0))
    var lw = make_label("W", 18, Color.BLACK, false, HORIZONTAL_ALIGNMENT_CENTER)
    lw.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    logo.add_child(lw)
    hb.add_child(logo)

    var tb = VBoxContainer.new()
    tb.add_theme_constant_override("separation", 2)
    hb.add_child(tb)
    var r1 = HBoxContainer.new()
    r1.add_theme_constant_override("separation", 8)
    tb.add_child(r1)
    r1.add_child(make_label("WILFOOT", 18, WHITE))
    r1.add_child(pill("2.1", LIME, Color.WHITE, 9, 7, 1))
    var r2 = HBoxContainer.new()
    r2.add_theme_constant_override("separation", 8)
    tb.add_child(r2)
    temp_label = make_label("", 10, DIM, true)
    r2.add_child(temp_label)
    r2.add_child(make_label("•", 10, DIM, true))
    r2.add_child(make_label("SÉRIE A", 10, NEON, true))

    var sp = Control.new()
    sp.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    hb.add_child(sp)

    var mp = PanelContainer.new()
    mp.size_flags_vertical = Control.SIZE_SHRINK_CENTER
    mp.add_theme_stylebox_override("panel", make_box(Color(1, 1, 1, 0.06), 100, 14, 6, Color(1, 1, 1, 0.08), 1))
    money_label = make_label("", 13, WHITE)
    mp.add_child(money_label)
    hb.add_child(mp)
    var rp = PanelContainer.new()
    rp.size_flags_vertical = Control.SIZE_SHRINK_CENTER
    rp.add_theme_stylebox_override("panel", make_box(Color(1, 1, 1, 0.04), 100, 12, 6, Color(1, 1, 1, 0.06), 1))
    round_label = make_label("", 12, Color(1, 1, 1, 0.7))
    rp.add_child(round_label)
    hb.add_child(rp)

    var line = ColorRect.new()
    line.color = Color("#1E1E21")
    line.custom_minimum_size = Vector2(0, 1)
    main.add_child(line)

    var margin = MarginContainer.new()
    margin.size_flags_vertical = Control.SIZE_EXPAND_FILL
    margin.add_theme_constant_override("margin_left", 22)
    margin.add_theme_constant_override("margin_right", 22)
    margin.add_theme_constant_override("margin_top", 12)
    margin.add_theme_constant_override("margin_bottom", 8)
    main.add_child(margin)

    scroll_box = ScrollContainer.new()
    scroll_box.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    margin.add_child(scroll_box)

    content = VBoxContainer.new()
    content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    content.add_theme_constant_override("separation", 12)
    scroll_box.add_child(content)

    # Barra de navegação: aba ativa em branco com texto preto.
    var nav_panel = PanelContainer.new()
    var nsb = make_box(Color("#0C0C0E"), 0, 12, 8)
    nsb.border_width_top = 1
    nsb.border_color = Color("#1E1E21")
    nav_panel.add_theme_stylebox_override("panel", nsb)
    main.add_child(nav_panel)
    var nav = HBoxContainer.new()
    nav.add_theme_constant_override("separation", 6)
    nav_panel.add_child(nav)
    for item in [["INÍCIO", "home"], ["ELENCO", "squad"], ["TÁTICA", "tactics"], ["MERCADO", "market"], ["JOGOS", "jogos"], ["RANKINGS", "rankings"], ["MUNDO", "world"], ["MAIS", "more"]]:
        var b = Button.new()
        b.text = loc_text(str(item[0]))
        b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        b.pressed.connect(show_screen.bind(item[1]))
        style_nav(b, false)
        nav.add_child(b)
        nav_buttons[item[1]] = b


func refresh_header():
    money_label.text = money_str(club.money)
    round_label.text = "R%d" % mini(round_no, season_rounds())
    temp_label.text = "TEMP %d" % season


func nav_group(s):
    match s:
        "player":
            return "squad"
        "calendar":
            return "jogos"
        "training", "focus", "table", "results", "contracts", "titulos", "patrocinadores", "premiacoes", "coach", "trofeus", "language":
            return "more"
    return s


func update_nav():
    var g = nav_group(current_screen)
    for k in nav_buttons:
        style_nav(nav_buttons[k], k == g)


func clear_content():
    for n in content.get_children():
        content.remove_child(n)
        n.queue_free()


func heading(t, sub := "", pill_text := ""):
    var hb = HBoxContainer.new()
    hb.add_theme_constant_override("separation", 10)
    content.add_child(hb)
    var l = make_label(t, 19, WHITE, true)
    l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    hb.add_child(l)
    if pill_text != "":
        hb.add_child(pill(pill_text, LIME, Color.BLACK, 10, 10, 4))
    if sub != "":
        var s = Label.new()
        s.text = loc_text(str(sub))
        s.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
        s.add_theme_color_override("font_color", MUTED)
        s.add_theme_font_size_override("font_size", 13)
        content.add_child(s)


func info(t):
    var l = Label.new()
    l.text = t
    l.add_theme_color_override("font_color", Color("#D2D6DB"))
    l.add_theme_font_size_override("font_size", 16)
    l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    content.add_child(l)
    return l


func banner(t):
    var pc = PanelContainer.new()
    pc.add_theme_stylebox_override("panel", make_box(Color(LIME, 0.10), 16, 16, 12, Color(LIME, 0.35), 1))
    var l = Label.new()
    l.text = loc_text(str(t))
    l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    l.add_theme_color_override("font_color", LIME)
    l.add_theme_font_override("font", bold_font)
    l.add_theme_font_size_override("font_size", 15)
    pc.add_child(l)
    content.add_child(pc)


func action(text, cb, primary := false, parent = null):
    var b = Button.new()
    b.text = loc_text(str(text))
    b.pressed.connect(cb)
    style_button(b, primary)
    if parent == null:
        parent = content
    parent.add_child(b)
    return b


func show_screen(s):
    current_screen = s
    if s != "tactics":
        selected_slot = -1
    clear_content()
    scroll_box.scroll_vertical = 0
    refresh_header()
    update_nav()
    if message != "":
        banner(message)
        message = ""
    match s:
        "home": screen_home()
        "squad": screen_squad()
        "player": screen_player(selected_player)
        "tactics": screen_tactics()
        "market": screen_market()
        "training": screen_training()
        "focus": screen_focus()
        "more": screen_more()
        "table": screen_table()
        "results": screen_results()
        "titulos": screen_titulos()
        "patrocinadores": screen_patrocinadores()
        "premiacoes": screen_premiacoes()
        "jogos": screen_games()
        "world": screen_world()
        "rankings": screen_rankings()
        "coach": screen_coach()
        "language": screen_language()
        "trofeus": screen_trofeus()
        "calendar": screen_games()
        "contracts": screen_contracts()
        "world_live": screen_world_live()


# ---------------------------------------------------------------- WILFOOT 3.0 • MUNDO VIVO

func screen_world_live() -> void:
    heading("MUNDO VIVO", "Notícias, movimentações e sinais do futebol mundial.", "WILFOOT 3.0")
    var status_text: String = "Mundo ainda carregando..."
    if is_instance_valid(WilfootWorld3):
        status_text = WilfootWorld3.get_status_text()
    var status_panel := PanelContainer.new()
    status_panel.add_theme_stylebox_override("panel", make_box(Color(0.01, 0.055, 0.09, 0.96), 18, 14, 7, Color("#2088BA"), 1))
    content.add_child(status_panel)
    var status_box := VBoxContainer.new()
    status_box.add_theme_constant_override("separation", 4)
    status_panel.add_child(status_box)
    status_box.add_child(make_label("🌍  O FUTEBOL NÃO PARA", 13, GOLD, true))
    status_box.add_child(make_label(status_text, 11, MUTED, false))

    action("ATUALIZAR MUNDO", func():
        if is_instance_valid(WilfootWorld3):
            WilfootWorld3.refresh_now()
        show_screen("world_live")
    , true)

    var news_title := make_label("ÚLTIMAS MOVIMENTAÇÕES", 13, WHITE, true)
    content.add_child(news_title)
    if not is_instance_valid(WilfootWorld3):
        info("Sistema Mundo Vivo indisponível.")
        return

    var news: Array[Dictionary] = WilfootWorld3.get_headlines()
    for item in news:
        var icon_text: String = str(item.get("icon", "🌍"))
        var title_text: String = str(item.get("title", "Notícia"))
        var body_text: String = str(item.get("body", ""))
        var card := PanelContainer.new()
        card.custom_minimum_size = Vector2(0, 86)
        card.add_theme_stylebox_override("panel", make_box(Color(0.015, 0.045, 0.075, 0.95), 15, 12, 7, Color("#174D6D"), 1))
        content.add_child(card)
        var card_box := VBoxContainer.new()
        card_box.add_theme_constant_override("separation", 4)
        card.add_child(card_box)
        card_box.add_child(make_label(icon_text + "  " + title_text, 12, LIME, true))
        var body_label := make_label(body_text, 10, Color("#C5D4DE"), false)
        body_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
        card_box.add_child(body_label)

    var future := PanelContainer.new()
    future.add_theme_stylebox_override("panel", make_box(Color(0.05, 0.04, 0.015, 0.92), 16, 12, 7, Color(GOLD, 0.45), 1))
    content.add_child(future)
    var future_box := VBoxContainer.new()
    future_box.add_theme_constant_override("separation", 4)
    future.add_child(future_box)
    future_box.add_child(make_label("🧠 PRÓXIMA ETAPA", 12, GOLD, true))
    future_box.add_child(make_label("A fundação está isolada do motor de partidas. O próximo passo será ligar transferências, treinadores, resultados e evolução de clubes ao mundo sem quebrar o que já funciona.", 10, Color("#D8D0B8"), false))


# ---------------------------------------------------------------- TELAS

func team_block(team, role):
    var vb = VBoxContainer.new()
    vb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    vb.add_theme_constant_override("separation", 6)
    vb.add_child(crest(team, 64))
    vb.add_child(make_label(team.to_upper(), 13, WHITE, true, HORIZONTAL_ALIGNMENT_CENTER))
    vb.add_child(make_label("%s • %dº LUGAR" % [role, position_of(team, USER_LEAGUE)], 10, DIM, true, HORIZONTAL_ALIGNMENT_CENTER))
    return vb


func screen_home():
    var total = season_rounds()
    heading("PAINEL DO CLUBE", "Temporada %d • Rodada %d de %d" % [season, mini(round_no, total), total], club.name.to_upper())

    var cols = HBoxContainer.new()
    cols.add_theme_constant_override("separation", 14)
    content.add_child(cols)
    var left = VBoxContainer.new()
    left.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    left.add_theme_constant_override("separation", 12)
    cols.add_child(left)
    var right = VBoxContainer.new()
    right.custom_minimum_size = Vector2(400, 0)
    right.add_theme_constant_override("separation", 12)
    cols.add_child(right)

    # Cartão do próximo jogo
    var fx = user_fixture(round_no)
    var card = PanelContainer.new()
    card.add_theme_stylebox_override("panel", make_box(Color("#17171A"), 24, 20, 18, Color(1, 1, 1, 0.10), 1))
    left.add_child(card)
    var cv = VBoxContainer.new()
    cv.add_theme_constant_override("separation", 16)
    card.add_child(cv)

    var top = HBoxContainer.new()
    cv.add_child(top)
    var title_txt = "TEMPORADA ENCERRADA"
    if not fx.is_empty():
        title_txt = "PRÓXIMO JOGO • BRASILEIRÃO • RODADA %d" % round_no
    var tl = make_label(title_txt, 10, DIM, true)
    tl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    top.add_child(tl)
    top.add_child(pill("TEMPORADA %d" % season, LIME, Color.BLACK, 10, 10, 4))

    if fx.is_empty():
        cv.add_child(make_label("%dº LUGAR NO BRASILEIRÃO" % position_of(club.name, USER_LEAGUE), 26, WHITE, false, HORIZONTAL_ALIGNMENT_CENTER))
        cv.add_child(make_label("Meta da diretoria: " + club.board_goal, 13, MUTED, false, HORIZONTAL_ALIGNMENT_CENTER))
    else:
        var home_team = club.name if fx.home else fx.opp
        var away_team = fx.opp if fx.home else club.name
        var mr = HBoxContainer.new()
        mr.add_theme_constant_override("separation", 10)
        cv.add_child(mr)
        mr.add_child(team_block(home_team, "MANDANTE"))
        var mid = VBoxContainer.new()
        mid.size_flags_vertical = Control.SIZE_SHRINK_CENTER
        mid.add_theme_constant_override("separation", 10)
        mr.add_child(mid)
        var vs = PanelContainer.new()
        vs.custom_minimum_size = Vector2(56, 56)
        vs.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
        vs.add_theme_stylebox_override("panel", make_box(Color(1, 1, 1, 0.06), 28, 0, 0, Color(1, 1, 1, 0.10), 1))
        var vl = make_label("VS", 14, Color(1, 1, 1, 0.8), false, HORIZONTAL_ALIGNMENT_CENTER)
        vl.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
        vs.add_child(vl)
        mid.add_child(vs)
        var arena = "ARENA • 20:00" if fx.home else "FORA • 20:00"
        mid.add_child(pill(arena, Color(0, 0, 0, 0.6), Color(1, 1, 1, 0.8), 10, 10, 4, Color(1, 1, 1, 0.10), 1))
        mr.add_child(team_block(away_team, "VISITANTE"))

    var stats = HBoxContainer.new()
    stats.add_theme_constant_override("separation", 8)
    cv.add_child(stats)
    stats.add_child(stat_box("MORAL", "%s • %d%%" % [morale_label(), avg_morale()]))
    stats.add_child(stat_box("FOLHA", money_str(wage_bill())))
    stats.add_child(stat_box("PRÊMIO", money_str(450000.0), true))

    var hb = HBoxContainer.new()
    hb.add_theme_constant_override("separation", 10)
    left.add_child(hb)
    var b1 = action("ESCALAÇÃO", show_screen.bind("tactics"), false, hb)
    b1.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    b1.custom_minimum_size = Vector2(0, 56)
    var b2
    if fx.is_empty():
        b2 = action("INICIAR NOVA TEMPORADA", new_season, true, hb)
    else:
        b2 = action("JOGAR PARTIDA", simulate_match, true, hb)
    b2.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    b2.custom_minimum_size = Vector2(0, 56)

    # Classificação resumida (top 5 + sua posição se estiver fora)
    var cc = make_panel()
    right.add_child(cc)
    var cvb = VBoxContainer.new()
    cvb.add_theme_constant_override("separation", 8)
    cc.add_child(cvb)
    cvb.add_child(make_label("SÉRIE A • CLASSIFICAÇÃO", 11, Color(1, 1, 1, 0.8), true))
    var rows = sorted_table(USER_LEAGUE)
    var shown = []
    for i in 5:
        shown.append([i + 1, rows[i]])
    var my_pos = position_of(club.name, USER_LEAGUE)
    if my_pos > 5:
        shown.append([my_pos, rows[my_pos - 1]])
    for e in shown:
        var r = e[1]
        var mine = r.name == club.name
        var rr = HBoxContainer.new()
        rr.add_theme_constant_override("separation", 10)
        cvb.add_child(rr)
        rr.add_child(cell(e[0], 22, LIME if e[0] <= 2 else DIM, HORIZONTAL_ALIGNMENT_CENTER, 12))
        rr.add_child(crest(r.name, 24))
        var an = cell(abbr(r.name), 0, LIME if mine else Color(1, 1, 1, 0.9), HORIZONTAL_ALIGNMENT_LEFT, 12)
        an.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        rr.add_child(an)
        rr.add_child(cell("%dJ" % r.j, 34, DIM, HORIZONTAL_ALIGNMENT_CENTER, 11))
        rr.add_child(cell("%dP" % r.p, 34, WHITE, HORIZONTAL_ALIGNMENT_CENTER, 12))
        var sg = r.gp - r.gc
        rr.add_child(pill(("+" if sg > 0 else "") + str(sg), LIME if mine else Color(1, 1, 1, 0.10), Color.BLACK if mine else Color(1, 1, 1, 0.6), 10, 6, 1))
    action("CLASSIFICAÇÃO COMPLETA", show_screen.bind("table"), false, cvb)

    var rc = make_panel(Color("#0E0E10"))
    right.add_child(rc)
    var rvb = VBoxContainer.new()
    rvb.add_theme_constant_override("separation", 8)
    rc.add_child(rvb)
    rvb.add_child(make_label("ÚLTIMO RESULTADO", 11, DIM, true))
    var lr = make_label(last_result, 14, Color(1, 1, 1, 0.85))
    lr.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    rvb.add_child(lr)
    action("RESULTADOS DA RODADA", show_screen.bind("results"), false, rvb)


func player_status(i):
    var p = players[i]
    if p.injured:
        return "LESIONADO %dd" % p.injury_days
    if i in starters:
        return "TITULAR"
    return "BANCO"


func screen_squad():
    heading("ELENCO • %d JOGADORES" % players.size(), "Toque em um atleta para ver detalhes", "MÉDIA %d" % avg_overall())
    var grid = GridContainer.new()
    grid.columns = 2
    grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    grid.add_theme_constant_override("h_separation", 12)
    grid.add_theme_constant_override("v_separation", 10)
    content.add_child(grid)
    for i in players.size():
        var p = players[i]
        var b = card_button(76, open_player.bind(i))
        var hb = card_body(b)
        hb.add_child(avatar(p.name, 46))
        var vb = VBoxContainer.new()
        vb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        vb.size_flags_vertical = Control.SIZE_SHRINK_CENTER
        vb.add_theme_constant_override("separation", 4)
        hb.add_child(vb)
        var r1 = HBoxContainer.new()
        r1.add_theme_constant_override("separation", 8)
        vb.add_child(r1)
        var nl = make_label("%02d  %s" % [p.number, p.name], 13, WHITE)
        nl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        nl.clip_text = true
        nl.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
        r1.add_child(nl)
        r1.add_child(pos_pill(p.pos))
        var status_col = DIM
        if p.injured:
            status_col = LOSS
        elif i in starters:
            status_col = LIME
        vb.add_child(make_label("%dA  •  %s  •  %s" % [p.age, money_str(p.value), player_status(i)], 10, status_col))
        hb.add_child(force_ring(p.overall))
        ignore_children(b)
        grid.add_child(b)


func open_player(i):
    selected_player = i
    show_screen("player")


func screen_player(i):
    var p = players[i]
    heading(p.name, "%s • camisa %d • %d anos" % [p.pos, p.number, p.age], "GER %d" % p.overall)

    var card = make_panel()
    content.add_child(card)
    var hb = HBoxContainer.new()
    hb.add_theme_constant_override("separation", 16)
    card.add_child(hb)
    hb.add_child(avatar(p.name, 72))
    var vb = VBoxContainer.new()
    vb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    vb.size_flags_vertical = Control.SIZE_SHRINK_CENTER
    vb.add_theme_constant_override("separation", 6)
    hb.add_child(vb)
    var extra = ""
    if p.injured:
        extra = "  •  LESIONADO: %d dias" % p.injury_days
    var l1 = make_label("Potencial %d  •  Forma %d/10  •  Moral %d  •  Fadiga %d%%%s" % [p.potential, p.form, p.morale, p.fatigue, extra], 13, Color(1, 1, 1, 0.85))
    l1.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    vb.add_child(l1)
    var l2 = make_label("Valor %s  •  Salário %s/mês  •  Contrato %d anos  •  Multa %s" % [money_str(p.value), money_str(p.salary), p.years, money_str(p.clause)], 12, MUTED)
    l2.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    vb.add_child(l2)
    hb.add_child(force_ring(p.overall, 64))

    # Atributos (o maior fica destacado)
    var best = 0
    for k in ATTR_ORDER:
        best = maxi(best, int(p.attrs[k]))
    var ar = HBoxContainer.new()
    ar.add_theme_constant_override("separation", 8)
    content.add_child(ar)
    for a in [["FINALIZAÇÃO", "fin"], ["PASSE", "pas"], ["DRIBLE", "dri"], ["VELOCIDADE", "spd"], ["FÍSICO", "phy"], ["DEFESA", "def"]]:
        ar.add_child(stat_box(a[0], str(p.attrs[a[1]]), int(p.attrs[a[1]]) == best))

    var hb2 = HBoxContainer.new()
    hb2.add_theme_constant_override("separation", 10)
    content.add_child(hb2)
    var b1 = action("COLOCAR COMO TITULAR", promote_player.bind(i), true, hb2)
    b1.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    var b2 = action("MANDAR PARA O BANCO", bench_player.bind(i), false, hb2)
    b2.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    var hb3 = HBoxContainer.new()
    hb3.add_theme_constant_override("separation", 10)
    content.add_child(hb3)
    var b3 = action("NEGOCIAR CONTRATO", negotiate.bind(i), false, hb3)
    b3.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    var b4 = action("TREINAR ESTE JOGADOR", open_focus.bind(i), false, hb3)
    b4.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    action("VOLTAR AO ELENCO", show_screen.bind("squad"))


# ---------------------------------------------------------------- ESCALAÇÃO E TÁTICAS

func make_token(p, slot, selected):
    var sz = 58
    var b = Button.new()
    b.custom_minimum_size = Vector2(sz, sz)
    b.size = Vector2(sz, sz)
    b.text = deaccent(p.name.split(" ")[0]).substr(0, 3)
    b.add_theme_font_override("font", bold_font)
    b.add_theme_font_size_override("font_size", 12)
    var bg = LIME if selected else Color("#101010")
    var fg = Color.BLACK if selected else WHITE
    var border = Color("#FF4D4D") if p.injured else LIME
    b.add_theme_stylebox_override("normal", make_box(bg, int(sz / 2.0), 0, 0, border, 2))
    b.add_theme_stylebox_override("hover", make_box(Color("#1C1C1C") if not selected else Color("#D6FF33"), int(sz / 2.0), 0, 0, border, 2))
    b.add_theme_stylebox_override("pressed", make_box(Color("#333333"), int(sz / 2.0), 0, 0, border, 2))
    b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
    for k in ["font_color", "font_hover_color", "font_pressed_color", "font_focus_color", "font_hover_pressed_color"]:
        b.add_theme_color_override(k, fg)
    b.pressed.connect(tap_slot.bind(slot))

    var pp = pill(SLOT_POS[slot], LIME, Color.BLACK, 8, 6, 1)
    pp.custom_minimum_size = Vector2(40, 14)
    pp.position = Vector2(float(sz) / 2.0 - 20.0, float(sz) - 6.0)
    b.add_child(pp)

    var fb = PanelContainer.new()
    fb.custom_minimum_size = Vector2(22, 22)
    fb.position = Vector2(sz - 14, -6)
    fb.add_theme_stylebox_override("panel", make_box(Color.BLACK, 11, 0, 0, Color(1, 1, 1, 0.15), 1))
    var fl = make_label(p.overall, 10, WHITE, false, HORIZONTAL_ALIGNMENT_CENTER)
    fl.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    fb.add_child(fl)
    b.add_child(fb)
    ignore_children(b)
    return b


func screen_tactics():
    var sub = "Formação %s • 11 titulares • %d reservas" % [formation, bench.size()]
    if selected_slot >= 0:
        sub = "Substituindo %s — toque em um reserva (ou no mesmo titular para cancelar)" % players[starters[selected_slot]].name
    else:
        sub += " • toque em um titular e depois em um reserva para substituir"
    heading("TÁTICA • %s" % formation, sub, mentality.to_upper())

    var row = HBoxContainer.new()
    row.add_theme_constant_override("separation", 14)
    content.add_child(row)

    var pitch_panel = PanelContainer.new()
    pitch_panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    pitch_panel.add_theme_stylebox_override("panel", make_box(PITCH, 24, 0, 0, Color(0, 1, 0.533, 0.20), 1))
    row.add_child(pitch_panel)
    var pitch = PitchView.new()
    pitch.custom_minimum_size = Vector2(620, 400)
    pitch_panel.add_child(pitch)
    var xs = [0.84, 0.58, 0.32, 0.09]
    for ri in PITCH_ROWS.size():
        var slots = PITCH_ROWS[ri]
        for k in slots.size():
            var slot = slots[k]
            var tok = make_token(players[starters[slot]], slot, slot == selected_slot)
            pitch.add_child(tok)
            pitch.items.append({"node": tok, "nx": xs[ri], "ny": float(k + 1) / float(slots.size() + 1)})

    var side = VBoxContainer.new()
    side.custom_minimum_size = Vector2(400, 0)
    side.add_theme_constant_override("separation", 8)
    row.add_child(side)
    side.add_child(make_label("BANCO DE RESERVAS", 11, Color(1, 1, 1, 0.8), true))
    for idx in bench:
        var p = players[idx]
        var b = card_button(58, tap_bench.bind(idx))
        var hb = card_body(b, 10)
        hb.add_child(avatar(p.name, 36))
        var vb = VBoxContainer.new()
        vb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        vb.size_flags_vertical = Control.SIZE_SHRINK_CENTER
        vb.add_theme_constant_override("separation", 3)
        hb.add_child(vb)
        var nl = make_label("%02d  %s%s" % [p.number, p.name, "  (LES)" if p.injured else ""], 12, WHITE)
        nl.clip_text = true
        nl.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
        vb.add_child(nl)
        vb.add_child(pos_pill(p.pos))
        hb.add_child(force_ring(p.overall, 40))
        ignore_children(b)
        side.add_child(b)

    var h = HBoxContainer.new()
    h.add_theme_constant_override("separation", 8)
    content.add_child(h)
    for o in [["FORMAÇÃO", formation, "formation"], ["MENTALIDADE", mentality, "mentality"], ["PRESSÃO", pressing, "pressing"], ["LINHA", defensive_line, "line"]]:
        var pb = pill_button("%s  •  %s" % [o[0], o[1].to_upper()], false, cycle_tactic.bind(o[2]))
        pb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        h.add_child(pb)


func tap_slot(slot):
    if selected_slot == slot:
        selected_slot = -1
    else:
        selected_slot = slot
    show_screen("tactics")


func tap_bench(idx):
    var p = players[idx]
    if p.injured:
        message = "%s está lesionado e não pode entrar." % p.name
        show_screen("tactics")
        return
    var slot = selected_slot
    if slot < 0:
        slot = slot_for(p.pos)
    if slot < 0:
        message = "Toque primeiro no titular que será substituído."
    else:
        swap_into_lineup(slot, idx)
        message = "%s entrou no time." % p.name
        selected_slot = -1
    show_screen("tactics")


# Slot de titular da mesma posição com o menor overall (-1 se não houver).
func slot_for(pos):
    var best = -1
    for s in SLOT_POS.size():
        if SLOT_POS[s] == pos:
            if best == -1 or players[starters[s]].overall < players[starters[best]].overall:
                best = s
    return best


func swap_into_lineup(slot, bench_idx):
    var out_idx = starters[slot]
    starters[slot] = bench_idx
    bench.erase(bench_idx)
    bench.append(out_idx)


func promote_player(i):
    var p = players[i]
    if i in starters:
        message = "%s já é titular." % p.name
    elif p.injured:
        message = "%s está lesionado." % p.name
    else:
        var slot = slot_for(p.pos)
        if slot == -1:
            message = "Não há titular na posição %s. Use a tela TÁTICAS para escolher quem sai." % p.pos
        else:
            swap_into_lineup(slot, i)
            message = "%s agora é titular." % p.name
    show_screen("player")


func bench_player(i):
    var p = players[i]
    if i not in starters:
        message = "%s já está no banco." % p.name
        show_screen("player")
        return
    var replacement = -1
    for x in bench:
        if players[x].pos == p.pos and not players[x].injured:
            replacement = x
            break
    if replacement == -1:
        message = "Não há reserva disponível na posição %s." % p.pos
    else:
        swap_into_lineup(starters.find(i), replacement)
        message = "%s foi para o banco." % p.name
    show_screen("player")


func cycle_tactic(kind):
    match kind:
        "formation":
            formation = next_in(FORMATIONS, formation)
        "mentality":
            mentality = next_in(MENTALITIES, mentality)
        "pressing":
            pressing = next_in(PRESSINGS, pressing)
        "line":
            defensive_line = next_in(LINES, defensive_line)
    show_screen("tactics")


# ---------------------------------------------------------------- MERCADO

func screen_market():
    heading("MERCADO • JANELA ABERTA", "Caixa disponível: %s" % money_str(club.money), "%d DISPONÍVEIS" % market.size())
    if market.size() == 0:
        info("Nenhum jogador disponível no momento.")
        return
    var grid = GridContainer.new()
    grid.columns = 3
    grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    grid.add_theme_constant_override("h_separation", 12)
    grid.add_theme_constant_override("v_separation", 12)
    content.add_child(grid)
    for i in market.size():
        var m = market[i]
        var card = make_panel()
        card.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        grid.add_child(card)
        var vb = VBoxContainer.new()
        vb.add_theme_constant_override("separation", 8)
        card.add_child(vb)
        var top = HBoxContainer.new()
        vb.add_child(top)
        top.add_child(pos_pill(m.pos))
        var sp = Control.new()
        sp.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        top.add_child(sp)
        top.add_child(make_label("GER %d" % m.overall, 12, LIME))
        var av = avatar(m.name, 52)
        av.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
        vb.add_child(av)
        vb.add_child(make_label(m.name, 14, WHITE, false, HORIZONTAL_ALIGNMENT_CENTER))
        vb.add_child(make_label("%d anos  •  POT %d" % [m.age, m.potential], 11, MUTED, false, HORIZONTAL_ALIGNMENT_CENTER))
        vb.add_child(make_label("Salário %s/mês" % money_str(m.salary), 10, DIM, false, HORIZONTAL_ALIGNMENT_CENTER))
        action(money_str(m.value), buy_player.bind(i), true, vb)


func buy_player(i):
    var m = market[i]
    var ok = await ask_dialog("Contratar %s (%s, GER %d)?\n\nValor: %s\nSalário: %s/mês" % [m.name, m.pos, m.overall, money_str(m.value), money_str(m.salary)], "CONTRATAR", "CANCELAR")
    if not ok:
        show_screen("market")
        return
    if club.money < m.value:
        message = "Dinheiro insuficiente."
    elif wage_bill() + m.salary > club.wage_budget:
        message = "Orçamento salarial insuficiente."
    else:
        club.money -= m.value
        var p = {
            "name": m.name, "pos": m.pos, "age": m.age, "overall": m.overall, "potential": m.potential,
            "value": m.value, "salary": m.salary, "years": 3, "bonus": 0.0, "morale": 75, "fatigue": 0
        }
        fill_defaults(p)
        players.append(p)
        bench.append(players.size() - 1)
        market.remove_at(i)
        message = "%s contratado e enviado ao banco." % p.name
    show_screen("market")


# ---------------------------------------------------------------- TREINO

func screen_training():
    heading("CENTRO DE TREINAMENTO", "Treinos evoluem o jogador, mas aumentam a fadiga. Toque em um atleta para escolher o foco.")
    for i in players.size():
        var p = players[i]
        var b = action("%s  •  GER %d/%d  •  Fadiga %d%%%s" % [p.name, p.overall, p.potential, p.fatigue, "  •  LESIONADO" if p.injured else ""], open_focus.bind(i))
        b.alignment = HORIZONTAL_ALIGNMENT_LEFT


func open_focus(i):
    selected_player = i
    show_screen("focus")


func screen_focus():
    var p = players[selected_player]
    heading("TREINO: " + p.name, "Escolha o atributo trabalhado nesta semana")
    info("GER %d / Potencial %d • Fadiga %d%%" % [p.overall, p.potential, p.fatigue])
    for f in FOCUS:
        action("%s  (%d)" % [f[1], p.attrs[f[0]]], train_focus.bind(f[0]))
    action("VOLTAR", show_screen.bind("training"))


func train_focus(key):
    var p = players[selected_player]
    if p.injured:
        message = "%s está lesionado." % p.name
    elif p.fatigue >= 85:
        message = "%s está exausto. Deixe-o descansar." % p.name
    else:
        p.attrs[key] = mini(99, p.attrs[key] + randi_range(1, 2))
        p.fatigue = mini(100, p.fatigue + 12)
        p.morale = mini(100, p.morale + 2)
        p.form = mini(10, p.form + 1)
        if p.overall < p.potential:
            p.overall = mini(p.potential, p.overall + 1)
        message = "%s treinou e chegou a GER %d." % [p.name, p.overall]
    show_screen("training")


# ---------------------------------------------------------------- CONTRATOS

func screen_contracts():
    heading("CONTRATOS", "Folha salarial: %s/mês • Orçamento salarial: %s/mês" % [money_str(wage_bill()), money_str(club.wage_budget)])
    for i in players.size():
        var p = players[i]
        var b = action("%s  —  %d anos  —  %s/mês  —  multa %s" % [p.name, p.years, money_str(p.salary), money_str(p.clause)], negotiate.bind(i))
        b.alignment = HORIZONTAL_ALIGNMENT_LEFT


func negotiate(i):
    var p = players[i]
    var salary = maxf(p.salary, roundf(p.salary * 1.15))
    var years = mini(5, p.years + 1)
    var clause = roundf(p.value * 2.5)
    var ok = await ask_dialog("NEGOCIAÇÃO: %s\n\nPedido do jogador:\nSalário: %s/mês\nDuração: %d anos\nMulta: %s\n\nAceitar proposta?" % [p.name, money_str(salary), years, money_str(clause)])
    if ok:
        if wage_bill() - p.salary + salary <= club.wage_budget and club.money >= salary:
            p.salary = salary
            p.years = years
            p.clause = clause
            p.morale = mini(100, p.morale + 6)
            message = "Contrato renovado com %s." % p.name
        else:
            message = "A diretoria não comporta essa proposta no orçamento."
    else:
        message = "Negociação adiada com %s." % p.name
    show_screen("contracts")


func ask_dialog(text, ok_text := "ACEITAR", cancel_text := "RECUSAR"):
    var dlg = ConfirmationDialog.new()
    dlg.title = "WILFOOT"
    dlg.dialog_text = text
    dlg.ok_button_text = ok_text
    dlg.cancel_button_text = cancel_text
    dlg.get_label().add_theme_font_size_override("font_size", 18)
    dlg.get_label().add_theme_color_override("font_color", WHITE)
    dlg.add_theme_stylebox_override("panel", make_box(PANEL, 20, 20, 16, BORDER, 1))
    dlg.always_on_top = true
    dlg.process_mode = Node.PROCESS_MODE_ALWAYS
    style_button(dlg.get_ok_button(), true, 44)
    style_button(dlg.get_cancel_button(), false, 44)
    dlg.confirmed.connect(func(): dialog_closed.emit(true))
    dlg.canceled.connect(func(): dialog_closed.emit(false))
    add_child(dlg)
    dlg.popup_centered(Vector2i(620, 360))
    var result = await dialog_closed
    dlg.queue_free()
    return result


# ---------------------------------------------------------------- MAIS / CALENDÁRIO / TABELA


# ---------------------------------------------------------------- MUNDO • 120 CLUBES / TORNEIOS / TREINADOR

const TOURNAMENTS = [
    ["UEFA Champions League", "UEFA", "clubes", 36],
    ["UEFA Europa League", "UEFA", "clubes", 36],
    ["UEFA Conference League", "UEFA", "clubes", 36],
    ["CONMEBOL Libertadores", "CONMEBOL", "clubes", 32],
    ["CONMEBOL Sudamericana", "CONMEBOL", "clubes", 32],
    ["CONMEBOL Recopa", "CONMEBOL", "final", 2],
    ["Copa do Brasil", "CBF", "mata-mata", 92],
    ["FA Cup", "Inglaterra", "mata-mata", 80],
    ["Carabao Cup", "Inglaterra", "mata-mata", 92],
    ["Copa del Rey", "Espanha", "mata-mata", 84],
    ["Supercopa de España", "Espanha", "final", 4],
    ["Coppa Italia", "Itália", "mata-mata", 44],
    ["Supercoppa Italiana", "Itália", "final", 4],
    ["DFB-Pokal", "Alemanha", "mata-mata", 64],
    ["DFL-Supercup", "Alemanha", "final", 2],
    ["Coupe de France", "França", "mata-mata", 80],
    ["Trophée des Champions", "França", "final", 2],
    ["Taça de Portugal", "Portugal", "mata-mata", 68],
    ["Supertaça Cândido de Oliveira", "Portugal", "final", 2],
    ["KNVB Beker", "Holanda", "mata-mata", 64],
    ["Johan Cruyff Schaal", "Holanda", "final", 2],
    ["Copa Argentina", "Argentina", "mata-mata", 64],
    ["Supercopa Argentina", "Argentina", "final", 2],
    ["Copa do Rei Saudita", "Arábia Saudita", "mata-mata", 32],
    ["Supercopa Saudita", "Arábia Saudita", "final", 4],
    ["FIFA Intercontinental Cup", "FIFA", "mundial", 6],
    ["FIFA Club World Cup", "FIFA", "mundial", 32],
    ["FIFA World Cup", "FIFA", "seleções", 48],
    ["UEFA Nations League", "UEFA", "seleções", 16],
    ["Copa América", "CONMEBOL", "seleções", 16],
    ["Euro", "UEFA", "seleções", 24],
    ["AFC Asian Cup", "AFC", "seleções", 24],
    ["AFCON", "CAF", "seleções", 24],
    ["CONCACAF Gold Cup", "CONCACAF", "seleções", 16]
]

func screen_world():
    heading("MUNDO DO FUTEBOL", "10 países • 1.200 clubes • 120 equipes por país • calendário global", "1.200 CLUBES")
    var stats = HBoxContainer.new()
    stats.add_theme_constant_override("separation", 10)
    content.add_child(stats)
    for item in [["10", "PAÍSES"], ["1.200", "CLUBES"], ["120", "POR PAÍS"], [str(TOURNAMENTS.size()), "TORNEIOS"]]:
        var card = make_panel(Color("#101114"), 16)
        card.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        stats.add_child(card)
        var vb = VBoxContainer.new()
        card.add_child(vb)
        vb.add_child(make_label(item[0], 24, LIME, true, HORIZONTAL_ALIGNMENT_CENTER))
        vb.add_child(make_label(item[1], 10, MUTED, true, HORIZONTAL_ALIGNMENT_CENTER))

    var engine_text := "ENGINE 7.0 • %s" % ("OK — 10 países / 1.200 clubes" if engine7_status.get("ok", false) else "MODO DE SEGURANÇA")
    content.add_child(make_label(engine_text, 11, LIME if engine7_status.get("ok", false) else YELLOW, true))
    heading("BASE MUNDIAL", "Cada país possui 120 clubes organizados em elite e divisões inferiores")
    if world_database.is_empty():
        content.add_child(make_label("Banco mundial não encontrado.", 14, MUTED))
    else:
        for country in world_database.get("countries", []):
            var card = make_panel(Color("#111214"), 16)
            content.add_child(card)
            var vb = VBoxContainer.new()
            vb.add_theme_constant_override("separation", 7)
            card.add_child(vb)
            var top = HBoxContainer.new()
            vb.add_child(top)
            var title = make_label(str(country.get("country", "País")), 15, WHITE, true)
            title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
            top.add_child(title)
            top.add_child(pill("120 CLUBES", LIME, Color.BLACK, 9, 8, 3))
            for division in country.get("divisions", []):
                var dteams = division.get("teams", [])
                var line = make_label("%s: %d clubes" % [str(division.get("name", "Divisão")), dteams.size()], 11, MUTED, true)
                vb.add_child(line)
            var names = []
            for t in country.get("teams", []):
                names.append(str(t))
            vb.add_child(make_label(" • ".join(names), 10, MUTED))

    heading("TORNEIOS", "Competições nacionais, continentais e mundiais")
    var grid = GridContainer.new()
    grid.columns = 2
    grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    grid.add_theme_constant_override("h_separation", 10)
    grid.add_theme_constant_override("v_separation", 8)
    content.add_child(grid)
    for t in TOURNAMENTS:
        var c = make_panel(Color("#0E1013"), 14)
        c.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        grid.add_child(c)
        var hb = HBoxContainer.new()
        c.add_child(hb)
        hb.add_child(make_label(t[0], 12, WHITE, true))
        var sp = Control.new(); sp.size_flags_horizontal = Control.SIZE_EXPAND_FILL; hb.add_child(sp)
        hb.add_child(pill(str(t[1]), Color("#25282E"), Color("#B9C0CA"), 8, 7, 2))

    action("SIMULAR PRÓXIMA RODADA DO MUNDO", simulate_world_round_manual, true)

func simulate_world_round_manual():
    play_world_round(round_no)
    message = "Rodada mundial simulada: base de 1.200 clubes carregada; 10 ligas principais atualizadas."
    save_game(true)
    show_screen("world")

func screen_coach():
    heading("CRIADOR DE TREINADOR", "Crie sua identidade e defina como sua equipe joga")
    var card = make_panel(Color("#101114"), 20)
    content.add_child(card)
    var vb = VBoxContainer.new()
    vb.add_theme_constant_override("separation", 10)
    card.add_child(vb)

    var name_edit = LineEdit.new()
    name_edit.text = str(coach.get("name", "Novo Treinador"))
    name_edit.placeholder_text = "Nome do treinador"
    name_edit.custom_minimum_size = Vector2(0, 48)
    vb.add_child(make_label("NOME", 10, MUTED, true)); vb.add_child(name_edit)

    var age_spin = SpinBox.new()
    age_spin.min_value = 18; age_spin.max_value = 80; age_spin.value = int(coach.get("age", 35)); age_spin.custom_minimum_size = Vector2(0, 48)
    vb.add_child(make_label("IDADE", 10, MUTED, true)); vb.add_child(age_spin)

    var nation = OptionButton.new()
    for n in ["Brasil","Argentina","Portugal","Espanha","Inglaterra","Itália","Alemanha","França","Holanda","Arábia Saudita"]: nation.add_item(n)
    var ni = ["Brasil","Argentina","Portugal","Espanha","Inglaterra","Itália","Alemanha","França","Holanda","Arábia Saudita"].find(str(coach.get("nationality","Brasil")))
    nation.select(maxi(0, ni)); nation.custom_minimum_size = Vector2(0,48)
    vb.add_child(make_label("NACIONALIDADE",10,MUTED,true)); vb.add_child(nation)

    var style = OptionButton.new()
    for st in ["Equilibrado","Posse de bola","Transição rápida","Pressão alta","Defesa e contra-ataque"]: style.add_item(st)
    var si = ["Equilibrado","Posse de bola","Transição rápida","Pressão alta","Defesa e contra-ataque"].find(str(coach.get("style","Equilibrado")))
    style.select(maxi(0, si)); style.custom_minimum_size = Vector2(0,48)
    vb.add_child(make_label("ESTILO",10,MUTED,true)); vb.add_child(style)

    var formation_box = OptionButton.new()
    for f in FORMATIONS: formation_box.add_item(f)
    formation_box.select(maxi(0, FORMATIONS.find(str(coach.get("formation","4-3-3")))))
    formation_box.custom_minimum_size = Vector2(0,48)
    vb.add_child(make_label("FORMAÇÃO FAVORITA",10,MUTED,true)); vb.add_child(formation_box)

    var skills = GridContainer.new(); skills.columns = 2; skills.add_theme_constant_override("h_separation",10); skills.add_theme_constant_override("v_separation",8); vb.add_child(skills)
    var skill_edits = {}
    for key in ["attack","defense","development","negotiation"]:
        var row = HBoxContainer.new(); row.custom_minimum_size=Vector2(0,42); skills.add_child(row)
        row.add_child(make_label(key.to_upper(),11,WHITE,true)); var sp=SpinBox.new(); sp.min_value=1; sp.max_value=99; sp.value=int(coach.get(key,50)); sp.size_flags_horizontal=Control.SIZE_EXPAND_FILL; row.add_child(sp); skill_edits[key]=sp

    action("CRIAR / SALVAR TREINADOR", func():
        coach.name = name_edit.text.strip_edges() if name_edit.text.strip_edges() != "" else "Novo Treinador"
        coach.age = int(age_spin.value); coach.nationality = nation.get_item_text(nation.selected); coach.style = style.get_item_text(style.selected); coach.formation = formation_box.get_item_text(formation_box.selected)
        for key in skill_edits: coach[key] = int(skill_edits[key].value)
        coach.reputation = int((coach.attack + coach.defense + coach.development + coach.negotiation) / 4.0)
        message = "Treinador %s criado com reputação %d." % [coach.name, coach.reputation]
        save_game(true); show_screen("home")
    , true, vb)

# Motor de partida: minuto a minuto, xG, posse, finalizações, cartões, substituições e efeitos táticos.
func simulate_real_match(home_team: String, away_team: String, home_strength: float, away_strength: float, _user_controlled: bool = false) -> Dictionary:
    var home_xg = 0.0
    var away_xg = 0.0
    var home_shots = 0
    var away_shots = 0
    var home_sot = 0
    var away_sot = 0
    var home_cards = 0
    var away_cards = 0
    var home_goals = 0
    var away_goals = 0
    var possession_home = clampf(50.0 + (home_strength - away_strength) * 0.45, 32.0, 68.0)
    var events = []
    var _h_fatigue: float = 0.0
    var _a_fatigue: float = 0.0
    for minute in range(1, 91):
        _h_fatigue += 0.08
        _a_fatigue += 0.08
        var phase = 1.0
        if minute >= 75: phase = 1.18
        var h_edge = (home_strength - away_strength) / 100.0 + 0.06
        var a_edge = (away_strength - home_strength) / 100.0
        var p_h = clampf(0.030 + h_edge * 0.018 + phase * 0.004, 0.008, 0.085)
        var p_a = clampf(0.027 + a_edge * 0.018 + phase * 0.004, 0.008, 0.080)
        if randf() < p_h:
            var x = clampf(randf_range(0.03, 0.22) + maxf(0.0, h_edge) * 0.08, 0.02, 0.35)
            home_shots += 1; home_xg += x
            if randf() < 0.34 + x:
                home_sot += 1
            if randf() < clampf(x * 0.22 + 0.035 + maxf(0.0, h_edge) * 0.05, 0.015, 0.28):
                home_goals += 1
                events.append({"minute":minute,"type":"goal","team":home_team,"text":"Gol do %s!" % home_team})
        if randf() < p_a:
            var x2 = clampf(randf_range(0.03, 0.22) + maxf(0.0, a_edge) * 0.08, 0.02, 0.35)
            away_shots += 1; away_xg += x2
            if randf() < 0.34 + x2: away_sot += 1
            if randf() < clampf(x2 * 0.22 + 0.035 + maxf(0.0, a_edge) * 0.05, 0.015, 0.28):
                away_goals += 1
                events.append({"minute":minute,"type":"goal","team":away_team,"text":"Gol do %s!" % away_team})
        if randf() < 0.012:
            if randf() < 0.5: home_cards += 1; events.append({"minute":minute,"type":"card","team":home_team,"text":"Cartão amarelo para %s." % home_team})
            else: away_cards += 1; events.append({"minute":minute,"type":"card","team":away_team,"text":"Cartão amarelo para %s." % away_team})
        if minute in [60, 70, 80] and randf() < 0.35:
            events.append({"minute":minute,"type":"sub","team":home_team,"text":"Substituição do %s." % home_team})
            if randf() < 0.7: events.append({"minute":minute,"type":"sub","team":away_team,"text":"Substituição do %s." % away_team})
    var result = {"home":home_team,"away":away_team,"hg":home_goals,"ag":away_goals,"home_xg":roundf(home_xg*100.0)/100.0,"away_xg":roundf(away_xg*100.0)/100.0,"home_shots":home_shots,"away_shots":away_shots,"home_sot":home_sot,"away_sot":away_sot,"home_cards":home_cards,"away_cards":away_cards,"possession_home":roundf(possession_home),"events":events}
    return result

func screen_language():
    heading("IDIOMA DO JOGO", "Escolha o idioma da interface. A seleção fica salva para a próxima abertura.", loc_text("IDIOMA ATUAL"))
    var current_id: String = str(WilfootLocalization.current_language) if is_instance_valid(WilfootLocalization) else "pt_BR"
    var current_name: String = WilfootLocalization.get_language_name(current_id) if is_instance_valid(WilfootLocalization) else "Português (Brasil)"
    var current_card = make_panel(Color("#0F1B29"), 18)
    content.add_child(current_card)
    var cv = VBoxContainer.new()
    cv.add_theme_constant_override("separation", 5)
    current_card.add_child(cv)
    cv.add_child(make_label(loc_text("IDIOMA ATUAL"), 10, MUTED, true))
    cv.add_child(make_label(current_name, 20, WHITE, true))

    var grid = GridContainer.new()
    grid.columns = 2
    grid.add_theme_constant_override("h_separation", 10)
    grid.add_theme_constant_override("v_separation", 10)
    grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    content.add_child(grid)
    if is_instance_valid(WilfootLocalization):
        for language_id: String in WilfootLocalization.get_languages():
            var b = Button.new()
            b.text = WilfootLocalization.get_language_name(language_id)
            b.custom_minimum_size = Vector2(0, 58)
            b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
            style_button(b, language_id == current_id, 58)
            b.pressed.connect(_select_language.bind(language_id))
            grid.add_child(b)
    action("AUTOMÁTICO", _select_system_language, false)
    action("VOLTAR", show_screen.bind("more"), false)

func _select_language(language_id: String) -> void:
    if is_instance_valid(WilfootLocalization):
        WilfootLocalization.set_language(language_id)

func _select_system_language() -> void:
    if is_instance_valid(WilfootLocalization):
        WilfootLocalization.set_system_language()

func screen_more():
    heading("MAIS", "Treino, contratos, campeonatos e carreira")
    var grid = GridContainer.new()
    grid.columns = 2
    grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    grid.add_theme_constant_override("h_separation", 12)
    grid.add_theme_constant_override("v_separation", 10)
    content.add_child(grid)
    for it in [["TREINAMENTO", show_screen.bind("training")], ["CONTRATOS", show_screen.bind("contracts")], ["CLASSIFICAÇÃO", show_screen.bind("table")], ["RESULTADOS DA RODADA", show_screen.bind("results")], ["🌍 MUNDO • 1.200 CLUBES", show_screen.bind("world")], ["👔 CRIADOR DE TREINADOR", show_screen.bind("coach")], ["🏆 GALERIA DE TROFÉUS", show_screen.bind("trofeus")], ["IMPORTAR RODADA (JSON)", importar_rodada], ["SIMULAR RODADA IMPORTADA", simular_nova_rodada], ["TÍTULOS REAIS", show_screen.bind("titulos")], ["PATROCINADORES", show_screen.bind("patrocinadores")], ["PREMIAÇÕES REAIS", show_screen.bind("premiacoes")], ["SALVAR CARREIRA", save_game], ["CARREGAR CARREIRA", load_button], ["IDIOMA", show_screen.bind("language")], ["MENU PRINCIPAL", back_to_menu]]:
        var b = action(it[0], it[1], false, grid)
        b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        b.custom_minimum_size = Vector2(0, 60)


func load_button():
    if load_game():
        message = "Carreira carregada."
    else:
        message = "Nenhum save compatível encontrado."
    show_screen("home")


func screen_games():
    var total = season_rounds()
    heading("JOGOS", "Rodada %d de %d" % [mini(round_no, total), total], "RODADA %d" % mini(round_no, total))
    var cols = HBoxContainer.new()
    cols.add_theme_constant_override("separation", 14)
    content.add_child(cols)
    var left = VBoxContainer.new()
    left.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    left.add_theme_constant_override("separation", 12)
    cols.add_child(left)
    var right = VBoxContainer.new()
    right.custom_minimum_size = Vector2(420, 0)
    right.add_theme_constant_override("separation", 12)
    cols.add_child(right)

    var fx = user_fixture(round_no)
    var card = PanelContainer.new()
    card.add_theme_stylebox_override("panel", make_box(Color("#0F0F10"), 24, 18, 16, Color(LIME, 0.25), 1))
    left.add_child(card)
    var cv = VBoxContainer.new()
    cv.add_theme_constant_override("separation", 16)
    card.add_child(cv)
    var top = HBoxContainer.new()
    cv.add_child(top)
    var tl = make_label("PRÓXIMO CONFRONTO", 10, MUTED, true)
    tl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    top.add_child(tl)
    top.add_child(pill("RODADA %d" % mini(round_no, total), LIME, Color.BLACK, 10, 10, 4))

    if fx.is_empty():
        cv.add_child(make_label("A temporada terminou.", 18, WHITE, false, HORIZONTAL_ALIGNMENT_CENTER))
        action("INICIAR NOVA TEMPORADA", new_season, true, cv)
    else:
        var home_team = club.name if fx.home else fx.opp
        var away_team = fx.opp if fx.home else club.name
        var mr = HBoxContainer.new()
        mr.add_theme_constant_override("separation", 12)
        cv.add_child(mr)
        var h1 = HBoxContainer.new()
        h1.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        h1.add_theme_constant_override("separation", 12)
        mr.add_child(h1)
        h1.add_child(crest(home_team, 44))
        h1.add_child(make_label(abbr(home_team), 15, WHITE, true))
        mr.add_child(make_label("VS", 12, DIM))
        var h2 = HBoxContainer.new()
        h2.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        h2.alignment = BoxContainer.ALIGNMENT_END
        h2.add_theme_constant_override("separation", 12)
        mr.add_child(h2)
        h2.add_child(make_label(abbr(away_team), 15, WHITE, true))
        h2.add_child(crest(away_team, 44))

        var pb = Button.new()
        pb.text = "JOGAR PARTIDA"
        style_button(pb, true, 56)
        pb.add_theme_font_size_override("font_size", 15)
        pb.pressed.connect(simulate_match)
        var icon = PlayIcon.new()
        icon.position = Vector2(20, 12)
        icon.mouse_filter = Control.MOUSE_FILTER_IGNORE
        pb.add_child(icon)
        cv.add_child(pb)
        cv.add_child(make_label("SIMULAÇÃO AO VIVO • 90'", 10, DIM, true, HORIZONTAL_ALIGNMENT_CENTER))

    var nc = make_panel()
    left.add_child(nc)
    var nv = VBoxContainer.new()
    nv.add_theme_constant_override("separation", 8)
    nc.add_child(nv)
    nv.add_child(make_label("PRÓXIMAS RODADAS", 11, Color(1, 1, 1, 0.6), true))
    var any = false
    for k in 3:
        var f2 = user_fixture(round_no + k)
        if f2.is_empty():
            break
        any = true
        nv.add_child(make_label("Rodada %d   •   %s" % [round_no + k, fixture_title(f2)], 13, Color(1, 1, 1, 0.85)))
    if not any:
        nv.add_child(make_label("Sem jogos restantes nesta temporada.", 13, MUTED))

    var hc = make_panel()
    right.add_child(hc)
    var hv = VBoxContainer.new()
    hv.add_theme_constant_override("separation", 8)
    hc.add_child(hv)
    hv.add_child(make_label("ÚLTIMOS JOGOS", 11, Color(1, 1, 1, 0.6), true))
    if match_history.size() == 0:
        hv.add_child(make_label("Nenhuma partida disputada ainda.", 13, MUTED))
    for e in match_history:
        var rowp = PanelContainer.new()
        rowp.add_theme_stylebox_override("panel", make_box(Color(0, 0, 0, 0.4), 14, 12, 9, Color(1, 1, 1, 0.06), 1))
        hv.add_child(rowp)
        var rh = HBoxContainer.new()
        rowp.add_child(rh)
        var rl = make_label(e.text, 12, Color(1, 1, 1, 0.75))
        rl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        rh.add_child(rl)
        var pbg = Color(1, 1, 1, 0.10)
        var pfg = Color(1, 1, 1, 0.5)
        if e.res == "V":
            pbg = Color(0, 1, 0.533, 0.20)
            pfg = NEON
        elif e.res == "D":
            pbg = Color(1, 0.3, 0.3, 0.20)
            pfg = LOSS
        rh.add_child(pill(e.res, pbg, pfg, 9, 8, 3))
    action("CLASSIFICAÇÃO COMPLETA", show_screen.bind("table"), false, hv)


func select_league(id):
    table_league = id
    show_screen(current_screen)


func table_tabs():
    var hb = HBoxContainer.new()
    hb.add_theme_constant_override("separation", 8)
    content.add_child(hb)
    var b1 = pill_button("CLASSIFICAÇÃO", current_screen == "table", show_screen.bind("table"))
    b1.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    hb.add_child(b1)
    var b2 = pill_button("RESULTADOS", current_screen == "results", show_screen.bind("results"))
    b2.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    hb.add_child(b2)


func league_selector():
    var hs = ScrollContainer.new()
    hs.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    hs.custom_minimum_size = Vector2(0, 50)
    content.add_child(hs)
    var hb = HBoxContainer.new()
    hb.add_theme_constant_override("separation", 6)
    hs.add_child(hb)
    for lg in LEAGUES:
        hb.add_child(pill_button(lg.short, lg.id == table_league, select_league.bind(lg.id), 130))


func cell(text, width, color, align := HORIZONTAL_ALIGNMENT_CENTER, size_px := 15):
    var l = Label.new()
    l.text = str(text)
    l.custom_minimum_size = Vector2(width, 0)
    l.horizontal_alignment = align
    l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    l.add_theme_color_override("font_color", color)
    l.add_theme_font_override("font", bold_font)
    l.add_theme_font_size_override("font_size", size_px)
    return l


func crest(team, sz := 24):
    var pc = PanelContainer.new()
    var sb = StyleBoxFlat.new()
    sb.bg_color = Color.from_hsv(float(absi(team.hash()) % 360) / 360.0, 0.55, 0.85)
    sb.set_corner_radius_all(int(float(sz) / 2.0))
    sb.set_border_width_all(2)
    sb.border_color = WHITE
    pc.add_theme_stylebox_override("panel", sb)
    pc.custom_minimum_size = Vector2(sz, sz)
    pc.size_flags_vertical = Control.SIZE_SHRINK_CENTER
    pc.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
    if sz >= 40:
        var l = make_label(abbr(team), int(sz * 0.28), Color.BLACK, false, HORIZONTAL_ALIGNMENT_CENTER)
        l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
        pc.add_child(l)
    return pc


func zone_color(league_id, pos, n):
    if league_id == "br_a":
        if pos <= 4:
            return Z_LIB
        if pos <= 6:
            return Z_PRE
        if pos <= 12:
            return Z_SUL
        if pos > n - 4:
            return Z_REB
        return Z_NEUTRAL
    var top = 1
    var bottom = 1
    if n >= 16:
        top = 4
        bottom = 4
    elif n >= 8:
        top = 2
        bottom = 2
    if pos <= top:
        return Z_LIB
    if pos > n - bottom:
        return Z_REB
    return Z_NEUTRAL


func table_header():
    var pc = PanelContainer.new()
    pc.add_theme_stylebox_override("panel", make_box(Color(0, 0, 0, 0), 6, 10, 2))
    content.add_child(pc)
    var hb = HBoxContainer.new()
    hb.add_theme_constant_override("separation", 8)
    pc.add_child(hb)
    hb.add_child(cell("#", 44, MUTED))
    hb.add_child(cell("", 24, MUTED))
    var nm = cell("CLUBE", 0, MUTED, HORIZONTAL_ALIGNMENT_LEFT)
    nm.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    hb.add_child(nm)
    for h in [["PTS", 64], ["J", 52], ["V", 52], ["E", 52], ["D", 52], ["SG", 64]]:
        hb.add_child(cell(h[0], h[1], MUTED))


func table_row(pos, r, n, league_id):
    var mine = (r.name == club.name)
    var bg = PANEL if pos % 2 == 1 else PANEL2
    var border = Color.TRANSPARENT
    var bw = 0
    if mine:
        bg = Color(LIME, 0.08)
        border = Color(LIME, 0.40)
        bw = 1
    var pc = PanelContainer.new()
    pc.add_theme_stylebox_override("panel", make_box(bg, 14, 10, 5, border, bw))
    content.add_child(pc)
    var hb = HBoxContainer.new()
    hb.add_theme_constant_override("separation", 8)
    pc.add_child(hb)

    var badge = PanelContainer.new()
    badge.add_theme_stylebox_override("panel", make_box(zone_color(league_id, pos, n), 8, 4, 2))
    badge.custom_minimum_size = Vector2(44, 0)
    badge.add_child(cell(pos, 0, WHITE, HORIZONTAL_ALIGNMENT_CENTER, 16))
    hb.add_child(badge)
    hb.add_child(crest(r.name, 24))

    var nm = cell(r.name, 0, LIME if mine else WHITE, HORIZONTAL_ALIGNMENT_LEFT, 17)
    nm.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    hb.add_child(nm)
    var sg = r.gp - r.gc
    var soft = Color("#B5B5BA")
    hb.add_child(cell(r.p, 64, WHITE, HORIZONTAL_ALIGNMENT_CENTER, 18))
    hb.add_child(cell(r.j, 52, soft))
    hb.add_child(cell(r.v, 52, soft))
    hb.add_child(cell(r.e, 52, soft))
    hb.add_child(cell(r.d, 52, soft))
    hb.add_child(cell(("+" if sg > 0 else "") + str(sg), 64, soft))


func legend_row(league_id):
    var items = [[Z_LIB, "Vaga continental"], [Z_REB, "Rebaixamento"]]
    if league_id == "br_a":
        items = [[Z_LIB, "Libertadores"], [Z_PRE, "Pré-Libertadores"], [Z_SUL, "Sul-Americana"], [Z_REB, "Rebaixamento"]]
    elif league_id == "br_b":
        items = [[Z_LIB, "Acesso à Série A"], [Z_REB, "Rebaixamento"]]
    var hb = HBoxContainer.new()
    hb.add_theme_constant_override("separation", 18)
    content.add_child(hb)
    for it in items:
        var box = ColorRect.new()
        box.color = it[0]
        box.custom_minimum_size = Vector2(14, 14)
        box.size_flags_vertical = Control.SIZE_SHRINK_CENTER
        hb.add_child(box)
        hb.add_child(cell(it[1], 0, MUTED, HORIZONTAL_ALIGNMENT_LEFT, 14))


func rounds_done(league_id):
    return maxi(0, mini(round_no - 1, schedules[league_id].size()))


func screen_table():
    var lg = league_of(table_league)
    var done = rounds_done(lg.id)
    var sub = "Rodada %d" % done if done > 0 else "Antes da 1ª rodada"
    heading("CLASSIFICAÇÃO", "%s • Temporada %d • %s" % [lg.name, season, sub])
    table_tabs()
    league_selector()
    var rows = sorted_table(lg.id)
    table_header()
    for i in rows.size():
        table_row(i + 1, rows[i], rows.size(), lg.id)
    legend_row(lg.id)


func screen_results():
    var lg = league_of(table_league)
    var res = last_results.get(lg.id, {"round": 0, "games": []})
    var sub = "Rodada %d" % res.round if res.round > 0 else "nenhuma rodada disputada"
    heading("RESULTADOS", "%s • %s" % [lg.name, sub])
    table_tabs()
    league_selector()
    if res.games.size() == 0:
        info("Nenhum jogo disputado ainda. Jogue uma partida para ver os resultados de todos os campeonatos.")
    else:
        var pc = make_panel()
        content.add_child(pc)
        var vb = VBoxContainer.new()
        vb.add_theme_constant_override("separation", 10)
        pc.add_child(vb)
        for g in res.games:
            var l = Label.new()
            l.text = g
            l.add_theme_font_size_override("font_size", 17)
            var mine = lg.id == USER_LEAGUE and club.name in g
            l.add_theme_color_override("font_color", LIME if mine else Color("#D2D6DB"))
            vb.add_child(l)
    painel_rodada_json()


# ---------------------------------------------------------------- PARTIDA

func effective_overall(p):
    var v = float(p.overall) - float(p.fatigue) * 0.1
    if p.injured:
        v *= 0.5
    return v


func team_rating():
    var total = 0.0
    for i in starters:
        total += effective_overall(players[i])
    return total / 11.0


# Peso de cada posição na força de ATAQUE e de DEFESA do time. Um goleiro quase
# não pesa no ataque, um centroavante quase não pesa na defesa, etc. Índice
# alinhado com SLOT_POS ("GOL","LE","ZAG","ZAG","LD","MC","MEI","MC","PE","ATA","PD").
const SLOT_ATTACK_WEIGHT = {"GOL": 0.05, "LE": 0.5, "ZAG": 0.15, "LD": 0.5, "MC": 0.6, "MEI": 0.85, "PE": 0.95, "ATA": 1.1, "PD": 0.95}
const SLOT_DEFENSE_WEIGHT = {"GOL": 1.3, "LE": 0.7, "ZAG": 1.1, "LD": 0.7, "MC": 0.5, "MEI": 0.25, "PE": 0.15, "ATA": 0.05, "PD": 0.15}

# Penalidade de cansaço/lesão aplicada em cima de um atributo (mesma lógica de effective_overall).
func effective_attr(p, valor: float) -> float:
    var v = valor - float(p.fatigue) * 0.1
    if p.injured:
        v *= 0.5
    return v

# Força de ataque real do time em campo: pesa finalização, drible e velocidade
# dos atributos individuais (attrs), ponderado pela posição de cada titular —
# um atacante rápido e finalizador pesa muito mais que um zagueiro na mesma conta.
func attack_rating() -> float:
    var total = 0.0
    var peso_total = 0.0
    for slot in starters.size():
        var p = players[starters[slot]]
        var pos = SLOT_POS[slot]
        var peso = SLOT_ATTACK_WEIGHT.get(pos, 0.5)
        var skill = float(p.attrs["fin"]) * 0.45 + float(p.attrs["dri"]) * 0.35 + float(p.attrs["spd"]) * 0.20
        total += peso * effective_attr(p, skill)
        peso_total += peso
    return total / peso_total if peso_total > 0.0 else team_rating()

# Força de defesa real do time em campo: pesa marcação e físico, ponderado pela
# posição — um zagueiro forte e um goleiro seguro pesam muito mais que um ponta.
func defense_rating() -> float:
    var total = 0.0
    var peso_total = 0.0
    for slot in starters.size():
        var p = players[starters[slot]]
        var pos = SLOT_POS[slot]
        var peso = SLOT_DEFENSE_WEIGHT.get(pos, 0.5)
        var skill = float(p.attrs["def"]) * 0.65 + float(p.attrs["phy"]) * 0.35
        total += peso * effective_attr(p, skill)
        peso_total += peso
    return total / peso_total if peso_total > 0.0 else team_rating()


func simulate_match():
    var fx = user_fixture(round_no)
    if fx.is_empty():
        message = "A temporada terminou. Inicie uma nova temporada."
        show_screen("home")
        return
    var opp = fx.opp
    var at_home = fx.home
    var opp_base = float(team_ratings.get(opp, 70))
    var my_attack = attack_rating() + float(MENTALITY_BONUS.get(mentality, 0))
    var my_def = defense_rating()
    var my_strength = (my_attack * 0.58 + my_def * 0.42)
    if pressing == "Alto": my_strength += 1.5
    if mentality == "Defensiva": my_strength += 0.5
    elif mentality == "Muito ofensiva": my_strength += 1.0
    my_strength += float(coach.get("attack",50) - 50) * 0.08 + float(coach.get("defense",50) - 50) * 0.05
    var home_name = club.name if at_home else opp
    var away_name = opp if at_home else club.name
    var home_strength = my_strength if at_home else opp_base
    var away_strength = opp_base if at_home else my_strength
    home_strength += 3.5
    var result = simulate_real_match(home_name, away_name, home_strength, away_strength, true)
    var gf = int(result.hg if at_home else result.ag)
    var ga = int(result.ag if at_home else result.hg)
    last_result = "%s %d x %d %s" % [home_name, result.hg, result.ag, away_name]
    record_game(USER_LEAGUE, home_name, result.hg, away_name, result.ag)
    var outcome = "V" if gf > ga else ("E" if gf == ga else "D")
    match_history.push_front({"text":"%s %d-%d %s" % [abbr(club.name), gf, ga, abbr(opp)], "res":outcome, "xg":"%.2f-%.2f" % [result.home_xg if at_home else result.away_xg, result.away_xg if at_home else result.home_xg], "shots":"%d-%d" % [result.home_shots if at_home else result.away_shots, result.away_shots if at_home else result.home_shots]})
    while match_history.size() > 10: match_history.pop_back()
    world_match_log.push_front(result)
    while world_match_log.size() > 30: world_match_log.pop_back()
    if gf > ga: message = "Vitória! xG %.2f • Finalizações %d" % [float(result.home_xg if at_home else result.away_xg), int(result.home_shots if at_home else result.away_shots)]; club.money += 450000.0
    elif gf == ga: message = "Empate. xG %.2f • Finalizações %d" % [float(result.home_xg if at_home else result.away_xg), int(result.home_shots if at_home else result.away_shots)]; club.money += 180000.0
    else: message = "Derrota. xG %.2f • Finalizações %d" % [float(result.home_xg if at_home else result.away_xg), int(result.home_shots if at_home else result.away_shots)]; club.money += 100000.0
    play_world_round(round_no)
    last_results[USER_LEAGUE].games.push_front(last_result)
    if last_export.has(USER_LEAGUE): last_export[USER_LEAGUE].push_front({"casa":home_name,"fora":away_name,"placar":"%d x %d" % [result.hg,result.ag]})
    exportar_rodada(round_no, home_name, result.hg, away_name, result.ag)
    round_no += 1
    var hurt=[]
    for idx in players.size():
        var p=players[idx]
        if idx in starters: p.fatigue=mini(100,p.fatigue+10)
        p.fatigue=maxi(0,p.fatigue-7)
        if p.injured:
            p.injury_days-=7
            if p.injury_days<=0: p.injured=false; p.injury_days=0
        elif randf()<0.03 and p.fatigue>50:
            p.injured=true; p.injury_days=randi_range(7,28); hurt.append(p.name)
    if hurt.size()>0: message += "\nLesão: "+", ".join(hurt)
    if round_no > season_rounds(): message += "\nTemporada encerrada! Você terminou em %dº lugar." % position_of(club.name,USER_LEAGUE)
    save_game(true)
    show_screen("home")
    open_live(home_name,result.hg,away_name,result.ag,hurt)


# ---------------------------------------------------------------- SAVE / LOAD

func save_game(silent := false):
    var data = {
        "version": SAVE_VERSION, "club": club, "round": round_no, "season": season,
        "formation": formation, "mentality": mentality, "pressing": pressing, "defensive_line": defensive_line,
        "players": players, "starters": starters, "bench": bench,
        "coach": coach, "world_match_log": world_match_log,
        "market": market, "tables": tables, "last_results": last_results, "last_result": last_result, "match_history": match_history
    }
    var f = FileAccess.open(SAVE_PATH, FileAccess.WRITE)
    if f:
        f.store_string(JSON.stringify(data))
        f.close()
        if not silent:
            message = "Carreira salva com sucesso."
    elif not silent:
        message = "Não foi possível salvar a carreira."
    if not silent:
        show_screen(current_screen)


func to_ints(v):
    var out = []
    if typeof(v) == TYPE_ARRAY:
        for x in v:
            out.append(int(x))
    return out


func lineup_valid():
    if starters.size() != 11:
        return false
    var seen = {}
    for i in starters + bench:
        if i < 0 or i >= players.size() or seen.has(i):
            return false
        seen[i] = true
    return seen.size() == players.size()


func tables_valid(t):
    if typeof(t) != TYPE_DICTIONARY:
        return false
    for lg in LEAGUES:
        var rows = t.get(lg.id)
        if typeof(rows) != TYPE_ARRAY or rows.size() != lg.teams.size():
            return false
        for r in rows:
            if typeof(r) != TYPE_DICTIONARY or not r.has("gp") or not r.has("name"):
                return false
    return true


func load_game() -> bool:
    if not FileAccess.file_exists(SAVE_PATH):
        return false
    var f = FileAccess.open(SAVE_PATH, FileAccess.READ)
    if not f:
        return false
    var d = JSON.parse_string(f.get_as_text())
    f.close()
    if typeof(d) != TYPE_DICTIONARY or typeof(d.get("players")) != TYPE_ARRAY:
        return false
    coach = d.get("coach", coach) if typeof(d.get("coach", coach)) == TYPE_DICTIONARY else coach
    world_match_log = d.get("world_match_log", []) if typeof(d.get("world_match_log", [])) == TYPE_ARRAY else []
    if d.players.size() < 11 or not tables_valid(d.get("tables")):
        return false
    for q in d.players:
        if typeof(q) != TYPE_DICTIONARY:
            return false

    # Elenco e escalação: só aplica se ficar consistente.
    var backup_players = players
    var backup_starters = starters
    var backup_bench = bench
    players = d.players
    for p in players:
        fill_defaults(p)
    starters = to_ints(d.get("starters"))
    bench = to_ints(d.get("bench"))
    if not lineup_valid():
        players = backup_players
        starters = backup_starters
        bench = backup_bench
        return false

    if typeof(d.get("club")) == TYPE_DICTIONARY:
        for k in d.club:
            club[k] = d.club[k]
    club.money = float(club.money)
    club.wage_budget = float(club.wage_budget)

    season = int(d.get("season", season))
    round_no = int(d.get("round", round_no))
    formation = str(d.get("formation", formation))
    mentality = str(d.get("mentality", mentality))
    pressing = str(d.get("pressing", pressing))
    defensive_line = str(d.get("defensive_line", defensive_line))
    last_result = str(d.get("last_result", last_result))

    var m = d.get("market")
    if typeof(m) == TYPE_ARRAY:
        var clean = []
        for x in m:
            if typeof(x) == TYPE_DICTIONARY and x.has("name") and x.has("pos"):
                for k in ["age", "overall", "potential"]:
                    x[k] = int(x.get(k, 0))
                for k in ["value", "salary"]:
                    x[k] = float(x.get(k, 0))
                clean.append(x)
        market = clean

    tables = d.tables
    for lg in LEAGUES:
        for s in tables[lg.id]:
            for k in ["p", "j", "v", "e", "d", "gp", "gc"]:
                s[k] = int(s.get(k, 0))

    match_history = []
    var mh = d.get("match_history")
    if typeof(mh) == TYPE_ARRAY:
        for e in mh:
            if typeof(e) == TYPE_DICTIONARY and e.has("text") and e.has("res"):
                match_history.append({"text": str(e.text), "res": str(e.res)})

    # Últimos resultados: opcional; se vier torto, começa vazio.
    last_results = {}
    var lr = d.get("last_results")
    for lg in LEAGUES:
        var entry = {"round": 0, "games": []}
        if typeof(lr) == TYPE_DICTIONARY and typeof(lr.get(lg.id)) == TYPE_DICTIONARY:
            var e = lr[lg.id]
            if typeof(e.get("games")) == TYPE_ARRAY:
                var games = []
                for g in e.games:
                    games.append(str(g))
                entry = {"round": int(e.get("round", 0)), "games": games}
        last_results[lg.id] = entry
    return true


func open_team_editor():
    _rebuild_world_team_catalog()
    var editor_state: Dictionary = {"selected_ref": {}}
    for ref in world_team_editor_catalog:
        if str(ref.get("name", "")) == str(club.get("name", "Internacional")):
            editor_state["selected_ref"] = ref.duplicate(true)
            break
    if (editor_state["selected_ref"] as Dictionary).is_empty() and not world_team_editor_catalog.is_empty():
        editor_state["selected_ref"] = world_team_editor_catalog[0].duplicate(true)
    if not (editor_state["selected_ref"] as Dictionary).is_empty():
        club = _world_ref_data(editor_state["selected_ref"] as Dictionary)

    # EDITOR PRO — responsivo para Android vertical/paisagem e PC.
    menu_root.visible = false

    var overlay := Control.new()
    overlay.name = "TeamEditorOverlay"
    overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    overlay.mouse_filter = Control.MOUSE_FILTER_STOP
    overlay.z_index = 1200
    overlay.process_mode = Node.PROCESS_MODE_ALWAYS
    add_child(overlay)

    var dim := ColorRect.new()
    dim.color = Color(0.015, 0.018, 0.025, 0.965)
    dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    dim.mouse_filter = Control.MOUSE_FILTER_IGNORE
    overlay.add_child(dim)

    var panel := PanelContainer.new()
    panel.name = "EditorPanel"
    panel.add_theme_stylebox_override("panel", make_box(Color("#101217"), 22, 0, 0, Color("#30343D"), 1))
    overlay.add_child(panel)

    var root := VBoxContainer.new()
    root.add_theme_constant_override("separation", 0)
    panel.add_child(root)

    # Cabeçalho estilo manager moderno.
    var header := PanelContainer.new()
    header.custom_minimum_size = Vector2(0, 88)
    header.add_theme_stylebox_override("panel", make_box(Color("#171A21"), 22, 18, 12, Color("#C8FF00"), 1))
    root.add_child(header)

    var head := HBoxContainer.new()
    head.add_theme_constant_override("separation", 14)
    header.add_child(head)

    var crest_panel := PanelContainer.new()
    crest_panel.custom_minimum_size = Vector2(58, 58)
    crest_panel.add_theme_stylebox_override("panel", make_box(Color("#E51B23"), 18, 0, 0))
    var crest_label := make_label("W", 28, WHITE, true, HORIZONTAL_ALIGNMENT_CENTER)
    crest_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    crest_panel.add_child(crest_label)
    head.add_child(crest_panel)

    var head_text := VBoxContainer.new()
    head_text.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    head_text.add_theme_constant_override("separation", 1)
    head.add_child(head_text)
    var club_title := make_label(str(club.get("name", "Internacional")), 22, WHITE, true)
    head_text.add_child(club_title)
    var club_sub := make_label("EDITOR DE EQUIPE  •  PERSONALIZAÇÃO COMPLETA", 10, LIME, true)
    head_text.add_child(club_sub)

    var rep_badge := PanelContainer.new()
    rep_badge.custom_minimum_size = Vector2(118, 58)
    rep_badge.add_theme_stylebox_override("panel", make_box(Color("#20242C"), 14, 10, 7, Color("#3B414D"), 1))
    var rep_box := VBoxContainer.new()
    rep_box.alignment = BoxContainer.ALIGNMENT_CENTER
    rep_badge.add_child(rep_box)
    rep_box.add_child(make_label("REPUTAÇÃO", 9, MUTED, true, HORIZONTAL_ALIGNMENT_CENTER))
    var rep_value := make_label(str(int(club.get("reputation", 78))), 22, LIME, true, HORIZONTAL_ALIGNMENT_CENTER)
    rep_box.add_child(rep_value)
    head.add_child(rep_badge)

    var scroll := ScrollContainer.new()
    scroll.name = "EditorScroll"
    scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
    scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
    root.add_child(scroll)

    var editor_content := VBoxContainer.new()
    editor_content.name = "EditorContent"
    editor_content.add_theme_constant_override("separation", 12)
    editor_content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    scroll.add_child(editor_content)

    var margin := MarginContainer.new()
    margin.add_theme_constant_override("margin_left", 14)
    margin.add_theme_constant_override("margin_right", 14)
    margin.add_theme_constant_override("margin_top", 12)
    margin.add_theme_constant_override("margin_bottom", 12)
    editor_content.add_child(margin)

    var body := VBoxContainer.new()
    body.add_theme_constant_override("separation", 12)
    margin.add_child(body)

    # Seletor global: permite editar qualquer um dos 1.200 clubes.
    var team_picker := PanelContainer.new()
    team_picker.name = "WorldTeamPicker"
    team_picker.add_theme_stylebox_override("panel", make_box(Color("#11151B"), 16, 12, 9, Color("#C8FF00"), 1))
    body.add_child(team_picker)
    var picker_box := VBoxContainer.new()
    picker_box.add_theme_constant_override("separation", 7)
    team_picker.add_child(picker_box)
    picker_box.add_child(make_label("EDITAR QUALQUER EQUIPE • 1.200 CLUBES", 12, LIME, true))
    var picker_row := BoxContainer.new()
    picker_row.add_theme_constant_override("separation", 8)
    picker_box.add_child(picker_row)
    var country_picker_box := VBoxContainer.new()
    country_picker_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    picker_row.add_child(country_picker_box)
    country_picker_box.add_child(make_label("PAÍS", 9, MUTED, true))
    var country_picker := OptionButton.new()
    country_picker.custom_minimum_size = Vector2(0, 50)
    country_picker_box.add_child(country_picker)
    var team_picker_box := VBoxContainer.new()
    team_picker_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    picker_row.add_child(team_picker_box)
    team_picker_box.add_child(make_label("EQUIPE", 9, MUTED, true))
    var team_picker_option := OptionButton.new()
    team_picker_option.custom_minimum_size = Vector2(0, 50)
    team_picker_box.add_child(team_picker_option)
    var picker_status := make_label("Selecione país e equipe para carregar o editor.", 9, MUTED)
    picker_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    picker_box.add_child(picker_status)

    # Barra de módulos. No Android ela pode rolar horizontalmente.
    var tabs_scroll := ScrollContainer.new()
    tabs_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
    tabs_scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    tabs_scroll.custom_minimum_size = Vector2(0, 52)
    body.add_child(tabs_scroll)
    var tabs := HBoxContainer.new()
    tabs.add_theme_constant_override("separation", 7)
    tabs_scroll.add_child(tabs)

    var tab_buttons: Array[Button] = []
    for label in ["GERAL", "ELENCO", "TÁTICAS", "UNIFORMES", "ESTÁDIO", "FINANÇAS"]:
        var tb := Button.new()
        tb.text = label
        tb.custom_minimum_size = Vector2(112, 46)
        tb.add_theme_font_size_override("font_size", 11)
        tb.add_theme_font_override("font", bold_font)
        tb.add_theme_stylebox_override("normal", make_box(Color("#181B21"), 12, 12, 6, Color("#30343D"), 1))
        tb.add_theme_stylebox_override("hover", make_box(Color("#232832"), 12, 12, 6, Color("#C8FF00"), 1))
        tb.add_theme_stylebox_override("pressed", make_box(Color("#C8FF00"), 12, 12, 6))
        tb.add_theme_color_override("font_color", WHITE)
        tb.add_theme_color_override("font_pressed_color", Color.BLACK)
        tabs.add_child(tb)
        tab_buttons.append(tb)

    var general := VBoxContainer.new()
    general.add_theme_constant_override("separation", 12)
    body.add_child(general)

    var card = func(title_text: String) -> VBoxContainer:
        var p := PanelContainer.new()
        p.add_theme_stylebox_override("panel", make_box(Color("#15181E"), 16, 14, 12, Color("#292E37"), 1))
        general.add_child(p)
        var v := VBoxContainer.new()
        v.add_theme_constant_override("separation", 9)
        p.add_child(v)
        v.add_child(make_label(title_text, 13, WHITE, true))
        return v

    var field_label = func(parent: VBoxContainer, text_value: String) -> void:
        parent.add_child(make_label(text_value, 9, MUTED, true))

    var text_field = func(parent: VBoxContainer, value: String, placeholder: String) -> LineEdit:
        var e := LineEdit.new()
        e.text = value
        e.placeholder_text = placeholder
        e.clear_button_enabled = true
        e.custom_minimum_size = Vector2(0, 52)
        e.add_theme_font_size_override("font_size", 15)
        e.add_theme_stylebox_override("normal", make_box(Color("#0F1217"), 12, 12, 7, Color("#303640"), 1))
        e.add_theme_stylebox_override("focus", make_box(Color("#12161C"), 12, 12, 7, LIME, 1))
        parent.add_child(e)
        return e

    var info_card: VBoxContainer = card.call("IDENTIDADE DO CLUBE") as VBoxContainer
    var row1: BoxContainer = BoxContainer.new()
    row1.add_theme_constant_override("separation", 10)
    info_card.add_child(row1)
    var name_box := VBoxContainer.new()
    name_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    row1.add_child(name_box)
    field_label.call(name_box, "NOME DO CLUBE")
    var name_edit: LineEdit = text_field.call(name_box, str(club.get("name", "Internacional")), "Ex.: Internacional") as LineEdit
    var short_box := VBoxContainer.new()
    short_box.custom_minimum_size = Vector2(110, 0)
    row1.add_child(short_box)
    field_label.call(short_box, "SIGLA")
    var short_edit: LineEdit = text_field.call(short_box, str(club.get("short_name", "INT")), "INT") as LineEdit

    var row2: BoxContainer = BoxContainer.new()
    row2.add_theme_constant_override("separation", 10)
    info_card.add_child(row2)
    var city_box := VBoxContainer.new()
    city_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    row2.add_child(city_box)
    field_label.call(city_box, "CIDADE")
    var city_edit: LineEdit = text_field.call(city_box, str(club.get("city", "Porto Alegre")), "Cidade") as LineEdit
    var league_box := VBoxContainer.new()
    league_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    row2.add_child(league_box)
    field_label.call(league_box, "LIGA")
    var league := OptionButton.new()
    for lg in LEAGUES:
        league.add_item(str(lg.name))
    league.custom_minimum_size = Vector2(0, 52)
    league.add_theme_font_size_override("font_size", 14)
    league_box.add_child(league)

    var stadium_card: VBoxContainer = card.call("ESTÁDIO E ESTRUTURA") as VBoxContainer
    var row3: BoxContainer = BoxContainer.new()
    row3.add_theme_constant_override("separation", 10)
    stadium_card.add_child(row3)
    var stadium_box := VBoxContainer.new()
    stadium_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    row3.add_child(stadium_box)
    field_label.call(stadium_box, "NOME DO ESTÁDIO")
    var stadium_edit: LineEdit = text_field.call(stadium_box, str(club.get("stadium", "Beira-Rio")), "Ex.: Beira-Rio") as LineEdit
    var capacity_box := VBoxContainer.new()
    capacity_box.custom_minimum_size = Vector2(145, 0)
    row3.add_child(capacity_box)
    field_label.call(capacity_box, "CAPACIDADE")
    var capacity := SpinBox.new()
    capacity.min_value = 1000
    capacity.max_value = 150000
    capacity.step = 100
    capacity.value = int(club.get("capacity", 50842))
    capacity.custom_minimum_size = Vector2(0, 52)
    capacity.add_theme_font_size_override("font_size", 14)
    capacity_box.add_child(capacity)

    var rating_card: VBoxContainer = card.call("NÍVEL DO CLUBE") as VBoxContainer
    var rating_row: BoxContainer = BoxContainer.new()
    rating_row.add_theme_constant_override("separation", 12)
    rating_card.add_child(rating_row)
    var rating_text := VBoxContainer.new()
    rating_text.custom_minimum_size = Vector2(88, 0)
    rating_row.add_child(rating_text)
    field_label.call(rating_text, "REPUTAÇÃO")
    var rating_number := make_label(str(int(club.get("reputation", 78))), 25, LIME, true)
    rating_text.add_child(rating_number)
    var slider_box := VBoxContainer.new()
    slider_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    rating_row.add_child(slider_box)
    slider_box.add_child(make_label("Nível geral", 9, MUTED, true))
    var rep := HSlider.new()
    rep.min_value = 1
    rep.max_value = 100
    rep.step = 1
    rep.value = int(club.get("reputation", 78))
    rep.custom_minimum_size = Vector2(0, 42)
    rep.value_changed.connect(func(v):
        rating_number.text = str(int(v))
        rep_value.text = str(int(v))
    )
    slider_box.add_child(rep)
    var level_box := VBoxContainer.new()
    level_box.custom_minimum_size = Vector2(155, 0)
    rating_row.add_child(level_box)
    field_label.call(level_box, "NÍVEL")
    var level := OptionButton.new()
    for x in ["Amador", "Semiprofissional", "Profissional", "Elite"]:
        level.add_item(x)
    level.select(2)
    level.custom_minimum_size = Vector2(0, 52)
    level_box.add_child(level)

    var finance_card: VBoxContainer = card.call("FINANÇAS") as VBoxContainer
    var row4: BoxContainer = BoxContainer.new()
    row4.add_theme_constant_override("separation", 10)
    finance_card.add_child(row4)
    var money_box := VBoxContainer.new()
    money_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    row4.add_child(money_box)
    field_label.call(money_box, "ORÇAMENTO")
    var money := SpinBox.new()
    money.min_value = 0
    money.max_value = 999999999
    money.step = 100000
    money.value = float(club.get("money", 50000000.0))
    money.custom_minimum_size = Vector2(0, 52)
    money_box.add_child(money)
    var wage_box := VBoxContainer.new()
    wage_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    row4.add_child(wage_box)
    field_label.call(wage_box, "FOLHA SALARIAL")
    var wage := SpinBox.new()
    wage.min_value = 0
    wage.max_value = 99999999
    wage.step = 10000
    wage.value = float(club.get("wage_budget", 1250000.0))
    wage.custom_minimum_size = Vector2(0, 52)
    wage_box.add_child(wage)

    var board_card: VBoxContainer = card.call("DIRETORIA E IDENTIDADE VISUAL") as VBoxContainer
    var goal_box := VBoxContainer.new()
    board_card.add_child(goal_box)
    field_label.call(goal_box, "META DA DIRETORIA")
    var goal: LineEdit = text_field.call(goal_box, str(club.get("board_goal", "Terminar no G6")), "Ex.: Terminar no G6") as LineEdit

    var colors: BoxContainer = BoxContainer.new()
    colors.add_theme_constant_override("separation", 10)
    board_card.add_child(colors)
    for key in ["cor_primaria", "cor_secundaria", "cor_terciaria"]:
        var cb_box := VBoxContainer.new()
        cb_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        colors.add_child(cb_box)
        field_label.call(cb_box, key.replace("cor_", "COR ").to_upper())
        var cp := ColorPickerButton.new()
        cp.custom_minimum_size = Vector2(0, 48)
        cp.color = Color(str(club.get(key, "#D71920" if key == "cor_primaria" else "#FFFFFF")))
        cp.tooltip_text = "Escolher cor"
        cb_box.add_child(cp)
        cp.color_changed.connect(func(c): club[key] = c.to_html(false))

    var hint := PanelContainer.new()
    hint.add_theme_stylebox_override("panel", make_box(Color("#101D12"), 14, 12, 9, Color("#294A2F"), 1))
    board_card.add_child(hint)
    hint.add_child(make_label("Dica: no Android, deslize a tela para acessar todas as opções. Os botões têm área de toque ampliada.", 10, Color("#A9DFAF")))

    var pv_name: Label = null
    var pv_meta: Label = null
    var refresh_editor_fields: Callable
    var save_editor_fields: Callable
    refresh_editor_fields = func() -> void:
        name_edit.text = str(club.get("name", "Clube"))
        short_edit.text = str(club.get("short_name", ""))
        city_edit.text = str(club.get("city", ""))
        stadium_edit.text = str(club.get("stadium", "Estádio Principal"))
        capacity.value = int(club.get("capacity", 10000))
        rep.value = int(club.get("reputation", 60))
        money.value = float(club.get("money", 5000000.0))
        wage.value = float(club.get("wage_budget", 150000.0))
        goal.text = str(club.get("board_goal", "Evoluir na divisão"))
        rating_number.text = str(int(rep.value))
        club_title.text = str(club.get("name", "Clube"))
        if is_instance_valid(pv_name):
            pv_name.text = str(club.get("name", "Clube"))
        if is_instance_valid(pv_meta):
            pv_meta.text = "%s  •  %s  •  %s" % [str(club.get("country", "")), str(club.get("division", "")), level.get_item_text(level.selected)]
        for key in ["cor_primaria", "cor_secundaria", "cor_terciaria"]:
            var target: ColorPickerButton = null
            if key == "cor_primaria" and colors.get_child_count() > 0:
                target = (colors.get_child(0) as VBoxContainer).get_child(1) as ColorPickerButton
            elif key == "cor_secundaria" and colors.get_child_count() > 1:
                target = (colors.get_child(1) as VBoxContainer).get_child(1) as ColorPickerButton
            elif key == "cor_terciaria" and colors.get_child_count() > 2:
                target = (colors.get_child(2) as VBoxContainer).get_child(1) as ColorPickerButton
            if is_instance_valid(target):
                target.color = Color(str(club.get(key, "#FFFFFF")))
        picker_status.text = "%s • %s" % [str(club.get("country", "")), str(club.get("division", ""))]

    save_editor_fields = func() -> void:
        var new_name: String = name_edit.text.strip_edges()
        if new_name.is_empty():
            new_name = "Clube"
        club["name"] = new_name
        club["short_name"] = short_edit.text.strip_edges()
        club["city"] = city_edit.text.strip_edges()
        club["stadium"] = stadium_edit.text.strip_edges()
        club["capacity"] = int(capacity.value)
        club["reputation"] = int(rep.value)
        club["board_goal"] = goal.text.strip_edges()
        club["money"] = float(money.value)
        club["wage_budget"] = float(wage.value)
        if colors.get_child_count() >= 3:
            club["cor_primaria"] = ((colors.get_child(0) as VBoxContainer).get_child(1) as ColorPickerButton).color.to_html(false)
            club["cor_secundaria"] = ((colors.get_child(1) as VBoxContainer).get_child(1) as ColorPickerButton).color.to_html(false)
            club["cor_terciaria"] = ((colors.get_child(2) as VBoxContainer).get_child(1) as ColorPickerButton).color.to_html(false)
        if not (editor_state["selected_ref"] as Dictionary).is_empty():
            _set_world_team_name(editor_state["selected_ref"] as Dictionary, new_name)
            var metadata: Dictionary = world_database.get("club_metadata", {}) as Dictionary
            var key: String = "%d:%d:%d" % [int((editor_state["selected_ref"] as Dictionary).get("country_index", -1)), int((editor_state["selected_ref"] as Dictionary).get("division_index", -1)), int((editor_state["selected_ref"] as Dictionary).get("team_index", -1))]
            metadata[key] = club.duplicate(true)
            world_database["club_metadata"] = metadata
            _save_world_database_edit()
            _rebuild_world_team_catalog()

    # Países e equipes disponíveis no banco mundial.
    var picker_countries: Array[String] = []
    for ref in world_team_editor_catalog:
        var country_name: String = str(ref.get("country", ""))
        if not picker_countries.has(country_name):
            picker_countries.append(country_name)
            country_picker.add_item(country_name)

    var populate_team_picker := func(country_name: String) -> void:
        team_picker_option.clear()
        var first_index: int = -1
        for i in world_team_editor_catalog.size():
            var ref: Dictionary = world_team_editor_catalog[i]
            if str(ref.get("country", "")) != country_name:
                continue
            var item_index: int = team_picker_option.item_count
            team_picker_option.add_item(str(ref.get("name", "Clube")))
            team_picker_option.set_item_metadata(item_index, i)
            if first_index == -1:
                first_index = i
        if first_index >= 0:
            team_picker_option.select(0)
            editor_state["selected_ref"] = world_team_editor_catalog[first_index].duplicate(true)
            club = _world_ref_data(editor_state["selected_ref"] as Dictionary)
            refresh_editor_fields.call()

    country_picker.item_selected.connect(func(index: int) -> void:
        var country_name: String = country_picker.get_item_text(index)
        populate_team_picker.call(country_name)
    )
    team_picker_option.item_selected.connect(func(index: int) -> void:
        if index < 0 or index >= team_picker_option.item_count:
            return
        var ref_index_variant: Variant = team_picker_option.get_item_metadata(index)
        if typeof(ref_index_variant) != TYPE_INT:
            return
        var ref_index: int = int(ref_index_variant)
        if ref_index < 0 or ref_index >= world_team_editor_catalog.size():
            return
        save_editor_fields.call()
        editor_state["selected_ref"] = world_team_editor_catalog[ref_index].duplicate(true)
        club = _world_ref_data(editor_state["selected_ref"] as Dictionary)
        refresh_editor_fields.call()
    )
    # Preview compacto, sempre visível e leve para Android.
    var preview := PanelContainer.new()
    preview.add_theme_stylebox_override("panel", make_box(Color("#0E1116"), 16, 14, 10, Color("#343A45"), 1))
    body.add_child(preview)
    var pv := VBoxContainer.new()
    pv.add_theme_constant_override("separation", 4)
    preview.add_child(pv)
    pv.add_child(make_label("PRÉVIA DO CLUBE", 12, WHITE, true))
    pv_name = make_label(str(club.get("name", "Internacional")), 19, WHITE, true)
    pv.add_child(pv_name)
    pv_meta = make_label("Brasil  •  Série A  •  Profissional", 10, MUTED)
    pv.add_child(pv_meta)
    if not (editor_state["selected_ref"] as Dictionary).is_empty():
        var initial_country: String = str((editor_state["selected_ref"] as Dictionary).get("country", ""))
        var initial_country_index: int = picker_countries.find(initial_country)
        if initial_country_index >= 0:
            country_picker.select(initial_country_index)
            populate_team_picker.call(initial_country)

    # Módulos ainda não editados nesta tela: feedback claro em vez de botões mortos.
    var module_note := make_label("ELENCO / TÁTICAS / UNIFORMES / ESTÁDIO / FINANÇAS ficam organizados nesta tela e serão ampliados nas próximas telas do editor.", 9, DIM)
    module_note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    pv.add_child(module_note)

    var footer := PanelContainer.new()
    footer.name = "EditorFooter"
    footer.custom_minimum_size = Vector2(0, 76)
    footer.add_theme_stylebox_override("panel", make_box(Color("#171A21"), 20, 12, 10, Color("#30343D"), 1))
    root.add_child(footer)
    var actions_scroll := ScrollContainer.new()
    actions_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
    actions_scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    footer.add_child(actions_scroll)
    var actions := HBoxContainer.new()
    actions.add_theme_constant_override("separation", 8)
    actions_scroll.add_child(actions)

    var save := Button.new()
    save.text = "SALVAR ALTERAÇÕES"
    save.custom_minimum_size = Vector2(190, 54)
    style_button(save, true, 54)
    save.add_theme_font_size_override("font_size", 12)
    save.pressed.connect(func():
        save_editor_fields.call()
        save_game(true)
        overlay.queue_free()
        show_screen("home")
        menu_root.visible = false
    )
    actions.add_child(save)

    var apply := Button.new()
    apply.text = "APLICAR"
    apply.custom_minimum_size = Vector2(125, 54)
    style_button(apply, false, 54)
    apply.add_theme_font_size_override("font_size", 12)
    apply.pressed.connect(func():
        save_editor_fields.call()
        club_title.text = club["name"]
        if is_instance_valid(pv_name):
            pv_name.text = str(club["name"])
        if is_instance_valid(pv_meta):
            pv_meta.text = "%s  •  %s  •  %s" % [str(club["city"]), league.get_item_text(league.selected), level.get_item_text(level.selected)]
        _mostrar_toast("Alterações aplicadas")
    )
    actions.add_child(apply)

    var restore := Button.new()
    restore.text = "RESTAURAR"
    restore.custom_minimum_size = Vector2(125, 54)
    style_button(restore, false, 54)
    restore.add_theme_font_size_override("font_size", 12)
    restore.pressed.connect(func():
        name_edit.text = "Internacional"
        short_edit.text = "INT"
        city_edit.text = "Porto Alegre"
        stadium_edit.text = "Beira-Rio"
        capacity.value = 50842
        rep.value = 78
        goal.text = "Terminar no G6"
        money.value = 50000000
        wage.value = 1250000
        _mostrar_toast("Valores restaurados")
    )
    actions.add_child(restore)

    var back := Button.new()
    back.text = "VOLTAR"
    back.custom_minimum_size = Vector2(115, 54)
    style_button(back, false, 54)
    back.add_theme_font_size_override("font_size", 12)
    back.pressed.connect(func():
        overlay.queue_free()
        menu_root.visible = true
        layout_menu()
    )
    actions.add_child(back)

    # Responsividade real: paisagem usa duas colunas onde possível; retrato vira fluxo vertical.
    var relayout := func():
        var w := overlay.size.x
        var h := overlay.size.y
        if w <= 1.0 or h <= 1.0:
            return
        var portrait := h > w * 1.05
        var mx := w * (0.025 if portrait else 0.045)
        var my := h * (0.02 if portrait else 0.035)
        panel.position = Vector2(mx, my)
        panel.size = Vector2(maxf(300.0, w - mx * 2.0), maxf(430.0, h - my * 2.0))
        header.custom_minimum_size.y = 82.0 if portrait else 88.0
        footer.custom_minimum_size.y = 72.0
        if portrait:
            head.add_theme_constant_override("separation", 8)
            rep_badge.custom_minimum_size.x = 88
            picker_row.vertical = true
            row1.vertical = true
            row2.vertical = true
            row3.vertical = true
            row4.vertical = true
            rating_row.vertical = true
            colors.vertical = true
            short_box.custom_minimum_size = Vector2(0, 0)
            capacity_box.custom_minimum_size = Vector2(0, 0)
            level_box.custom_minimum_size = Vector2(0, 0)
        else:
            head.add_theme_constant_override("separation", 14)
            rep_badge.custom_minimum_size.x = 118
            picker_row.vertical = false
            row1.vertical = false
            row2.vertical = false
            row3.vertical = false
            row4.vertical = false
            rating_row.vertical = false
            colors.vertical = false
            short_box.custom_minimum_size = Vector2(110, 0)
            capacity_box.custom_minimum_size = Vector2(145, 0)
            level_box.custom_minimum_size = Vector2(155, 0)
        scroll.custom_minimum_size.y = maxf(260.0, panel.size.y - 170.0)

    overlay.resized.connect(relayout)
    relayout.call_deferred()


func _mostrar_toast(toast_message: String) -> void:
    var toast := Label.new()
    toast.text = toast_message
    toast.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    toast.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    toast.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    toast.mouse_filter = Control.MOUSE_FILTER_IGNORE
    toast.z_index = 5000
    toast.custom_minimum_size = Vector2(280, 54)
    toast.add_theme_font_size_override("font_size", 14)
    toast.add_theme_color_override("font_color", Color.BLACK)
    toast.add_theme_stylebox_override("normal", make_box(LIME, 14, 16, 8))
    add_child(toast)
    var viewport_size: Vector2 = get_viewport_rect().size
    toast.position = Vector2(maxf(12.0, (viewport_size.x - 280.0) * 0.5), 24.0)
    var tween: Tween = create_tween()
    tween.tween_interval(1.15)
    tween.tween_property(toast, "modulate:a", 0.0, 0.25)
    tween.tween_callback(toast.queue_free)


# ---------------------------------------------------------------- MENU PRINCIPAL

func circle_points(center, r, steps := 56):
    var pts = PackedVector2Array()
    for i in steps:
        var ang = TAU * float(i) / float(steps)
        pts.append(center + Vector2(cos(ang), sin(ang)) * r)
    return pts


func build_brand(parent, title_px, center := false):
    var brand = VBoxContainer.new()
    brand.add_theme_constant_override("separation", 6)
    parent.add_child(brand)
    var r1 = HBoxContainer.new()
    r1.add_theme_constant_override("separation", 12)
    brand.add_child(r1)
    var lg = PanelContainer.new()
    lg.custom_minimum_size = Vector2(44, 44)
    lg.add_theme_stylebox_override("panel", make_box(LIME, 12, 0, 0))
    var lw = make_label("W", 20, Color.BLACK, false, HORIZONTAL_ALIGNMENT_CENTER)
    lw.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    lg.add_child(lw)
    r1.add_child(lg)
    var ln = ColorRect.new()
    ln.color = Color(1, 1, 1, 0.2)
    ln.custom_minimum_size = Vector2(40, 1)
    ln.size_flags_vertical = Control.SIZE_SHRINK_CENTER
    r1.add_child(ln)
    r1.add_child(make_label("ANDROID • GODOT 4", 10, Color(1, 1, 1, 0.4), true))
    var title = make_label("WILFOOT 2.1", title_px, Color("#F5F5F5"))
    brand.add_child(title)
    var r2 = HBoxContainer.new()
    r2.add_theme_constant_override("separation", 12)
    brand.add_child(r2)
    r2.add_child(make_label("FOOTBALL MANAGER MOBILE", 12, Color(1, 1, 1, 0.55), true))
    r2.add_child(pill("2.1", LIME, Color.WHITE, 11, 10, 3))
    if center:
        r1.alignment = BoxContainer.ALIGNMENT_CENTER
        r2.alignment = BoxContainer.ALIGNMENT_CENTER
        title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    return brand


func build_menu_21() -> void:
    # WILFOOT 2.1 — dashboard premium, focado em Android e toque.
    menu_language_built = str(WilfootLocalization.current_language) if is_instance_valid(WilfootLocalization) else "pt_BR"
    menu_root = Control.new()
    menu_root.name = "WILFOOT21"
    menu_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    menu_root.mouse_filter = Control.MOUSE_FILTER_STOP
    menu_root.process_mode = Node.PROCESS_MODE_ALWAYS
    menu_root.z_index = 1000
    add_child(menu_root)

    var bg := TextureRect.new()
    bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    bg.texture = load("res://assets/wilfoot_menu_bg.png")
    bg.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    bg.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
    bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
    menu_root.add_child(bg)

    var shade := ColorRect.new()
    shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    shade.color = Color(0.005, 0.018, 0.04, 0.78)
    shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
    menu_root.add_child(shade)

    var glow_a := ColorRect.new()
    glow_a.color = Color(0.02, 0.35, 0.70, 0.10)
    glow_a.position = Vector2(-180, -140)
    glow_a.size = Vector2(650, 420)
    glow_a.mouse_filter = Control.MOUSE_FILTER_IGNORE
    menu_root.add_child(glow_a)

    var margin := MarginContainer.new()
    margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    margin.add_theme_constant_override("margin_left", 18)
    margin.add_theme_constant_override("margin_right", 18)
    margin.add_theme_constant_override("margin_top", 14)
    margin.add_theme_constant_override("margin_bottom", 14)
    margin.mouse_filter = Control.MOUSE_FILTER_IGNORE
    menu_root.add_child(margin)

    var root := VBoxContainer.new()
    root.add_theme_constant_override("separation", 10)
    root.mouse_filter = Control.MOUSE_FILTER_IGNORE
    margin.add_child(root)

    var top := PanelContainer.new()
    top.custom_minimum_size = Vector2(0, 66)
    top.add_theme_stylebox_override("panel", make_box(Color(0.01, 0.05, 0.09, 0.96), 18, 12, 7, Color("#1F79AE"), 1))
    root.add_child(top)
    var top_h := HBoxContainer.new()
    top_h.add_theme_constant_override("separation", 10)
    top.add_child(top_h)
    var logo := PanelContainer.new()
    logo.custom_minimum_size = Vector2(48, 48)
    logo.add_theme_stylebox_override("panel", make_box(LIME, 14, 0, 0))
    var logo_l := make_label("W", 24, Color.BLACK, true, HORIZONTAL_ALIGNMENT_CENTER)
    logo_l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    logo.add_child(logo_l)
    top_h.add_child(logo)
    var brand := VBoxContainer.new()
    brand.add_theme_constant_override("separation", 0)
    top_h.add_child(brand)
    brand.add_child(make_label("WILFOOT 2.1", 22, WHITE, true))
    brand.add_child(make_label("FOOTBALL MANAGER • ANDROID", 9, NEON, true))
    var top_sp := Control.new()
    top_sp.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    top_h.add_child(top_sp)
    top_h.add_child(_menu21_chip("2026", "TEMPORADA"))
    top_h.add_child(_menu21_chip("1.200", "CLUBES"))
    top_h.add_child(_menu21_chip("10", "PAÍSES"))

    var body := HBoxContainer.new()
    body.size_flags_vertical = Control.SIZE_EXPAND_FILL
    body.add_theme_constant_override("separation", 10)
    body.mouse_filter = Control.MOUSE_FILTER_IGNORE
    root.add_child(body)

    var left := VBoxContainer.new()
    left.custom_minimum_size = Vector2(220, 0)
    left.add_theme_constant_override("separation", 8)
    body.add_child(left)
    var profile := PanelContainer.new()
    profile.custom_minimum_size = Vector2(0, 112)
    profile.add_theme_stylebox_override("panel", make_box(Color(0.01,0.045,0.08,0.95), 18, 12, 7, Color("#1C5D84"), 1))
    left.add_child(profile)
    var pv := VBoxContainer.new()
    pv.add_theme_constant_override("separation", 4)
    profile.add_child(pv)
    pv.add_child(make_label("CARREIRA", 9, GOLD, true))
    pv.add_child(make_label(str(club.get("name", "Seu Clube")).to_upper(), 18, WHITE, true))
    pv.add_child(make_label("Treinador • %s" % str(coach.get("name", "Novo treinador")), 10, MUTED))
    pv.add_child(make_label("R$ %s" % money_str(float(club.get("money", 0.0))), 13, GREEN, true))

    var nav := PanelContainer.new()
    nav.size_flags_vertical = Control.SIZE_EXPAND_FILL
    nav.add_theme_stylebox_override("panel", make_box(Color(0.01,0.04,0.07,0.95), 18, 10, 6, Color("#164D78"), 1))
    left.add_child(nav)
    var nv := VBoxContainer.new()
    nv.add_theme_constant_override("separation", 5)
    nav.add_child(nv)
    nv.add_child(make_label("CENTRAL DA CARREIRA", 9, MUTED, true))
    _menu21_nav(nv, "▶  CONTINUAR CARREIRA", func(): _menu21_open("home"), true)
    _menu21_nav(nv, "⚽  ELENCO", func(): _menu21_open("squad"), false)
    _menu21_nav(nv, "♟  TÁTICAS", func(): _menu21_open("tactics"), false)
    _menu21_nav(nv, "↔  MERCADO", func(): _menu21_open("market"), false)
    _menu21_nav(nv, "🏆  COMPETIÇÕES", func(): _menu21_open("jogos"), false)
    _menu21_nav(nv, "🌍  MUNDO VIVO", func(): _menu21_open("world_live"), false)
    _menu21_nav(nv, "✎  EDITOR 1.200 CLUBES", open_team_editor, false)
    var nv_sp := Control.new()
    nv_sp.size_flags_vertical = Control.SIZE_EXPAND_FILL
    nv.add_child(nv_sp)
    nv.add_child(make_label("ENGINE 7.0 • GL COMPATIBILITY", 8, GREEN, true))
    nv.add_child(make_label("TOQUE • 60 FPS • MOTO G54", 8, MUTED, true))

    var center := VBoxContainer.new()
    center.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    center.add_theme_constant_override("separation", 10)
    body.add_child(center)

    var hero := PanelContainer.new()
    hero.custom_minimum_size = Vector2(0, 150)
    hero.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    hero.add_theme_stylebox_override("panel", make_box(Color(0.015,0.05,0.09,0.96), 20, 14, 8, Color("#2287BD"), 1))
    center.add_child(hero)
    var hv := VBoxContainer.new()
    hv.add_theme_constant_override("separation", 5)
    hero.add_child(hv)
    hv.add_child(make_label("SUA HISTÓRIA COMEÇA AGORA", 9, GOLD, true))
    hv.add_child(make_label("WILFOOT", 42, WHITE, true))
    hv.add_child(make_label("2.1", 20, LIME, true))
    hv.add_child(make_label("Controle o clube, escale, negocie, evolua e conquiste o mundo.", 11, Color("#C6D7E4")))
    var hero_actions := HBoxContainer.new()
    hero_actions.add_theme_constant_override("separation", 8)
    hv.add_child(hero_actions)
    _menu21_big_button(hero_actions, "▶  CONTINUAR", func(): _menu21_open("home"), true)
    _menu21_big_button(hero_actions, "⚽  PRÓXIMO JOGO", func(): _menu21_open("jogos"), false)

    var ranking_title := HBoxContainer.new()
    center.add_child(ranking_title)
    var rt := make_label("RANKINGS DO MUNDO", 12, WHITE, true)
    rt.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    ranking_title.add_child(rt)
    ranking_title.add_child(make_label("ATUALIZADO • TEMPORADA 2026", 8, MUTED, true))

    var rank_row := HBoxContainer.new()
    rank_row.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    rank_row.add_theme_constant_override("separation", 8)
    center.add_child(rank_row)
    _menu21_rank_card(rank_row, "🏆", "BOLA DE OURO", "O. Dembélé", "78.79 pts", GOLD, func(): _menu21_open("rankings"))
    _menu21_rank_card(rank_row, "🌍", "SELEÇÕES", "Argentina", "1900 pts", LIME, func(): _menu21_open("rankings"))

    var quick := HBoxContainer.new()
    quick.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    quick.add_theme_constant_override("separation", 8)
    center.add_child(quick)
    _menu21_quick_card(quick, "🏅", "RANKING DE CLUBES", "Força • títulos • forma", func(): _menu21_open("rankings"))
    _menu21_quick_card(quick, "🏟", "RANKING DE LIGAS", "Coeficiente mundial", func(): _menu21_open("rankings"))
    _menu21_quick_card(quick, "🏆", "TROFÉUS", "Galeria da carreira", func(): _menu21_open("trofeus"))

    var right := VBoxContainer.new()
    right.custom_minimum_size = Vector2(300, 0)
    right.add_theme_constant_override("separation", 8)
    body.add_child(right)

    var next := PanelContainer.new()
    next.custom_minimum_size = Vector2(0, 166)
    next.add_theme_stylebox_override("panel", make_box(Color(0.01,0.045,0.075,0.97), 20, 13, 8, Color("#1D678E"), 1))
    right.add_child(next)
    var fxv := VBoxContainer.new()
    fxv.add_theme_constant_override("separation", 7)
    next.add_child(fxv)
    fxv.add_child(make_label("PRÓXIMA PARTIDA", 9, GOLD, true))
    var fixture: Dictionary = user_fixture(round_no)
    if fixture.is_empty():
        fxv.add_child(make_label("Temporada encerrada", 18, WHITE, true))
        fxv.add_child(make_label("Prepare a nova temporada.", 10, MUTED))
    else:
        var opponent: String = str(fixture.get("opp", "Adversário"))
        fxv.add_child(make_label(str(club.get("name", "Seu Clube")), 15, WHITE, true))
        fxv.add_child(make_label("VS", 10, NEON, true, HORIZONTAL_ALIGNMENT_CENTER))
        fxv.add_child(make_label(opponent, 15, WHITE, true))
        fxv.add_child(make_label("RODADA %d • %s" % [round_no, "CASA" if bool(fixture.get("home", true)) else "FORA"], 9, MUTED, true))
        _menu21_big_button(fxv, "JOGAR PARTIDA", func(): _menu21_open("jogos"), true)

    var status := PanelContainer.new()
    status.size_flags_vertical = Control.SIZE_EXPAND_FILL
    status.add_theme_stylebox_override("panel", make_box(Color(0.01,0.04,0.07,0.96), 20, 12, 7, Color("#164D78"), 1))
    right.add_child(status)
    var sv := VBoxContainer.new()
    sv.add_theme_constant_override("separation", 7)
    status.add_child(sv)
    sv.add_child(make_label("CENTRAL RÁPIDA", 9, MUTED, true))
    _menu21_action(sv, "NOVO JOGO", _menu_new_game_pressed, true)
    _menu21_action(sv, "CARREGAR SAVE", _menu_load_game_pressed, false)
    _menu21_action(sv, "SALVAR CARREIRA", save_from_menu, false)
    _menu21_action(sv, "PREMIAÇÕES", func(): _menu21_open("premiacoes"), false)
    _menu21_action(sv, "SAIR", quit_game, false)

    var footer := make_label("WILFOOT 2.1  •  Android  •  1.200 clubes  •  10 países  •  interface touch", 8, Color(1,1,1,0.48), true, HORIZONTAL_ALIGNMENT_CENTER)
    root.add_child(footer)

func _menu21_chip(value_text: String, caption: String) -> Control:
    var p := PanelContainer.new()
    p.custom_minimum_size = Vector2(92, 42)
    p.add_theme_stylebox_override("panel", make_box(Color(1,1,1,0.045), 12, 7, 5, Color("#1B4E6D"), 1))
    var v := VBoxContainer.new()
    v.add_theme_constant_override("separation", 0)
    p.add_child(v)
    v.add_child(make_label(value_text, 13, WHITE, true, HORIZONTAL_ALIGNMENT_CENTER))
    v.add_child(make_label(caption, 7, MUTED, true, HORIZONTAL_ALIGNMENT_CENTER))
    return p

func _menu21_nav(parent: VBoxContainer, label_text: String, cb: Callable, active: bool) -> void:
    var b := Button.new()
    b.text = loc_text(label_text)
    b.alignment = HORIZONTAL_ALIGNMENT_LEFT
    b.custom_minimum_size = Vector2(0, 44)
    b.mouse_filter = Control.MOUSE_FILTER_STOP
    b.add_theme_font_override("font", bold_font)
    b.add_theme_font_size_override("font_size", 11)
    b.add_theme_stylebox_override("normal", make_box(Color("#0877B8") if active else Color(0,0,0,0), 11, 9, 5, Color("#2BB8FF") if active else Color(0,0,0,0), 1 if active else 0))
    b.add_theme_stylebox_override("hover", make_box(Color("#126C9F"), 11, 9, 5, Color("#2BB8FF"), 1))
    b.add_theme_stylebox_override("pressed", make_box(Color("#07557F"), 11, 9, 5))
    b.add_theme_color_override("font_color", WHITE if active else Color("#B7C7D5"))
    b.pressed.connect(cb)
    parent.add_child(b)

func _menu21_big_button(parent: Control, label_text: String, cb: Callable, primary: bool) -> void:
    var b := Button.new()
    b.text = loc_text(label_text)
    b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    b.custom_minimum_size = Vector2(0, 42)
    b.mouse_filter = Control.MOUSE_FILTER_STOP
    style_button(b, primary, 42)
    b.add_theme_font_size_override("font_size", 11)
    b.pressed.connect(cb)
    parent.add_child(b)

func _menu21_rank_card(parent: HBoxContainer, icon_text: String, title_text: String, person_text: String, points_text: String, accent: Color, cb: Callable) -> void:
    var b := Button.new()
    b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    b.custom_minimum_size = Vector2(0, 88)
    b.mouse_filter = Control.MOUSE_FILTER_STOP
    b.add_theme_stylebox_override("normal", make_box(Color(0.01,0.05,0.085,0.96), 16, 10, 6, Color(accent,0.32), 1))
    b.add_theme_stylebox_override("hover", make_box(Color(0.04,0.12,0.18,0.98), 16, 10, 6, accent, 1))
    b.add_theme_stylebox_override("pressed", make_box(Color(0.02,0.08,0.13,1.0), 16, 10, 6, accent, 1))
    b.add_theme_color_override("font_color", WHITE)
    b.add_theme_color_override("font_hover_color", WHITE)
    b.text = "%s  %s\n%s  •  %s" % [icon_text, loc_text(title_text), loc_text(person_text), loc_text(points_text)]
    b.add_theme_font_override("font", bold_font)
    b.add_theme_font_size_override("font_size", 11)
    b.pressed.connect(cb)
    parent.add_child(b)

func _menu21_quick_card(parent: HBoxContainer, icon_text: String, title_text: String, sub_text: String, cb: Callable) -> void:
    var b := Button.new()
    b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    b.custom_minimum_size = Vector2(0, 66)
    b.text = "%s  %s\n%s" % [icon_text, loc_text(title_text), loc_text(sub_text)]
    b.alignment = HORIZONTAL_ALIGNMENT_LEFT
    b.mouse_filter = Control.MOUSE_FILTER_STOP
    b.add_theme_stylebox_override("normal", make_box(Color(0.01,0.04,0.07,0.95), 15, 9, 6, Color("#1B4E6D"), 1))
    b.add_theme_stylebox_override("hover", make_box(Color("#102A3C"), 15, 9, 6, Color("#2BB8FF"), 1))
    b.add_theme_stylebox_override("pressed", make_box(Color("#0B1C29"), 15, 9, 6, Color("#168BD0"), 1))
    b.add_theme_color_override("font_color", WHITE)
    b.add_theme_font_override("font", bold_font)
    b.add_theme_font_size_override("font_size", 10)
    b.pressed.connect(cb)
    parent.add_child(b)

func _menu21_action(parent: VBoxContainer, label_text: String, cb: Callable, primary: bool) -> void:
    var b := Button.new()
    b.text = loc_text(label_text)
    b.custom_minimum_size = Vector2(0, 42)
    b.mouse_filter = Control.MOUSE_FILTER_STOP
    style_button(b, primary, 42)
    b.add_theme_font_size_override("font_size", 11)
    b.pressed.connect(cb)
    parent.add_child(b)

func _menu21_open(target: String) -> void:
    if is_instance_valid(menu_root):
        menu_root.visible = false
    show_screen(target)

func build_menu():
    # WILFOOT 2.1 — menu principal redesenhado para Android.
    menu_root = Control.new()
    menu_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    menu_root.mouse_filter = Control.MOUSE_FILTER_STOP
    menu_root.process_mode = Node.PROCESS_MODE_ALWAYS
    menu_root.z_index = 1000
    add_child(menu_root)

    menu_bg = TextureRect.new()
    menu_bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    menu_bg.texture = load("res://assets/wilfoot_menu_bg.png")
    menu_bg.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    menu_bg.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
    menu_bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
    menu_root.add_child(menu_bg)

    menu_overlay = ColorRect.new()
    menu_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    menu_overlay.color = Color(0.0, 0.025, 0.06, 0.68)
    menu_overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
    menu_root.add_child(menu_overlay)

    # Brilhos leves: mantêm o visual premium sem pesar no Moto G54.
    add_glow(menu_root, Vector2(110, 70), 320, Color(LIME, 0.07))
    add_glow(menu_root, Vector2(1110, 620), 360, Color(GOLD, 0.045))

    # Top bar.
    var top := PanelContainer.new()
    top.name = "MenuTopBar"
    top.add_theme_stylebox_override("panel", make_box(Color(0.015, 0.055, 0.09, 0.96), 18, 14, 7, Color("#1A5B86"), 1))
    top.mouse_filter = Control.MOUSE_FILTER_IGNORE
    menu_root.add_child(top)
    var top_h := HBoxContainer.new()
    top_h.add_theme_constant_override("separation", 10)
    top.add_child(top_h)
    var logo := PanelContainer.new()
    logo.custom_minimum_size = Vector2(50, 50)
    logo.add_theme_stylebox_override("panel", make_box(LIME, 14, 0, 0))
    var lw := make_label("W", 25, Color.BLACK, true, HORIZONTAL_ALIGNMENT_CENTER)
    lw.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    logo.add_child(lw)
    top_h.add_child(logo)
    var title_box := VBoxContainer.new()
    title_box.add_theme_constant_override("separation", 0)
    top_h.add_child(title_box)
    title_box.add_child(make_label("WILFOOT 2.1", 24, WHITE, true))
    title_box.add_child(make_label("FOOTBALL MANAGER MOBILE • ANDROID", 9, NEON, true))
    var top_spacer := Control.new()
    top_spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    top_h.add_child(top_spacer)
    top_h.add_child(_menu_stat_pill("📅", "TEMPORADA 2026"))
    top_h.add_child(_menu_stat_pill("💰", "R$ 50,0 M"))
    top_h.add_child(_menu_stat_pill("⚙", "MOTO G54"))

    # Sidebar.
    var side := PanelContainer.new()
    side.name = "MenuSidebar"
    side.add_theme_stylebox_override("panel", make_box(Color(0.01, 0.04, 0.07, 0.95), 18, 12, 7, Color("#164D78"), 1))
    menu_root.add_child(side)
    var side_v := VBoxContainer.new()
    side_v.add_theme_constant_override("separation", 5)
    side.add_child(side_v)
    side_v.add_child(make_label("MENU PRINCIPAL", 11, MUTED, true))
    for item in [["⌂", "INÍCIO"], ["⚽", "ELENCO"], ["▦", "COMPETIÇÕES"], ["🏆", "RANKINGS"], ["♟", "TÁTICAS"], ["↔", "TRANSFERÊNCIAS"], ["✎", "EDITOR DE EQUIPES"], ["⚙", "OPÇÕES"]]:
        var nav := Button.new()
        nav.text = "%s   %s" % [item[0], item[1]]
        nav.alignment = HORIZONTAL_ALIGNMENT_LEFT
        nav.custom_minimum_size = Vector2(0, 44)
        nav.add_theme_font_override("font", bold_font)
        nav.add_theme_font_size_override("font_size", 12)
        var active: bool = str(item[1]) == "INÍCIO"
        nav.add_theme_stylebox_override("normal", make_box(Color("#0877B8") if active else Color(0,0,0,0), 11, 8, 5, Color("#2BB8FF") if active else Color(0,0,0,0), 1 if active else 0))
        nav.add_theme_stylebox_override("hover", make_box(Color("#126C9F"), 11, 8, 5, Color("#2BB8FF"), 1))
        nav.add_theme_stylebox_override("pressed", make_box(Color("#07557F"), 11, 8, 5))
        nav.add_theme_color_override("font_color", WHITE if active else Color("#B7C7D5"))
        nav.mouse_filter = Control.MOUSE_FILTER_STOP
        side_v.add_child(nav)
        if item[1] == "EDITOR DE EQUIPES":
            nav.pressed.connect(open_team_editor)
        elif item[1] == "RANKINGS":
            nav.pressed.connect(func(): menu_root.visible = false; show_screen("rankings"))
        elif item[1] == "COMPETIÇÕES":
            nav.pressed.connect(func(): menu_root.visible = false; show_screen("competitions"))
    var side_sp := Control.new()
    side_sp.size_flags_vertical = Control.SIZE_EXPAND_FILL
    side_v.add_child(side_sp)
    side_v.add_child(make_label("● ENGINE 7.0  •  60 FPS", 9, GREEN, true))
    side_v.add_child(make_label("1.200 CLUBES • 10 PAÍSES", 9, MUTED, true))

    # Hero central.
    var hero := PanelContainer.new()
    hero.name = "MenuHero"
    hero.add_theme_stylebox_override("panel", make_box(Color(0.01, 0.03, 0.06, 0.82), 22, 18, 9, Color("#1D75AA"), 1))
    menu_root.add_child(hero)
    var hero_v := VBoxContainer.new()
    hero_v.add_theme_constant_override("separation", 8)
    hero.add_child(hero_v)
    hero_v.add_child(make_label("SUA CARREIRA. SEU CLUBE. SUA HISTÓRIA.", 10, GOLD, true))
    hero_v.add_child(make_label("WILFOOT", 50, WHITE, true))
    hero_v.add_child(make_label("2.0", 28, LIME, true))
    var hline := ColorRect.new()
    hline.color = Color(0.15, 0.65, 1.0, 0.8)
    hline.custom_minimum_size = Vector2(0, 2)
    hero_v.add_child(hline)
    hero_v.add_child(make_label("Gerencie elenco, táticas, mercado, finanças e títulos.\nUma experiência completa feita para Android.", 13, Color("#C7D5E0"), false))
    var hero_sp := Control.new()
    hero_sp.size_flags_vertical = Control.SIZE_EXPAND_FILL
    hero_v.add_child(hero_sp)
    var feature_row := HBoxContainer.new()
    feature_row.add_theme_constant_override("separation", 7)
    hero_v.add_child(feature_row)
    for f in [["1.200", "CLUBES"], ["10", "PAÍSES"], ["7.0", "ENGINE"], ["60", "FPS"]]:
        var card := PanelContainer.new()
        card.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        card.custom_minimum_size = Vector2(0, 56)
        card.add_theme_stylebox_override("panel", make_box(Color(1,1,1,0.045), 12, 7, 5, Color("#1B4E6D"), 1))
        var cv := VBoxContainer.new()
        cv.alignment = BoxContainer.ALIGNMENT_CENTER
        card.add_child(cv)
        cv.add_child(make_label(f[0], 18, LIME, true, HORIZONTAL_ALIGNMENT_CENTER))
        cv.add_child(make_label(f[1], 8, MUTED, true, HORIZONTAL_ALIGNMENT_CENTER))
        feature_row.add_child(card)

    # Painel de ações.
    var actions := PanelContainer.new()
    actions.name = "MenuActions"
    actions.add_theme_stylebox_override("panel", make_box(Color(0.01, 0.035, 0.06, 0.96), 22, 14, 8, Color("#164D78"), 1))
    menu_root.add_child(actions)
    var actions_title := make_label("CENTRAL DA CARREIRA", 11, MUTED, true)
    actions_title.position = Vector2(18, 16)
    actions_title.size = Vector2(300, 24)
    actions.add_child(actions_title)

    menu_buttons.clear()
    menu_button("NOVO JOGO", Rect2(), _menu_new_game_pressed, true)
    menu_button("CARREGAR JOGO SALVO", Rect2(), _menu_load_game_pressed, false)
    menu_button("EDITOR DE EQUIPES", Rect2(), open_team_editor, false)
    menu_button("SALVAR JOGO", Rect2(), save_from_menu, false)
    menu_button("RANKINGS", Rect2(), func(): menu_root.visible = false; show_screen("rankings"), false)
    menu_button("GALERIA DE TROFÉUS", Rect2(), func(): menu_root.visible = false; show_screen("trofeus"), false)
    var quit_b: Button = menu_button("SAIR", Rect2(), quit_game, false)
    for k in ["font_color", "font_hover_color", "font_pressed_color", "font_focus_color", "font_hover_pressed_color"]:
        quit_b.add_theme_color_override(k, MUTED)

    menu_msg = Label.new()
    menu_msg.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    menu_msg.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    menu_msg.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    menu_msg.add_theme_color_override("font_color", LIME)
    menu_msg.add_theme_font_override("font", bold_font)
    menu_msg.add_theme_font_size_override("font_size", 13)
    menu_msg.mouse_filter = Control.MOUSE_FILTER_IGNORE
    menu_root.add_child(menu_msg)

    var foot := make_label("WILFOOT ENGINE 7.0  •  ANDROID  •  2026", 9, Color(1,1,1,0.48), true, HORIZONTAL_ALIGNMENT_CENTER)
    foot.name = "MenuFooter"
    foot.mouse_filter = Control.MOUSE_FILTER_IGNORE
    menu_root.add_child(foot)

    menu_root.resized.connect(layout_menu)
    call_deferred("layout_menu")


func _menu_stat_pill(icon_text: String, value_text: String) -> Control:
    var p := PanelContainer.new()
    p.custom_minimum_size = Vector2(118, 48)
    p.add_theme_stylebox_override("panel", make_box(Color(1,1,1,0.045), 12, 7, 5, Color("#1B4E6D"), 1))
    var h := HBoxContainer.new()
    h.add_theme_constant_override("separation", 6)
    p.add_child(h)
    h.add_child(make_label(icon_text, 15, GOLD, true, HORIZONTAL_ALIGNMENT_CENTER))
    h.add_child(make_label(value_text, 8, WHITE, true, HORIZONTAL_ALIGNMENT_CENTER))
    return p


func layout_menu():
    if not is_instance_valid(menu_root):
        return
    var w: float = menu_root.size.x
    var h: float = menu_root.size.y
    if w <= 1.0 or h <= 1.0:
        return
    var portrait := h > w * 1.08
    var compact := w < 1050.0
    var top: Control = menu_root.get_node_or_null("MenuTopBar") as Control
    var side: Control = menu_root.get_node_or_null("MenuSidebar") as Control
    var hero: Control = menu_root.get_node_or_null("MenuHero") as Control
    var actions: Control = menu_root.get_node_or_null("MenuActions") as Control
    if portrait:
        if is_instance_valid(top):
            top.position = Vector2(10, 10)
            top.size = Vector2(w - 20, 68)
        if is_instance_valid(side):
            side.visible = false
        if is_instance_valid(hero):
            hero.position = Vector2(10, 88)
            hero.size = Vector2(w - 20, minf(285.0, h * 0.32))
        if is_instance_valid(actions):
            actions.position = Vector2(10, hero.position.y + hero.size.y + 10)
            actions.size = Vector2(w - 20, maxf(310.0, h - actions.position.y - 42.0))
        _layout_action_buttons(actions, w - 20, actions.size.y)
        menu_msg.position = Vector2(10, h - 34)
        menu_msg.size = Vector2(w - 20, 24)
    else:
        if is_instance_valid(top):
            top.position = Vector2(18, 14)
            top.size = Vector2(w - 36, 72)
        var side_w := 210.0 if compact else 230.0
        var actions_w := 305.0 if compact else 350.0
        var gap := 12.0
        var y := 98.0
        var hh := maxf(360.0, h - y - 44.0)
        if is_instance_valid(side):
            side.visible = true
            side.position = Vector2(18, y)
            side.size = Vector2(side_w, hh)
        if is_instance_valid(hero):
            hero.position = Vector2(18 + side_w + gap, y)
            hero.size = Vector2(maxf(360.0, w - 18.0 - side_w - actions_w - gap * 3.0), hh)
        if is_instance_valid(actions):
            actions.position = Vector2(w - actions_w - 18.0, y)
            actions.size = Vector2(actions_w, hh)
        _layout_action_buttons(actions, actions_w, hh)
        menu_msg.position = Vector2(18, h - 34)
        menu_msg.size = Vector2(w - 36, 24)
        var foot := menu_root.get_node_or_null("MenuFooter") as Control
        if is_instance_valid(foot):
            foot.position = Vector2(18, h - 28)
            foot.size = Vector2(w - 36, 20)


func _layout_action_buttons(actions: Control, width: float, height: float) -> void:
    if not is_instance_valid(actions):
        return
    var labels := ["NOVO JOGO", "CARREGAR JOGO SALVO", "EDITOR DE EQUIPES", "SALVAR JOGO", "RANKINGS", "GALERIA DE TROFÉUS", "SAIR"]
    var x: float = actions.position.x + 14.0
    var y: float = actions.position.y + 52.0
    var bw: float = maxf(220.0, width - 28.0)
    var bh: float = 50.0 if height < 500.0 else 54.0
    var gap: float = 8.0
    for label_text in labels:
        var b: Button = menu_buttons.get(label_text) as Button
        if not is_instance_valid(b):
            continue
        b.position = Vector2(x, y)
        b.size = Vector2(bw, bh)
        b.custom_minimum_size = Vector2(bw, bh)
        b.add_theme_font_size_override("font_size", 15 if height < 500.0 else 16)
        y += bh + gap
func menu_line(points, color, width):
    var l = Line2D.new()
    l.points = PackedVector2Array(points)
    l.default_color = color
    l.width = width
    l.antialiased = true
    menu_root.add_child(l)
    return l


func menu_button(text, rect, cb, primary := true):
    var b = Button.new()
    b.text = loc_text(str(text))
    b.position = rect.position
    b.size = rect.size
    style_button(b, primary, max(48, int(rect.size.y)))
    b.custom_minimum_size = rect.size
    b.mouse_filter = Control.MOUSE_FILTER_STOP
    b.focus_mode = Control.FOCUS_ALL
    b.disabled = false
    b.z_index = 1100
    b.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
    b.add_theme_font_size_override("font_size", 18)
    b.pressed.connect(cb)
    menu_buttons[text] = b
    menu_root.add_child(b)
    return b


# Tela de abertura (boot) antes do menu.
func build_boot():
    boot_root = Control.new()
    boot_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(boot_root)
    var bg = ColorRect.new()
    bg.color = Color("#0C0C0E")
    bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    boot_root.add_child(bg)
    add_glow(boot_root, Vector2(200, 60), 420, Color(LIME, 0.05))
    add_glow(boot_root, Vector2(1100, 700), 380, Color(NEON, 0.05))
    var a = menu_line_on(boot_root, circle_points(Vector2(640, 360), 210), Color(LIME, 0.10), 2)
    a.closed = true
    var b = menu_line_on(boot_root, circle_points(Vector2(640, 360), 150), Color(1, 1, 1, 0.05), 2)
    b.closed = true

    var cc = CenterContainer.new()
    cc.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    boot_root.add_child(cc)
    var vb = VBoxContainer.new()
    vb.add_theme_constant_override("separation", 30)
    cc.add_child(vb)
    build_brand(vb, 72, true)

    var pv = VBoxContainer.new()
    pv.custom_minimum_size = Vector2(260, 0)
    pv.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
    pv.add_theme_constant_override("separation", 8)
    vb.add_child(pv)
    var ph = HBoxContainer.new()
    pv.add_child(ph)
    var pl = make_label("BOOTING MAIN.TSCN", 10, Color(1, 1, 1, 0.3), true)
    pl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    ph.add_child(pl)
    boot_pct = make_label("0%", 10, Color(1, 1, 1, 0.3), true)
    ph.add_child(boot_pct)
    boot_bar = ProgressBar.new()
    boot_bar.show_percentage = false
    boot_bar.max_value = 100.0
    boot_bar.custom_minimum_size = Vector2(0, 4)
    boot_bar.add_theme_stylebox_override("background", make_box(Color(1, 1, 1, 0.10), 100, 0, 0))
    boot_bar.add_theme_stylebox_override("fill", make_box(LIME, 100, 0, 0))
    pv.add_child(boot_bar)

    var tw = create_tween()
    tw.tween_method(set_boot_progress, 0.0, 100.0, 1.6)
    tw.tween_property(boot_root, "modulate:a", 0.0, 0.35)
    tw.tween_callback(hide_boot)


func menu_line_on(parent, points, color, width):
    var l = Line2D.new()
    l.points = PackedVector2Array(points)
    l.default_color = color
    l.width = width
    l.antialiased = true
    parent.add_child(l)
    return l


func set_boot_progress(v):
    boot_bar.value = v
    boot_pct.text = "%d%%" % int(v)


func hide_boot():
    boot_root.visible = false


func show_menu():
    var active_language: String = str(WilfootLocalization.current_language) if is_instance_valid(WilfootLocalization) else "pt_BR"
    if not is_instance_valid(menu_root) or menu_language_built != active_language:
        if is_instance_valid(menu_root):
            menu_root.queue_free()
        build_menu_21()
    menu_msg.text = ""
    menu_root.visible = true


func back_to_menu():
    save_game(true)
    show_menu()


func _menu_new_game_pressed() -> void:
    # Entrada dedicada do botão principal: evita referências antigas/capturas inválidas.
    if not is_instance_valid(menu_root):
        return
    start_new_game()


func _menu_load_game_pressed() -> void:
    # Entrada dedicada do botão de carregar: mantém o botão responsivo no Android.
    if not is_instance_valid(menu_root):
        return
    continue_game()


func start_new_game():
    if FileAccess.file_exists(SAVE_PATH):
        var ok = await ask_dialog("Começar um novo jogo?\n\nO save atual será substituído quando você jogar a próxima partida ou salvar.", "NOVO JOGO", "CANCELAR")
        if not ok:
            return
    reset_game()
    menu_root.visible = false
    show_screen("home")


func continue_game():
    if load_game():
        menu_root.visible = false
        show_screen("home")
    else:
        menu_msg.text = loc_text("Nenhum save compatível encontrado.")


func save_from_menu():
    save_game(true)
    menu_msg.text = loc_text("Carreira salva com sucesso.")
    # Mantém o jogador no menu; não abre a carreira por acidente.


func quit_game():
    get_tree().quit()


# ---------------------------------------------------------------- PARTIDA AO VIVO

func scorer_name():
    var pool = []
    for i in starters:
        var pos = players[i].pos
        var w = 1
        if pos == "ATA" or pos == "PE" or pos == "PD":
            w = 5
        elif pos == "MEI" or pos == "MC":
            w = 3
        for k in w:
            pool.append(players[i].name)
    return pool[randi() % pool.size()]


func build_live_events(home_team, hg, away_team, ag, hurt):
    var ev = []
    ev.append({"t": 0, "text": "Começa a partida! %s x %s." % [home_team, away_team], "side": ""})
    ev.append({"t": 45, "text": "Fim do primeiro tempo.", "side": ""})
    ev.append({"t": 46, "text": "Bola rolando para o segundo tempo.", "side": ""})
    for k in hg:
        var txt = "Gol do %s!" % home_team
        if home_team == club.name:
            txt = "GOOOL! %s balança as redes para o %s!" % [scorer_name(), club.name]
        ev.append({"t": randi_range(1, 89), "text": txt, "side": "home"})
    for k in ag:
        var txt2 = "Gol do %s!" % away_team
        if away_team == club.name:
            txt2 = "GOOOL! %s balança as redes para o %s!" % [scorer_name(), club.name]
        ev.append({"t": randi_range(1, 89), "text": txt2, "side": "away"})
    for k in randi_range(2, 4):
        ev.append({"t": randi_range(3, 88), "text": "Chance perdida! %s finaliza e a bola passa perto." % scorer_name(), "side": ""})
    for hn in hurt:
        ev.append({"t": randi_range(10, 85), "text": "%s sente o físico e vai para o departamento médico." % hn, "side": ""})
    ev.append({"t": 90, "text": "Fim de jogo!", "side": ""})
    ev.sort_custom(func(a, b): return a.t < b.t)
    return ev


func build_live():
    live_root = Control.new()
    live_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(live_root)
    var bg = ColorRect.new()
    bg.color = Color(DARK, 0.97)
    bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    live_root.add_child(bg)

    var mc = MarginContainer.new()
    mc.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    mc.add_theme_constant_override("margin_left", 24)
    mc.add_theme_constant_override("margin_right", 24)
    mc.add_theme_constant_override("margin_top", 16)
    mc.add_theme_constant_override("margin_bottom", 16)
    live_root.add_child(mc)
    var vb = VBoxContainer.new()
    vb.add_theme_constant_override("separation", 12)
    mc.add_child(vb)

    # Cabeçalho: minuto, placar e botão de fechar
    var hb = HBoxContainer.new()
    hb.add_theme_constant_override("separation", 12)
    vb.add_child(hb)
    var mpn = PanelContainer.new()
    mpn.custom_minimum_size = Vector2(46, 46)
    mpn.size_flags_vertical = Control.SIZE_SHRINK_CENTER
    mpn.add_theme_stylebox_override("panel", make_box(LIME, 23, 0, 0))
    live_minute = make_label("0'", 13, Color.BLACK, false, HORIZONTAL_ALIGNMENT_CENTER)
    live_minute.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    mpn.add_child(live_minute)
    hb.add_child(mpn)
    var tv = VBoxContainer.new()
    tv.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    tv.size_flags_vertical = Control.SIZE_SHRINK_CENTER
    hb.add_child(tv)
    live_title = make_label("", 18, WHITE, true)
    tv.add_child(live_title)
    tv.add_child(make_label("WILFOOT LIVE • BRASILEIRÃO", 10, MUTED, true))
    var cb = Button.new()
    cb.text = "X"
    cb.custom_minimum_size = Vector2(44, 44)
    cb.add_theme_font_override("font", bold_font)
    cb.add_theme_stylebox_override("normal", make_box(Color(1, 1, 1, 0.10), 22, 0, 0, Color(1, 1, 1, 0.10), 1))
    cb.add_theme_stylebox_override("hover", make_box(Color(1, 1, 1, 0.18), 22, 0, 0, Color(1, 1, 1, 0.10), 1))
    cb.add_theme_stylebox_override("pressed", make_box(Color(1, 1, 1, 0.05), 22, 0, 0, Color(1, 1, 1, 0.10), 1))
    cb.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
    cb.pressed.connect(close_live)
    hb.add_child(cb)

    live_bar = ProgressBar.new()
    live_bar.show_percentage = false
    live_bar.max_value = 90.0
    live_bar.custom_minimum_size = Vector2(0, 6)
    live_bar.add_theme_stylebox_override("background", make_box(Color(1, 1, 1, 0.10), 100, 0, 0))
    live_bar.add_theme_stylebox_override("fill", make_box(LIME, 100, 0, 0))
    vb.add_child(live_bar)

    # Corpo: campo com a bola + narração
    var body = HBoxContainer.new()
    body.size_flags_vertical = Control.SIZE_EXPAND_FILL
    body.add_theme_constant_override("separation", 14)
    vb.add_child(body)
    var pp = PanelContainer.new()
    pp.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    pp.add_theme_stylebox_override("panel", make_box(Color("#0A1611"), 24, 0, 0, Color(0, 1, 0.533, 0.20), 1))
    body.add_child(pp)
    var view = PitchView.new()
    view.custom_minimum_size = Vector2(560, 300)
    pp.add_child(view)
    var ball = PanelContainer.new()
    ball.custom_minimum_size = Vector2(14, 14)
    ball.add_theme_stylebox_override("panel", make_box(LIME, 7, 0, 0))
    view.add_child(ball)
    view.items.append({"node": ball, "nx": 0.5, "ny": 0.48})
    live_view = view

    var np = make_panel()
    np.custom_minimum_size = Vector2(430, 0)
    body.add_child(np)
    var nv = VBoxContainer.new()
    nv.add_theme_constant_override("separation", 10)
    np.add_child(nv)
    nv.add_child(make_label("NARRAÇÃO WILFOOT", 10, DIM, true))
    live_scroll = ScrollContainer.new()
    live_scroll.name = "LiveScroll"
    live_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
    live_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    nv.add_child(live_scroll)
    live_log = VBoxContainer.new()
    live_log.name = "LiveLog"
    live_log.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    live_log.add_theme_constant_override("separation", 8)
    live_scroll.add_child(live_log)

    # Rodapé verde-limão
    var fp = PanelContainer.new()
    fp.add_theme_stylebox_override("panel", make_box(LIME, 16, 16, 10))
    vb.add_child(fp)
    var fh = HBoxContainer.new()
    fh.add_theme_constant_override("separation", 12)
    fp.add_child(fh)
    var fl = make_label("MOTOR GODOT • SIMULAÇÃO AO VIVO", 11, Color.BLACK, true)
    fl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    fl.size_flags_vertical = Control.SIZE_SHRINK_CENTER
    fh.add_child(fl)
    live_status = make_label("SIMULANDO...", 11, Color.BLACK)
    live_status.size_flags_vertical = Control.SIZE_SHRINK_CENTER
    fh.add_child(live_status)
    live_done_btn = Button.new()
    live_done_btn.text = "CONTINUAR"
    live_done_btn.custom_minimum_size = Vector2(150, 36)
    live_done_btn.visible = false
    live_done_btn.add_theme_font_override("font", bold_font)
    live_done_btn.add_theme_font_size_override("font_size", 12)
    live_done_btn.add_theme_stylebox_override("normal", make_box(Color.BLACK, 12, 12, 4))
    live_done_btn.add_theme_stylebox_override("hover", make_box(Color("#1C1C1C"), 12, 12, 4))
    live_done_btn.add_theme_stylebox_override("pressed", make_box(Color("#333333"), 12, 12, 4))
    live_done_btn.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
    for k in ["font_color", "font_hover_color", "font_pressed_color", "font_focus_color", "font_hover_pressed_color"]:
        live_done_btn.add_theme_color_override(k, LIME)
    live_done_btn.pressed.connect(close_live)
    fh.add_child(live_done_btn)


func open_live(home_team, hg, away_team, ag, hurt):
    if live_root != null:
        close_live()
    live_home = home_team
    live_away = away_team
    live_hg = 0
    live_ag = 0
    live_min = 0
    live_events = build_live_events(home_team, hg, away_team, ag, hurt)
    build_live()
    live_refresh()
    live_emit(0)
    live_timer = Timer.new()
    live_timer.wait_time = 0.11
    live_timer.timeout.connect(live_tick)
    add_child(live_timer)
    live_timer.start()


func live_refresh():
    live_title.text = "%s %d x %d %s" % [abbr(live_home), live_hg, live_ag, abbr(live_away)]
    live_minute.text = "%d'" % live_min
    live_bar.value = float(live_min)


func add_live_line(minute, text):
    # A narração pode receber eventos no mesmo frame em que a UI é criada.
    # Reconstrói as referências com segurança e nunca chama add_child em null.
    if live_root == null or not is_instance_valid(live_root):
        return
    if live_log == null or not is_instance_valid(live_log):
        live_log = live_root.find_child("LiveLog", true, false) as VBoxContainer
    if live_scroll == null or not is_instance_valid(live_scroll):
        live_scroll = live_root.find_child("LiveScroll", true, false) as ScrollContainer
    if live_log == null or not is_instance_valid(live_log):
        return
    var pc = PanelContainer.new()
    var sb = make_box(Color.TRANSPARENT, 0, 12, 4)
    sb.border_width_left = 2
    sb.border_color = Color(LIME, 0.5)
    pc.add_theme_stylebox_override("panel", sb)
    var l = make_label("%d'  %s" % [minute, text], 13, Color(1, 1, 1, 0.85))
    l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    pc.add_child(l)
    live_log.add_child(pc)
    await get_tree().process_frame
    if live_scroll != null and is_instance_valid(live_scroll):
        live_scroll.scroll_vertical = int(live_scroll.get_v_scroll_bar().max_value)


# Mostra os eventos do minuto e devolve a posição da bola (0 a 1) se houve gol.
func live_emit(minute):
    var goal_x = -1.0
    for e in live_events:
        if e.t == minute:
            add_live_line(minute, e.text)
            if e.side == "home":
                live_hg += 1
                goal_x = 0.94
            elif e.side == "away":
                live_ag += 1
                goal_x = 0.06
    return goal_x


func live_tick():
    if live_min >= 90:
        return
    if live_view == null or not is_instance_valid(live_view):
        close_live()
        return
    live_min += 1
    var goal_x = live_emit(live_min)
    var bx = 0.5 + 0.32 * sin(float(live_min) * 0.45) + randf_range(-0.03, 0.03)
    if goal_x >= 0.0:
        bx = goal_x
    if live_view.items.size() > 0 and live_view.items[0] is Dictionary:
        live_view.items[0]["nx"] = bx
        live_view._layout()
    live_refresh()
    if live_min >= 90:
        live_timer.stop()
        live_status.text = "FIM"
        live_done_btn.visible = true


func close_live():
    if live_timer != null and is_instance_valid(live_timer):
        live_timer.stop()
        live_timer.queue_free()
    live_timer = null
    if live_root != null and is_instance_valid(live_root):
        live_root.queue_free()
    live_root = null


# ---------------------------------------------------------------- INTEGRAÇÃO COM O EXPORT WEB (JSON)

# Cópia gravável no aparelho: res:// é somente leitura no Android exportado.
func rodada_user_path():
    return "user://" + rodada_json_path.get_file()


func rodada_placar():
    var pp = rodada_data.get("partida_principal")
    if typeof(pp) == TYPE_DICTIONARY:
        return str(pp.get("placar", ""))
    return ""


func carregar_rodada(silent := false):
    var tentativas = [rodada_user_path(), rodada_json_path, "res://Data/rodada_12.json"]
    var path = ""
    for c in tentativas:
        if FileAccess.file_exists(c):
            path = c
            break
    if path == "":
        if not silent:
            message = "Arquivo não encontrado. Tentei: " + ", ".join(tentativas)
        return false
    var file = FileAccess.open(path, FileAccess.READ)
    if not file:
        if not silent:
            message = "Não foi possível abrir " + path
        return false
    var json = JSON.new()
    var err = json.parse(file.get_as_text())
    file.close()
    if err != OK:
        message = "Erro no JSON (linha %d): %s" % [json.get_error_line(), json.get_error_message()]
        return false
    if typeof(json.data) != TYPE_DICTIONARY:
        message = "JSON inválido: era esperado um objeto."
        return false
    if not json.data.has("partida_principal") or not json.data.has("jogos_da_rodada"):
        message = "JSON incompleto: faltam \"partida_principal\" ou \"jogos_da_rodada\"."
        return false
    rodada_data = json.data
    rodada_importada = true
    if not silent:
        var pl = rodada_placar()
        message = "Rodada importada de %s" % path.get_file() + ((" • " + pl) if pl != "" else "") + "."
    atualizar_tela()
    return true


func atualizar_tela():
    if scroll_box != null and current_screen == "results":
        show_screen("results")


func jogo_time(jogo, casa: bool):
    var chaves = ["casa", "mandante", "time_casa", "home"] if casa else ["fora", "visitante", "time_fora", "away"]
    for k in chaves:
        if jogo.has(k):
            return str(jogo[k])
    return ""


func jogo_texto(jogo):
    var c = jogo_time(jogo, true)
    var f = jogo_time(jogo, false)
    var placar = str(jogo.get("placar", ""))
    if c != "" and f != "":
        return "%s %s %s" % [c, placar if placar != "" else "x", f]
    return placar if placar != "" else str(jogo)


func importar_rodada():
    if carregar_rodada():
        show_screen("results")
    else:
        show_screen("more")


# Mesma ideia do web artifact, mas usando a força dos times do jogo em vez de sorteio 0 a 3.
# Usa a força real dos times conhecidos (ou uma força estável por nome) em vez do
# sorteio 0-3 do script original, e simula a partida principal também.
func simular_nova_rodada():
    var por_divisao = rodada_data.get("jogos_da_rodada")
    if typeof(por_divisao) != TYPE_DICTIONARY:
        message = "Nenhuma rodada importada para simular."
        show_screen("more")
        return
    var total = 0
    for divisao in por_divisao.keys():
        var lista = por_divisao[divisao]
        if typeof(lista) != TYPE_ARRAY:
            continue
        for jogo in lista:
            if typeof(jogo) == TYPE_DICTIONARY:
                simular_jogo_importado(jogo)
                total += 1
    var pp = rodada_data.get("partida_principal")
    if typeof(pp) == TYPE_DICTIONARY:
        simular_jogo_importado(pp)
    rodada_data["ultima_simulacao"] = Time.get_datetime_string_from_system()
    rodada_importada = true
    if salvar_rodada():
        message = "Rodada simulada e salva (%d jogos)." % total
    else:
        message = "Rodada simulada, mas não foi possível salvar o arquivo."
    show_screen("results")


# Gravação atômica: escreve num arquivo temporário e só troca pelo definitivo no
# final, com backup do anterior — evita corromper o save se a gravação for interrompida.
func salvar_rodada(path := ""):
    if path == "":
        path = rodada_user_path()
    DirAccess.make_dir_recursive_absolute(path.get_base_dir())
    var backup_path = path + ".bak"
    var temp_path = path + ".tmp"
    if FileAccess.file_exists(path):
        DirAccess.copy_absolute(path, backup_path)
    var file = FileAccess.open(temp_path, FileAccess.WRITE)
    if not file:
        return false
    file.store_string(JSON.stringify(rodada_data, "\t"))
    file.close()
    if DirAccess.rename_absolute(temp_path, path) != OK:
        DirAccess.copy_absolute(temp_path, path)
    return true


func exportar_rodada(r, home_name, hg, away_name, ag):
    var estadio = "Estádio do " + home_name
    if home_name == club.name:
        estadio = "Estádio Beira-Rio"
    rodada_data = {
        "temporada": season,
        "rodada": r,
        "partida_principal": {"casa": home_name, "fora": away_name, "placar": "%d x %d" % [hg, ag], "estadio": estadio},
        "jogos_da_rodada": last_export
    }
    rodada_importada = false
    salvar_rodada("user://rodada_atual.json")


# ---------------------------------------------------------------- TÍTULOS, PATROCINADORES E PREMIAÇÕES
# Telas de referência a partir dos dados de Football-Manager-x-real do pacote ULTIMATE
# (Data/*.json, adaptado de Scripts/JogadorReal.gd, TimeReal.gd, PatrocinadorData.gd,
# Premiacao2026Data.gd). São informativas: não afetam o seu elenco nem o seu caixa.

func carregar_json_bundled(path):
    if not FileAccess.file_exists(path):
        return null
    var f = FileAccess.open(path, FileAccess.READ)
    if not f:
        return null
    var j = JSON.new()
    var err = j.parse(f.get_as_text())
    f.close()
    if err != OK:
        return null
    return j.data


func titulos_ordenados(lista):
    var s = lista.duplicate()
    s.sort_custom(func(a, b): return int(a.get("ano", 0)) > int(b.get("ano", 0)))
    return s


func cartao_titulos(nome, subtitulo, carteira):
    var pc = make_panel()
    content.add_child(pc)
    var vb = VBoxContainer.new()
    vb.add_theme_constant_override("separation", 8)
    pc.add_child(vb)
    var top = HBoxContainer.new()
    vb.add_child(top)
    var nl = make_label(nome, 15, WHITE, true)
    nl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    top.add_child(nl)
    top.add_child(pill("%d TÍTULOS" % carteira.size(), LIME, Color.BLACK, 10, 8, 3))
    if subtitulo != "":
        vb.add_child(make_label(subtitulo, 11, MUTED))
    for t in titulos_ordenados(carteira):
        var linha = "%d  •  %s" % [int(t.get("ano", 0)), str(t.get("titulo", ""))]
        if t.has("time"):
            linha += "  (%s)" % str(t["time"])
        vb.add_child(make_label(linha, 12, Color(1, 1, 1, 0.8)))


func screen_titulos():
    heading("TÍTULOS REAIS", "Carteira de títulos de jogadores e times reais, só para consulta")
    var jogadores = carregar_json_bundled("res://Data/jogadores_reais_titulos.json")
    var times = carregar_json_bundled("res://Data/times_reais_titulos.json")
    if jogadores == null and times == null:
        info("Não encontrei res://Data/jogadores_reais_titulos.json nem times_reais_titulos.json.")
        return
    if typeof(jogadores) == TYPE_ARRAY and jogadores.size() > 0:
        content.add_child(make_label("JOGADORES", 11, DIM, true))
        for j in jogadores:
            cartao_titulos("%s %s" % [j.get("flag", ""), j.get("nome", "")], "%s  •  %s  •  OVR %s" % [j.get("pais", ""), j.get("time_atual", ""), str(j.get("ovr", ""))], j.get("carteira_titulos", []))
    if typeof(times) == TYPE_ARRAY and times.size() > 0:
        content.add_child(make_label("TIMES", 11, DIM, true))
        for t in times:
            cartao_titulos("%s %s" % [t.get("flag", ""), t.get("nome", "")], "Fundado em %s  •  %s" % [str(t.get("fundacao", "")), t.get("estadio", "")], t.get("carteira_titulos", []))


func _trophy_card(title: String, count: int, years: Array[String], icon: String, selected: bool = false) -> PanelContainer:
    var panel := PanelContainer.new()
    panel.custom_minimum_size = Vector2(0, 205)
    var box := StyleBoxFlat.new()
    box.bg_color = Color("101923") if not selected else Color("122a3e")
    box.border_color = Color("2ba7ff") if selected else Color("253746")
    box.set_border_width_all(2 if selected else 1)
    box.set_corner_radius_all(14)
    box.content_margin_left = 12
    box.content_margin_right = 12
    box.content_margin_top = 12
    box.content_margin_bottom = 12
    panel.add_theme_stylebox_override("panel", box)
    var v := VBoxContainer.new()
    v.add_theme_constant_override("separation", 7)
    panel.add_child(v)
    var icon_label := Label.new()
    icon_label.text = icon
    icon_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    icon_label.add_theme_font_size_override("font_size", 42)
    v.add_child(icon_label)
    var name_label := Label.new()
    name_label.text = title
    name_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    name_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    name_label.add_theme_font_size_override("font_size", 16)
    v.add_child(name_label)
    var count_label := Label.new()
    count_label.text = "🏆 %d conquista%s" % [count, "" if count == 1 else "s"]
    count_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    count_label.add_theme_color_override("font_color", Color("ffd45a"))
    count_label.add_theme_font_size_override("font_size", 14)
    v.add_child(count_label)
    var years_label := Label.new()
    years_label.text = ", ".join(years.slice(0, 5)) if years.size() > 0 else "Nenhum título registrado"
    years_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    years_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    years_label.add_theme_color_override("font_color", Color("aab7c4"))
    years_label.add_theme_font_size_override("font_size", 11)
    v.add_child(years_label)
    return panel

func screen_trofeus() -> void:
    heading("GALERIA DE TROFÉUS", "%s • conquistas históricas" % str(club.get("name", "Clube")), "🏆 %d TÍTULOS" % int(club.get("total_titulos", 0)))
    var root := VBoxContainer.new()
    root.add_theme_constant_override("separation", 12)
    content.add_child(root)

    var hero := PanelContainer.new()
    hero.custom_minimum_size = Vector2(0, 112)
    var hero_style := StyleBoxFlat.new()
    hero_style.bg_color = Color("0b1420")
    hero_style.border_color = Color("2ba7ff")
    hero_style.set_border_width_all(1)
    hero_style.set_corner_radius_all(16)
    hero_style.content_margin_left = 18
    hero_style.content_margin_right = 18
    hero_style.content_margin_top = 14
    hero_style.content_margin_bottom = 14
    hero.add_theme_stylebox_override("panel", hero_style)
    var hero_box := HBoxContainer.new()
    hero_box.add_theme_constant_override("separation", 14)
    hero.add_child(hero_box)
    var hero_crest := Label.new()
    hero_crest.text = "⚽"
    hero_crest.add_theme_font_size_override("font_size", 48)
    hero_crest.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    hero_box.add_child(hero_crest)
    var hero_text := VBoxContainer.new()
    hero_box.add_child(hero_text)
    var club_name_label := Label.new()
    club_name_label.text = str(club.get("name", "Clube"))
    club_name_label.add_theme_font_size_override("font_size", 24)
    hero_text.add_child(club_name_label)
    var meta := Label.new()
    meta.text = "%s • %s • Fundado em %s" % [str(club.get("city", "Brasil")), str(club.get("stadium", "Estádio")), str(club.get("founded", club.get("fundacao", "—")))]
    meta.add_theme_color_override("font_color", Color("9fb0bf"))
    hero_text.add_child(meta)
    var total := Label.new()
    total.text = "🏆 %d títulos registrados" % int(club.get("total_titulos", 0))
    total.add_theme_color_override("font_color", Color("ffd45a"))
    hero_text.add_child(total)
    root.add_child(hero)

    var filters := HBoxContainer.new()
    filters.add_theme_constant_override("separation", 8)
    for label_text in ["TODOS", "NACIONAIS", "INTERNACIONAIS", "REGIONAIS"]:
        var b := Button.new()
        b.text = label_text
        b.custom_minimum_size = Vector2(0, 48)
        b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        b.focus_mode = Control.FOCUS_NONE
        b.add_theme_font_size_override("font_size", 13)
        filters.add_child(b)
    root.add_child(filters)

    var grid := GridContainer.new()
    grid.columns = 2 if get_viewport_rect().size.x < 900.0 else 4
    grid.add_theme_constant_override("h_separation", 10)
    grid.add_theme_constant_override("v_separation", 10)
    root.add_child(grid)

    var trophies: Array[Dictionary] = [
        {"title":"Brasileirão - Série A", "key":"brasileirao", "icon":"🏆"},
        {"title":"Copa do Brasil", "key":"copa_brasil", "icon":"🏆"},
        {"title":"Libertadores", "key":"libertadores", "icon":"🌎"},
        {"title":"Mundial de Clubes", "key":"mundial", "icon":"🌐"},
        {"title":"Recopa Sul-Americana", "key":"recopa", "icon":"🥇"},
        {"title":"Estadual / Regional", "key":"estadual", "icon":"🏅"}
    ]
    for i in trophies.size():
        var t: Dictionary = trophies[i]
        var count := int(club.get(t["key"], 0))
        var years: Array[String] = []
        var card_data: Variant = club.get("carteira_titulos", [])
        if card_data is Array:
            for item in card_data:
                if item is Dictionary and str(item.get("competicao", "")).to_lower().contains(str(t["title"]).split(" ")[0].to_lower()):
                    years.append(str(item.get("ano", "")))
        grid.add_child(_trophy_card(str(t["title"]), count, years, str(t["icon"]), i == 0))

    var tip := Label.new()
    tip.text = "Toque em uma competição para abrir detalhes, temporadas conquistadas e histórico do clube."
    tip.add_theme_color_override("font_color", Color("8ea0ae"))
    tip.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    tip.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    tip.add_theme_font_size_override("font_size", 13)
    root.add_child(tip)

func _ranking_panel(title_text: String, subtitle: String, rows: Array, accent: Color) -> PanelContainer:
    var panel := PanelContainer.new()
    var sb := StyleBoxFlat.new()
    sb.bg_color = Color("#08111D")
    sb.border_color = accent
    sb.set_border_width_all(1)
    sb.set_corner_radius_all(16)
    sb.content_margin_left = 12
    sb.content_margin_right = 12
    sb.content_margin_top = 10
    sb.content_margin_bottom = 10
    panel.add_theme_stylebox_override("panel", sb)
    var box := VBoxContainer.new()
    box.add_theme_constant_override("separation", 7)
    panel.add_child(box)
    var h := HBoxContainer.new()
    box.add_child(h)
    var ttl := make_label(title_text, 17, WHITE, true)
    ttl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    h.add_child(ttl)
    h.add_child(pill(str(rows.size()) + " ITENS", accent, Color.WHITE, 9, 8, 3))
    box.add_child(make_label(subtitle, 11, MUTED))
    var head := HBoxContainer.new()
    head.add_theme_constant_override("separation", 8)
    box.add_child(head)
    for x in [["#",35],["NOME",0],["PONTOS",80],["ANO",58]]:
        var hl := make_label(x[0], 10, DIM, true)
        hl.custom_minimum_size = Vector2(float(x[1]), 28)
        if int(x[1]) == 0: hl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        head.add_child(hl)
    for i in rows.size():
        var row: Dictionary = rows[i]
        var rb := HBoxContainer.new()
        rb.custom_minimum_size = Vector2(0, 34)
        rb.add_theme_constant_override("separation", 8)
        if i == 0:
            var rbg := ColorRect.new()
            rbg.color = Color(accent, 0.10)
            rbg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
            rbg.mouse_filter = Control.MOUSE_FILTER_IGNORE
            rb.add_child(rbg)
        var pos := make_label("%02d" % (i + 1), 11, GOLD if i < 3 else MUTED, true)
        pos.custom_minimum_size = Vector2(35, 30)
        rb.add_child(pos)
        var nm := make_label(str(row.get("name", "—")), 12, WHITE if i < 3 else Color("#C7D5E2"), true)
        nm.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        rb.add_child(nm)
        var pts := make_label(str(row.get("points", "—")), 12, GOLD if i == 0 else WHITE, true)
        pts.custom_minimum_size = Vector2(80, 30)
        rb.add_child(pts)
        var yr := make_label(str(row.get("year", "—")), 11, MUTED, true)
        yr.custom_minimum_size = Vector2(58, 30)
        rb.add_child(yr)
        box.add_child(rb)
    return panel


func screen_rankings() -> void:
    heading("RANKINGS", "WILFOOT 2.1 • histórico, desempenho e prestígio mundial", "4 RANKINGS")
    var ballon: Array[Dictionary] = [
        {"name":"Lionel Messi", "points":"92.00", "year":"2025"},
        {"name":"Ousmane Dembélé", "points":"78.79", "year":"2024"},
        {"name":"Rodri", "points":"83.70", "year":"2023"},
        {"name":"Karim Benzema", "points":"98.39", "year":"2022"},
        {"name":"Lionel Messi", "points":"56.76", "year":"2021"},
        {"name":"Lionel Messi", "points":"64.96", "year":"2019"},
        {"name":"Luka Modrić", "points":"71.31", "year":"2018"},
        {"name":"Cristiano Ronaldo", "points":"89.58", "year":"2017"},
        {"name":"Cristiano Ronaldo", "points":"86.13", "year":"2016"},
        {"name":"Lionel Messi", "points":"41.33", "year":"2015"}
    ]
    var selections: Array[Dictionary] = [
        {"name":"Argentina", "points":"1900", "year":"+0"}, {"name":"Espanha", "points":"1596", "year":"+1"},
        {"name":"Itália", "points":"1592", "year":"-1"}, {"name":"Brasil", "points":"1588", "year":"0"},
        {"name":"Inglaterra", "points":"1584", "year":"0"}, {"name":"Alemanha", "points":"1580", "year":"0"},
        {"name":"França", "points":"1576", "year":"+2"}, {"name":"Croácia", "points":"1572", "year":"-1"},
        {"name":"México", "points":"1568", "year":"0"}, {"name":"Bélgica", "points":"1568", "year":"+1"}
    ]
    var clubs: Array[Dictionary] = []
    var sorted: Array[Dictionary] = []
    for lg in LEAGUES:
        for t in lg.teams:
            sorted.append({"name": str(t[0]), "points": str(int(t[1]) * 15), "year": str(lg.short)})
    sorted.sort_custom(func(a: Dictionary, b: Dictionary) -> bool: return int(a.points) > int(b.points))
    clubs = sorted.slice(0, mini(10, sorted.size()))
    var leagues: Array[Dictionary] = []
    for lg in LEAGUES:
        var avg := 0.0
        for t in lg.teams: avg += float(t[1])
        avg /= float(lg.teams.size())
        leagues.append({"name": str(lg.name), "points": str(int(avg * 6)), "year": str(lg.short)})
    leagues.sort_custom(func(a: Dictionary, b: Dictionary) -> bool: return int(a.points) > int(b.points))
    var top := GridContainer.new()
    top.columns = 2 if get_viewport_rect().size.x >= 760 else 1
    top.add_theme_constant_override("h_separation", 10)
    top.add_theme_constant_override("v_separation", 10)
    content.add_child(top)
    top.add_child(_ranking_panel("🏆  BOLA DE OURO", "Histórico de vencedores e pontuação da temporada", ballon, GOLD))
    top.add_child(_ranking_panel("🌍  RANKING DE SELEÇÕES", "Pontuação mundial e variação de posição", selections, LIME))
    var bottom := GridContainer.new()
    bottom.columns = 2 if get_viewport_rect().size.x >= 760 else 1
    bottom.add_theme_constant_override("h_separation", 10)
    bottom.add_theme_constant_override("v_separation", 10)
    content.add_child(bottom)
    bottom.add_child(_ranking_panel("⚽  RANKING DE CLUBES", "Força, títulos e desempenho internacional", clubs, NEON))
    bottom.add_child(_ranking_panel("🏟️  RANKING DE LIGAS", "Coeficiente e nível competitivo", leagues, Color("#8C7CFF")))


func screen_patrocinadores():
    heading("PATROCINADORES", "Valores reais de patrocínio máster no futebol brasileiro (2025/2026)")
    var lista = carregar_json_bundled("res://Data/patrocinadores_brasil_2026_reais.json")
    if typeof(lista) != TYPE_ARRAY or lista.size() == 0:
        info("Não encontrei res://Data/patrocinadores_brasil_2026_reais.json.")
        return
    for p in lista:
        var pc = make_panel()
        content.add_child(pc)
        var vb = VBoxContainer.new()
        vb.add_theme_constant_override("separation", 6)
        pc.add_child(vb)
        var top = HBoxContainer.new()
        vb.add_child(top)
        var nl = make_label("%s  •  %s" % [str(p.get("time", "")), str(p.get("marca", ""))], 15, WHITE, true)
        nl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        top.add_child(nl)
        top.add_child(pill(str(p.get("categoria", "")), LIME if p.get("ativo", true) else PANEL2, Color.BLACK if p.get("ativo", true) else MUTED, 10, 8, 3))
        vb.add_child(make_label("R$ %.0fM/ano  •  %d anos  •  %s" % [float(p.get("valor_ano", 0.0)), int(p.get("anos", 0)), str(p.get("posicao", ""))], 13, Color(1, 1, 1, 0.85)))
        if p.has("detalhe"):
            var dl = make_label(str(p["detalhe"]), 11, MUTED)
            dl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
            vb.add_child(dl)


func screen_premiacoes():
    heading("PREMIAÇÕES REAIS", "Valores oficiais de premiação de competições (CBF, CONMEBOL, UEFA, Premier League)")
    var dados = carregar_json_bundled("res://Data/premiacoes_2026_atualizadas_cbf.json")
    if typeof(dados) != TYPE_DICTIONARY or dados.size() == 0:
        info("Não encontrei res://Data/premiacoes_2026_atualizadas_cbf.json.")
        return
    for comp in dados.keys():
        var d = dados[comp]
        var pc = make_panel()
        content.add_child(pc)
        var vb = VBoxContainer.new()
        vb.add_theme_constant_override("separation", 6)
        pc.add_child(vb)
        vb.add_child(make_label(comp, 14, WHITE, true))
        var linha = ""
        for k in d.keys():
            if k in ["fonte", "detalhe", "moeda", "aumento"]:
                continue
            var v = d[k]
            var txt = ("%.1f" % v) if typeof(v) == TYPE_FLOAT else str(v)
            linha += "%s: %s %s   " % [k, txt, str(d.get("moeda", ""))]
        var ll = make_label(linha.strip_edges(), 12, Color(1, 1, 1, 0.85))
        ll.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
        vb.add_child(ll)
        if d.has("fonte"):
            var fl = make_label(str(d["fonte"]), 11, MUTED)
            fl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
            vb.add_child(fl)


func painel_rodada_json():
    if not rodada_importada or rodada_data.is_empty():
        return
    var pc = make_panel()
    content.add_child(pc)
    var vb = VBoxContainer.new()
    vb.add_theme_constant_override("separation", 8)
    pc.add_child(vb)
    vb.add_child(make_label("RODADA IMPORTADA • %s" % rodada_json_path.get_file(), 11, LIME, true))
    var pp = rodada_data.get("partida_principal")
    if typeof(pp) == TYPE_DICTIONARY:
        var txt = "Partida principal: " + jogo_texto(pp)
        if pp.has("estadio"):
            txt += "  •  " + str(pp["estadio"])
        var l = make_label(txt, 14, WHITE)
        l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
        vb.add_child(l)
    var por_divisao = rodada_data.get("jogos_da_rodada")
    if typeof(por_divisao) == TYPE_DICTIONARY:
        for divisao in por_divisao.keys():
            var lista = por_divisao[divisao]
            if typeof(lista) != TYPE_ARRAY:
                continue
            vb.add_child(make_label(str(divisao).to_upper(), 10, DIM, true))
            for jogo in lista:
                if typeof(jogo) == TYPE_DICTIONARY:
                    vb.add_child(make_label(jogo_texto(jogo), 13, Color("#D2D6DB")))
